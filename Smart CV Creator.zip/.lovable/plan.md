# خطة التنفيذ

## 1) رفع السيرة الذاتية واستخراجها بالذكاء الاصطناعي
- زر **"رفع سيرة ذاتية"** في صفحة `builder` يقبل: PDF, DOCX, TXT, صورة (PNG/JPG).
- يستخدم `document--parse_document` على الخادم (Server Function) لاستخراج النص.
- وضع جديد في `ai-assist` اسمه **`cv_parse`** يحوّل النص إلى JSON يطابق `CVData` (contact, experience, education, skills, projects, certificates, languages…).
- معاينة قبل الاستيراد: المستخدم يختار الحقول/الأقسام التي يريد دمجها (replace / merge / skip).
- بعد الاستيراد: زر **"تحسين تلقائي بالـ AI"** يطبّق `improve` على summary + bullets الخبرة.
- إمكانية إضافة أقسام مخصصة (custom sections) قبل الحفظ.

## 2) إصلاح المشاكل
- تمرير `tsc --noEmit` كاملاً.
- مراجعة سريعة لتحذيرات وحدة التحكم (re-renders, missing keys, hydration).
- التأكد من أن lazy autoreanalyze لا يُطلق طلبات أثناء الكتابة.

## 3) عشر ميزات جديدة قوية
| # | الميزة | الوصف المختصر |
|---|---|---|
| 1 | **CV Parser** (أعلاه) | رفع ملف → تعبئة تلقائية |
| 2 | **Multi-CV Workspace** | إدارة عدة سير ذاتية، نسخ، أرشفة، مقارنة جنبًا إلى جنب |
| 3 | **Version History** | كل تعديل = سناب‌شوت قابل للاستعادة (آخر 20) |
| 4 | **AI Interview Coach** | يولّد أسئلة مقابلة من CV + JD ويقيّم إجاباتك صوتيًا/نصيًا |
| 5 | **Skill Gap Analyzer** | يحلّل الفجوة مع وصف الوظيفة ويقترح كورسات (روابط) |
| 6 | **LinkedIn Import** | لصق رابط/تصدير LinkedIn → تعبئة تلقائية |
| 7 | **Public Share Link** | رابط عام `/cv/:slug` بميتاداتا OG ومعاينة فاخرة |
| 8 | **AI Photo Enhancer** | اقتصاص ذكي + خلفية احترافية للصورة الشخصية |
| 9 | **PDF + DOCX + JSON Export** | تصدير DOCX حقيقي عبر `docx`، PDF محسّن للطباعة، JSON للنسخ الاحتياطي |
| 10 | **Smart Templates Recommendation** | AI يقترح القالب الأمثل بناءً على المجال والخبرة |
| 11 (إضافي) | **Translate CV** (AR↔EN بنقرة) | ترجمة كاملة مع الحفاظ على البنية |
| 12 (إضافي) | **ATS Auto-Tracker** | تتبّع تطوّر النتيجة عبر الزمن مع رسم بياني |

## تفاصيل تقنية
- Edge function `ai-assist` يضاف لها modes: `cv_parse`, `interview_questions`, `skill_gap`, `translate_cv`, `template_recommend`.
- مكوّن `CVUploadDialog` جديد في `src/components/cv/`.
- حفظ النسخ في `localStorage` تحت `cv_versions_v1` (حتى لا نحتاج DB لو لم تُرد).
- التصدير DOCX يستخدم مكتبة `docx` (مثبتة لخطاب التغطية حاليًا — نعيد استخدامها).
- ميزة المشاركة العامة تتطلب Lovable Cloud (جدول `shared_cvs` + RLS) — أنبّهك قبل البدء.

## ترتيب التنفيذ المقترح
1. CV Parser + إصلاحات سريعة (الأهم) ✅
2. Version History + Multi-CV
3. Translate + Template Recommendation + Skill Gap
4. Interview Coach + LinkedIn Import
5. Photo Enhancer + DOCX Export + Public Share
6. ATS Tracker

هل أبدأ بالخطوة 1 الآن (الرفع + الإصلاحات) ثم نتابع الميزات بالترتيب أعلاه؟ أم تفضّل ترتيبًا مختلفًا أو حذف ميزات معيّنة (مثل المشاركة العامة التي تحتاج قاعدة بيانات)؟
