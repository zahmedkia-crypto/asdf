// AI assistant for CV builder: improve text, suggest content, generate cover letter, match job, ATS score, parse uploaded CV
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SYSTEM_PROMPTS: Record<string, (lang: string, extra?: Record<string, unknown>) => string> = {
  improve: (lang) =>
    `You rewrite CV text to be concise, action-oriented, ATS-friendly, and grammatically perfect. Keep it factual — never fabricate. FORMATTING RULES: produce well-structured paragraphs that look clean when justified (text-align: justify) — balanced sentence length (12–22 words), no extremely long unbreakable words, no double spaces, use proper punctuation, no markdown, no leading/trailing whitespace. For a summary: 2–4 sentences, single paragraph. For bullets: each starts with "• " on its own line. Respond in ${lang === "ar" ? "Arabic" : "English"} only with the improved text, no preamble.`,
  suggest: (lang) =>
    `You suggest professional CV content based on the role/context provided. Return 3-5 short bullet points. Respond in ${lang === "ar" ? "Arabic" : "English"} only.`,
  cover_letter: (lang, extra) => {
    const tone = (extra?.tone as string) || "professional";
    const toneDesc: Record<string, string> = {
      professional: "formal, confident, business-appropriate",
      friendly: "warm, conversational, personable while still professional",
      creative: "bold, original, memorable with a creative hook",
    };
    return `You write professional cover letters tailored to the job and CV provided. Tone: ${toneDesc[tone] || toneDesc.professional}. Specific, sincere. 3-4 short paragraphs. Respond in ${lang === "ar" ? "Arabic" : "English"} only.`;
  },
  match: (lang) =>
    `You analyze a CV against a job description. Return JSON: {"score":0-100,"matched_keywords":[],"missing_keywords":[],"suggestions":[]}. Respond in ${lang === "ar" ? "Arabic" : "English"} for suggestions text.`,
  ats: (lang) =>
    `You evaluate a CV for ATS-readiness. If a JOB DESCRIPTION is included in the user message, extract its key skills, tools and responsibilities and use them to drive matched_keywords / missing_keywords / keywords_to_add. Return ONLY valid minified JSON: {"score":0-100,"strengths":[],"weaknesses":[],"matched_keywords":[],"missing_keywords":[],"keywords_to_add":[],"placement_plan":[{"keyword":"","section":"summary|experience|skills|projects|other","reason":""}]}. placement_plan MUST contain ONE entry for EVERY missing_keyword (and any keyword in keywords_to_add) explaining the most appropriate CV section to insert it into: technical tools/frameworks → "skills"; soft-skills/responsibilities → "summary" or "experience"; portfolio/work artifacts → "projects". Respond in ${lang === "ar" ? "Arabic" : "English"} for reason text only — keep keyword and section values verbatim from JD.`,
  skills_suggest: (lang) =>
    `You suggest the most relevant professional skills for the given job title/role. Return ONLY valid minified JSON: {"skills":["Skill 1","Skill 2",...]}. 10-15 concrete skills (technical + soft, ATS-friendly keywords). No explanations. Skill names in ${lang === "ar" ? "Arabic" : "English"}.`,
  bullets: (lang) =>
    `You convert a long job/project description into 3-5 concise, action-oriented bullet points. Each bullet starts with a strong action verb (Led, Built, Delivered, Designed, Optimized, Increased…). Add metrics where plausible (%, $, count). Keep facts only — never invent. Return ONLY the bullets separated by newlines, each starting with "• ". Respond in ${lang === "ar" ? "Arabic" : "English"}.`,
  hint: (lang) =>
    `You are an inline writing assistant for CVs. Given a short text the user is writing, return ONE concise improved version (1-3 sentences max) — clearer, more professional, more ATS-friendly. Keep the user's intent and facts. Respond in ${lang === "ar" ? "Arabic" : "English"} ONLY with the improved text. No preamble, no quotes.`,
  ats_apply: (lang) =>
    `You receive a CV as JSON, an ATS analysis (weaknesses + keywords_to_add + missing_keywords), and optionally a JOB DESCRIPTION. Rewrite the CV to maximize ATS score (target 90+) and tailor it to the job description when provided. Place each missing keyword in the MOST APPROPRIATE section (technical tools → skills, soft skills/responsibilities → summary or experience bullets):
- Strengthen 'contact.summary' with strong action verbs and naturally integrate the missing keywords.
- Rewrite each 'experience[].description' as 3-5 concise bullet points starting with action verbs, using metrics where plausible, and weaving in relevant keywords. Preserve facts (company, position, dates) — never fabricate employers or degrees.
- Improve 'projects[].description' similarly.
- Add reasonable missing keywords as new entries in 'skills' (level 4) when they fit the role.
- Keep the EXACT same JSON schema, all 'id' values, and all top-level keys: id, name, lang, template, contact, experience, education, skills, certificates, projects, courses, awards, languages, custom, sectionOrder, updatedAt.
- Write all rewritten text in ${lang === "ar" ? "Arabic" : "English"}.
Return ONLY the full updated CV as valid minified JSON. No markdown, no commentary.`,
  cover_improve: (lang) =>
    `You improve a cover letter: more compelling, specific, professional, ATS-friendly while preserving facts. Keep 3-4 short paragraphs. Respond in ${lang === "ar" ? "Arabic" : "English"} ONLY with the improved letter text. No preamble, no quotes, no markdown.`,
  cover_ats: (lang) =>
    `You evaluate a cover letter against a job description for ATS-readiness and relevance. Return ONLY valid minified JSON: {"score":0-100,"matched_keywords":[],"missing_keywords":[],"strengths":[],"weaknesses":[],"suggestions":[]}. Strengths and weaknesses are short bullet phrases (3-6 each). Suggestions are concrete actionable edits. All text in ${lang === "ar" ? "Arabic" : "English"}.`,
  cover_apply: (lang) =>
    `You receive a cover letter, a job description, and an ATS analysis (missing_keywords, weaknesses, suggestions). Rewrite the letter to address every weakness, naturally weave in the missing keywords, and apply each suggestion — while preserving the candidate's facts. Keep 3-4 short paragraphs, professional and ATS-friendly. Respond in ${lang === "ar" ? "Arabic" : "English"} ONLY with the rewritten letter text. No preamble, no quotes, no markdown.`,
  cv_parse: (lang) =>
    `You extract structured CV data from raw text or a document/image. Return ONLY valid minified JSON matching this shape (omit unknown fields, never invent facts):
{"contact":{"fullName":"","jobTitle":"","email":"","phone":"","location":"","website":"","linkedin":"","summary":""},
"experience":[{"position":"","company":"","location":"","startDate":"YYYY/MM","endDate":"YYYY/MM or empty","current":false,"description":""}],
"education":[{"degree":"","institution":"","location":"","startDate":"","endDate":"","gpa":"","description":""}],
"skills":[{"name":"","level":3}],
"certificates":[{"name":"","issuer":"","date":"","credentialId":"","url":""}],
"projects":[{"name":"","role":"","date":"","url":"","description":""}],
"courses":[{"name":"","provider":"","date":"","url":""}],
"awards":[{"name":"","issuer":"","date":"","description":""}],
"languages":[{"name":"","proficiency":"basic|conversational|fluent|native"}]}
Detect language; keep original text language. Normalize dates to YYYY/MM when possible. Skill level: 5 expert, 4 advanced, 3 intermediate, 2 basic, 1 beginner. Write field text in ${lang === "ar" ? "Arabic" : "English"} only when translating; otherwise preserve the source. No markdown fences. No commentary.`,
  translate_cv: (lang) =>
    `You translate a CV JSON between Arabic and English. Target language: ${lang === "ar" ? "Arabic" : "English"}. Translate ALL text fields (summary, position, company, description, degree, institution, project descriptions, custom titles…). Preserve emails, URLs, phone numbers, dates, ids verbatim. Return ONLY the full translated CV JSON with the EXACT same schema and all id fields. No markdown.`,
  template_recommend: (lang) =>
    `You recommend the best CV template from this list: classic, modern, elegant, minimal, creative, ats, executive, tech, timeline, compact, twocol. Base your choice on the candidate's industry, seniority, and target role. Return ONLY JSON: {"template":"<id>","reason":"<short reason in ${lang === "ar" ? "Arabic" : "English"}>"}`,
  skill_gap: (lang) =>
    `Compare a CV against a job description. Identify skill gaps and recommend learning resources. Return ONLY JSON: {"gaps":[{"skill":"","why":"","resources":[{"title":"","url":""}]}],"strengths":[""]}. Recommend reputable resources (Coursera, edX, Udemy, official docs, YouTube). Text in ${lang === "ar" ? "Arabic" : "English"}.`,
  interview_questions: (lang) =>
    `Generate likely interview questions tailored to the candidate's CV and optionally a job description. Return ONLY JSON: {"questions":[{"q":"","category":"behavioral|technical|situational","tip":""}]}. 8-12 questions. Text in ${lang === "ar" ? "Arabic" : "English"}.`,
};

interface ContentPart {
  type: string;
  text?: string;
  image_url?: { url: string };
  file?: { filename: string; file_data: string };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { mode, prompt, lang = "ar", file, userKey, userProvider, userModel, ...extra } = await req.json();
    const lovableKey = Deno.env.get("LOVABLE_API_KEY");

    const sys = SYSTEM_PROMPTS[mode];
    if (!sys) throw new Error("Invalid mode");

    // Build user content
    let userContent: string | ContentPart[] = prompt || "";
    if (file && file.dataUrl) {
      const parts: ContentPart[] = [];
      if (prompt) parts.push({ type: "text", text: prompt });
      const mime: string = file.mime || "";
      if (mime.startsWith("image/")) {
        parts.push({ type: "image_url", image_url: { url: file.dataUrl } });
      } else if (mime === "application/pdf") {
        parts.push({ type: "file", file: { filename: file.name || "cv.pdf", file_data: file.dataUrl } });
      } else {
        parts.push({ type: "text", text: `[FILE: ${file.name}]` });
      }
      userContent = parts;
    }

    // Route: user-provided key (Google/OpenRouter/Groq) OR Lovable Gateway
    let endpoint = "https://ai.gateway.lovable.dev/v1/chat/completions";
    let model = "google/gemini-3-flash-preview";
    let authKey = lovableKey;

    if (userKey && typeof userKey === "string" && userKey.length > 10) {
      authKey = userKey;
      if (userProvider === "openrouter") {
        endpoint = "https://openrouter.ai/api/v1/chat/completions";
        model = userModel || "google/gemini-2.0-flash-exp:free";
      } else if (userProvider === "groq") {
        endpoint = "https://api.groq.com/openai/v1/chat/completions";
        model = userModel || "llama-3.3-70b-versatile";
      } else if (userProvider === "google") {
        endpoint = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions";
        model = userModel || "gemini-2.0-flash";
      }
    }

    if (!authKey) throw new Error("No API key configured");

    const resp = await fetch(endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${authKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: sys(lang, extra) },
          { role: "user", content: userContent },
        ],
      }),
    });

    if (resp.status === 429) {
      return new Response(JSON.stringify({ error: "rate_limit" }), {
        status: 429,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (resp.status === 402) {
      return new Response(JSON.stringify({ error: "credits" }), {
        status: 402,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!resp.ok) {
      const t = await resp.text();
      console.error("gateway", resp.status, t);
      return new Response(JSON.stringify({ error: "gateway_error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const data = await resp.json();
    const content = data.choices?.[0]?.message?.content ?? "";
    return new Response(JSON.stringify({ content }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "unknown" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
