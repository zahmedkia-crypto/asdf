import { supabase } from "@/integrations/supabase/client";

export type AIMode = "improve" | "suggest" | "cover_letter" | "match" | "ats" | "ats_apply" | "skills_suggest" | "bullets" | "hint" | "cover_improve" | "cover_ats" | "cover_apply" | "cv_parse" | "translate_cv" | "template_recommend" | "skill_gap" | "interview_questions";

export type AIProvider = "lovable" | "google" | "openrouter" | "groq";

export interface UserKeyConfig {
  provider: AIProvider;
  key: string;
  model?: string;
}

const KEY_USERKEY = "cv:userKey";
const KEY_PREFER_USER = "cv:preferUserKey";

export function getUserKey(): UserKeyConfig | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY_USERKEY);
    if (!raw) return null;
    return JSON.parse(raw) as UserKeyConfig;
  } catch { return null; }
}
export function setUserKey(c: UserKeyConfig | null) {
  if (!c) localStorage.removeItem(KEY_USERKEY);
  else localStorage.setItem(KEY_USERKEY, JSON.stringify(c));
}
export function getPreferUserKey(): boolean {
  if (typeof localStorage === "undefined") return false;
  return localStorage.getItem(KEY_PREFER_USER) === "1";
}
export function setPreferUserKey(v: boolean) {
  localStorage.setItem(KEY_PREFER_USER, v ? "1" : "0");
}

export async function callAI(mode: AIMode, prompt: string, lang: "ar" | "en" = "ar", extra?: Record<string, unknown>) {
  const user = getUserKey();
  const prefer = getPreferUserKey();
  const userKeyPayload = user && prefer ? { userKey: user.key, userProvider: user.provider, userModel: user.model } : {};

  const { data, error } = await supabase.functions.invoke("ai-assist", {
    body: { mode, prompt, lang, ...userKeyPayload, ...(extra || {}) },
  });
  if (error) {
    const status = (error as { context?: { status?: number } }).context?.status;
    if (status === 429) throw new Error("rate_limit");
    if (status === 402) throw new Error("credits");
    throw new Error("ai_error");
  }
  return (data as { content: string }).content as string;
}

export async function pingAI(): Promise<{ ok: boolean; ms: number; error?: string; via?: string }> {
  const t0 = performance.now();
  try {
    const out = await callAI("hint", "ping", "en");
    return { ok: true, ms: Math.round(performance.now() - t0), via: out.slice(0, 30) };
  } catch (e) {
    return { ok: false, ms: Math.round(performance.now() - t0), error: e instanceof Error ? e.message : "unknown" };
  }
}

export function tryParseJSON<T>(s: string): T | null {
  const cleaned = s.replace(/```json\s*/gi, "").replace(/```/g, "").trim();
  try {
    return JSON.parse(cleaned) as T;
  } catch {
    const m = cleaned.match(/\{[\s\S]*\}/);
    if (m) {
      try { return JSON.parse(m[0]) as T; } catch { return null; }
    }
    return null;
  }
}
