import type { CVData, TemplateId } from "./cv-types";

export interface ATSLocalIssue {
  level: "error" | "warn" | "info";
  section?: string;
  message: string;
}

export interface ATSLocalReport {
  score: number;
  issues: ATSLocalIssue[];
  missingKeywords: string[];
}

/** Templates known to be problematic for naive ATS parsers (multi-column, heavy graphics). */
const RISKY_TEMPLATES: Partial<Record<TemplateId, { ar: string; en: string }>> = {
  twocol: { ar: "قالب بعمودين قد يربك بعض أنظمة ATS — يفضّل قالب أحادي العمود.", en: "Two-column layouts can confuse some ATS parsers — prefer a single column." },
  creative: { ar: "القالب الإبداعي يحتوي عناصر زخرفية قد تشوش التحليل.", en: "Creative templates contain decorative elements that may hurt parsing." },
  timeline: { ar: "القالب الزمني يعتمد على رسوميات قد تُتجاهَل في ATS.", en: "Timeline template relies on graphics that ATS may skip." },
};

const tokenize = (s: string) =>
  (s.toLowerCase().match(/[\p{L}\p{N}+#.]{2,}/gu) || []).filter((w) => w.length > 2);

export function runLocalATS(cv: CVData, jobDesc?: string): ATSLocalReport {
  const issues: ATSLocalIssue[] = [];
  const lang = cv.lang;
  const ar = lang === "ar";
  const c = cv.contact;

  // Contact basics
  if (!c.email) issues.push({ level: "error", section: "summary", message: ar ? "البريد الإلكتروني مفقود — حقل أساسي لأي ATS." : "Email is missing — required by every ATS." });
  if (!c.phone) issues.push({ level: "warn", section: "summary", message: ar ? "رقم الهاتف مفقود." : "Phone number is missing." });
  if (!c.location) issues.push({ level: "info", section: "summary", message: ar ? "الموقع مفقود — يساعد في الفلترة الجغرافية." : "Location missing — used by geographic filters." });
  if (!c.jobTitle) issues.push({ level: "warn", section: "summary", message: ar ? "المسمى الوظيفي مفقود — يستخدم لمطابقة الإعلان." : "Job title missing — matches the job posting." });
  if (!c.summary || c.summary.length < 80) issues.push({ level: "warn", section: "summary", message: ar ? "النبذة قصيرة جداً (أقل من 80 حرفاً)." : "Summary is too short (< 80 chars)." });

  // Sections
  if (cv.experience.length === 0) issues.push({ level: "error", section: "experience", message: ar ? "لا توجد خبرات — معظم ATS يرفض السير الذاتية بدون خبرة." : "No experience — most ATS reject CVs without experience." });
  cv.experience.forEach((e, i) => {
    if (!e.startDate) issues.push({ level: "warn", section: "experience", message: ar ? `تجربة #${i + 1} بدون تاريخ بداية.` : `Experience #${i + 1} has no start date.` });
    if (!e.company) issues.push({ level: "warn", section: "experience", message: ar ? `تجربة #${i + 1} بدون اسم الشركة.` : `Experience #${i + 1} has no company name.` });
    if (!e.description || e.description.length < 40) issues.push({ level: "info", section: "experience", message: ar ? `تجربة #${i + 1} وصفها قصير.` : `Experience #${i + 1} description is short.` });
  });
  if (cv.education.length === 0) issues.push({ level: "info", section: "education", message: ar ? "لا توجد بيانات تعليم." : "No education entries." });
  if (cv.skills.length < 5) issues.push({ level: "warn", section: "skills", message: ar ? "أقل من 5 مهارات — أضف كلمات مفتاحية أكثر." : "Fewer than 5 skills — add more keywords." });

  // Template risk
  const risk = RISKY_TEMPLATES[cv.template];
  if (risk) issues.push({ level: "warn", message: ar ? risk.ar : risk.en });

  // Photo in ATS template
  if (cv.template === "ats" && cv.contact.photo) {
    issues.push({ level: "info", section: "summary", message: ar ? "الصور قد تتجاهلها أنظمة ATS." : "Photos are typically ignored by ATS." });
  }

  // Long single bullets in experience
  cv.experience.forEach((e, i) => {
    const lines = (e.description || "").split(/\n+/).filter(Boolean);
    if (lines.length === 1 && (e.description || "").length > 400) {
      issues.push({ level: "info", section: "experience", message: ar ? `تجربة #${i + 1}: قسّم الوصف إلى نقاط قصيرة لقراءة أفضل من ATS.` : `Experience #${i + 1}: split into short bullet points for ATS readability.` });
    }
  });

  // Missing keywords from JD
  let missingKeywords: string[] = [];
  if (jobDesc && jobDesc.trim()) {
    const cvBag = new Set(tokenize([c.summary, ...cv.experience.map((e) => `${e.position} ${e.description}`), ...cv.skills.map((s) => s.name)].join(" ")));
    const jdTokens = Array.from(new Set(tokenize(jobDesc))).filter((t) => t.length > 3);
    missingKeywords = jdTokens.filter((t) => !cvBag.has(t)).slice(0, 12);
    if (missingKeywords.length > 0) {
      issues.push({ level: "warn", section: "skills", message: (ar ? "كلمات مفتاحية من الوصف الوظيفي غير موجودة: " : "Keywords from the job description are missing: ") + missingKeywords.slice(0, 6).join("، ") });
    }
  }

  // Score: start at 100, subtract by severity
  let score = 100;
  for (const i of issues) score -= i.level === "error" ? 18 : i.level === "warn" ? 7 : 2;
  score = Math.max(0, Math.min(100, score));

  return { score, issues, missingKeywords };
}
