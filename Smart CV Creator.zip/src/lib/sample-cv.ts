import type { CVData, Lang } from "./cv-types";

export function sampleCV(lang: Lang = "ar"): CVData {
  const ar = lang === "ar";
  return {
    id: "sample",
    name: "sample",
    lang,
    template: "modern",
    contact: {
      fullName: ar ? "سارة الأحمد" : "Sarah Anderson",
      jobTitle: ar ? "مهندسة برمجيات أولى" : "Senior Software Engineer",
      email: "sarah@example.com",
      phone: "+1 555 123 4567",
      location: ar ? "الرياض، السعودية" : "San Francisco, CA",
      website: "sarah.dev",
      linkedin: "linkedin.com/in/sarah",
      summary: ar
        ? "مهندسة برمجيات بخبرة 8 سنوات في بناء تطبيقات ويب قابلة للتوسع، متخصصة في React وNode.js والبنى السحابية، مع شغف بقيادة الفرق التقنية وتحسين الأداء."
        : "Software engineer with 8+ years building scalable web applications. Expert in React, Node.js, and cloud architecture. Passionate about leading technical teams and shipping performant products.",
    },
    experience: [
      {
        id: "e1",
        position: ar ? "مهندسة برمجيات أولى" : "Senior Software Engineer",
        company: "TechCorp",
        location: ar ? "الرياض" : "Remote",
        startDate: "2022-01",
        endDate: "",
        current: true,
        description: ar
          ? "• قيادة فريق من 6 مهندسين لبناء منصة SaaS تخدم 500 ألف مستخدم.\n• تحسين زمن الاستجابة بنسبة 60% عبر إعادة هيكلة الواجهة الخلفية.\n• إطلاق 12 ميزة رئيسية ساهمت بزيادة الإيرادات 35%."
          : "• Led team of 6 engineers building SaaS platform serving 500K users.\n• Improved API response time by 60% via backend refactor.\n• Shipped 12 major features driving 35% revenue growth.",
      },
      {
        id: "e2",
        position: ar ? "مهندسة برمجيات" : "Software Engineer",
        company: "StartupHub",
        location: ar ? "جدة" : "New York, NY",
        startDate: "2019-03",
        endDate: "2021-12",
        description: ar
          ? "• بناء تطبيقات React عالية الأداء.\n• تطوير واجهات REST وGraphQL.\n• إرشاد 3 مهندسين مبتدئين."
          : "• Built high-performance React applications.\n• Developed REST and GraphQL APIs.\n• Mentored 3 junior engineers.",
      },
    ],
    education: [
      {
        id: "ed1",
        degree: ar ? "بكالوريوس علوم الحاسب" : "B.Sc. Computer Science",
        institution: ar ? "جامعة الملك سعود" : "Stanford University",
        location: ar ? "الرياض" : "Stanford, CA",
        startDate: "2015-09",
        endDate: "2019-06",
        gpa: "3.9 / 4.0",
      },
    ],
    skills: [
      { id: "s1", name: "React", level: 5 },
      { id: "s2", name: "TypeScript", level: 5 },
      { id: "s3", name: "Node.js", level: 4 },
      { id: "s4", name: "AWS", level: 4 },
      { id: "s5", name: "PostgreSQL", level: 4 },
      { id: "s6", name: "Docker", level: 4 },
      { id: "s7", name: "GraphQL", level: 4 },
      { id: "s8", name: ar ? "قيادة فرق" : "Team Leadership", level: 5 },
    ],
    certificates: [
      { id: "c1", name: "AWS Certified Solutions Architect", issuer: "Amazon", date: "2023-05" },
    ],
    projects: [
      {
        id: "p1",
        name: ar ? "منصة التحليلات الذكية" : "Analytics Platform",
        role: ar ? "قائدة المشروع" : "Tech Lead",
        date: "2024",
        description: ar
          ? "منصة تحليلات في الوقت الفعلي تعالج 2 مليون حدث يوميًا."
          : "Real-time analytics platform processing 2M events daily.",
      },
    ],
    courses: [],
    awards: [],
    languages: [
      { id: "l1", name: ar ? "العربية" : "Arabic", proficiency: "native" },
      { id: "l2", name: ar ? "الإنجليزية" : "English", proficiency: "fluent" },
    ],
    custom: [],
    sectionOrder: ["summary", "experience", "education", "skills", "projects", "certificates", "languages"],
    accentColor: "#1e3a5f",
    updatedAt: Date.now(),
  };
}
