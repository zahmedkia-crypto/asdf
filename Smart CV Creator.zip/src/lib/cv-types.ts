export type Lang = "ar" | "en";

export interface ContactInfo {
  fullName: string;
  jobTitle: string;
  email: string;
  phone: string;
  location: string;
  website?: string;
  linkedin?: string;
  summary: string;
  photo?: string; // base64 data URL
}

export interface Experience {
  id: string;
  position: string;
  company: string;
  location?: string;
  startDate: string;
  endDate: string;
  current?: boolean;
  description: string;
}

export interface Education {
  id: string;
  degree: string;
  institution: string;
  location?: string;
  startDate: string;
  endDate: string;
  gpa?: string;
  description?: string;
}

export interface Skill {
  id: string;
  name: string;
  level?: number; // 1-5
}

export interface Certificate {
  id: string;
  name: string;
  issuer: string;
  date: string;
  credentialId?: string;
  url?: string;
  logo?: string; // base64 data URL
}

export interface Project {
  id: string;
  name: string;
  role?: string;
  date?: string;
  url?: string;
  description: string;
  logo?: string; // base64 data URL
}

export interface Course {
  id: string;
  name: string;
  provider: string;
  date: string;
  url?: string;
}

export interface Award {
  id: string;
  name: string;
  issuer: string;
  date: string;
  description?: string;
}

export interface Language {
  id: string;
  name: string;
  proficiency: "basic" | "conversational" | "fluent" | "native";
}

export interface CustomSection {
  id: string;
  title: string;
  items: { id: string; title: string; subtitle?: string; date?: string; description?: string }[];
}

export type SectionKey =
  | "summary"
  | "experience"
  | "education"
  | "skills"
  | "certificates"
  | "projects"
  | "courses"
  | "awards"
  | "languages"
  | `custom:${string}`;

export interface CVData {
  id: string;
  name: string; // CV name
  lang: Lang;
  template: TemplateId;
  contact: ContactInfo;
  experience: Experience[];
  education: Education[];
  skills: Skill[];
  certificates: Certificate[];
  projects: Project[];
  courses: Course[];
  awards: Award[];
  languages: Language[];
  custom: CustomSection[];
  sectionOrder: SectionKey[];
  lastATSScore?: number;
  accentColor?: string; // hex
  showQR?: boolean;
  updatedAt: number;
}

export type TemplateId =
  | "classic"
  | "modern"
  | "elegant"
  | "minimal"
  | "creative"
  | "ats"
  | "executive"
  | "tech"
  | "timeline"
  | "compact"
  | "twocol";

export const TEMPLATES: { id: TemplateId; nameAr: string; nameEn: string; type: string }[] = [
  { id: "classic", nameAr: "الكلاسيكي", nameEn: "Classic", type: "Chronological" },
  { id: "modern", nameAr: "العصري", nameEn: "Modern", type: "Combination" },
  { id: "elegant", nameAr: "الأنيق", nameEn: "Elegant", type: "Chronological" },
  { id: "minimal", nameAr: "البسيط", nameEn: "Minimal", type: "Functional" },
  { id: "creative", nameAr: "الإبداعي", nameEn: "Creative", type: "Combination" },
  { id: "ats", nameAr: "متوافق مع ATS", nameEn: "ATS-Friendly", type: "ATS" },
  { id: "executive", nameAr: "التنفيذي", nameEn: "Executive", type: "Senior" },
  { id: "tech", nameAr: "التقني", nameEn: "Tech", type: "Developer" },
  { id: "timeline", nameAr: "الزمني", nameEn: "Timeline", type: "Chronological" },
  { id: "compact", nameAr: "المُكثّف", nameEn: "Compact", type: "Single-page" },
  { id: "twocol", nameAr: "العمودين", nameEn: "Two Column", type: "Combination" },
];

export const ACCENT_COLORS = [
  "#1e3a5f", "#7c2d92", "#0d7a5f", "#c9a14a", "#e85d3a",
  "#3b82f6", "#dc2626", "#0891b2", "#7c3aed", "#111111",
];

export function emptyCV(lang: Lang = "ar"): CVData {
  return {
    id: crypto.randomUUID(),
    name: lang === "ar" ? "سيرتي الذاتية" : "My CV",
    lang,
    template: "modern",
    contact: {
      fullName: "",
      jobTitle: "",
      email: "",
      phone: "",
      location: "",
      summary: "",
    },
    experience: [],
    education: [],
    skills: [],
    certificates: [],
    projects: [],
    courses: [],
    awards: [],
    languages: [],
    custom: [],
    sectionOrder: [
      "summary",
      "experience",
      "education",
      "skills",
      "certificates",
      "projects",
      "languages",
      "courses",
      "awards",
    ],
    updatedAt: Date.now(),
  };
}
