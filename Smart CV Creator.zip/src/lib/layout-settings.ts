import type { CVData, TemplateId } from "./cv-types";

/** Per-section typography override. "inherit" = use the template/global default. */
export type AlignOption = "inherit" | "start" | "justify" | "center";
export type HyphensOption = "inherit" | "auto" | "manual" | "none";
export type TextJustifyOption = "inherit" | "inter-word" | "auto" | "distribute" | "none";

export interface SectionTypography {
  /** text-align */
  align: AlignOption;
  /** hyphens for Latin (LTR) content */
  hyphensLatin: HyphensOption;
  /** hyphens for Arabic (RTL) content — recommend "manual" or "none" to preserve ligatures */
  hyphensArabic: HyphensOption;
  /** text-justify algorithm */
  textJustify: TextJustifyOption;
}

export const SECTION_KEYS = [
  "summary",
  "experience",
  "education",
  "skills",
  "projects",
  "certificates",
  "courses",
  "awards",
  "languages",
] as const;
export type SectionKey = typeof SECTION_KEYS[number];

/** Group similar sections so they share typography by default. */
export type SectionGroupKey = "summary" | "history" | "lists";
export const SECTION_GROUPS: Record<SectionGroupKey, SectionKey[]> = {
  summary: ["summary"],
  history: ["experience", "education", "projects", "courses", "awards", "certificates"],
  lists: ["skills", "languages"],
};
export const GROUP_OF: Record<SectionKey, SectionGroupKey> = (() => {
  const out = {} as Record<SectionKey, SectionGroupKey>;
  (Object.keys(SECTION_GROUPS) as SectionGroupKey[]).forEach((g) =>
    SECTION_GROUPS[g].forEach((k) => (out[k] = g))
  );
  return out;
})();

export const DEFAULT_SECTION_TYPO: SectionTypography = {
  align: "inherit",
  hyphensLatin: "inherit",
  hyphensArabic: "inherit",
  textJustify: "inherit",
};

export interface TemplateOverride {
  sectionTypography?: Partial<Record<SectionKey, SectionTypography>>;
  sectionGroups?: Partial<Record<SectionGroupKey, SectionTypography>>;
  /** Preview direction saved per-template so switching templates restores it. */
  previewDir?: "auto" | "rtl" | "ltr";
}

export type ExportOptimizeLevel = "off" | "standard" | "aggressive";

export interface LayoutSettings {
  maxSummary: number;
  maxSkills: number;
  maxExperienceItemChars: number;
  experiencePageBreakThreshold: number;
  autoFixOnExport: boolean;
  /** Stronger pre-export pass: tighter pagebreaks, widow control, force keepLines everywhere. */
  exportOptimizeLevel: ExportOptimizeLevel;
  sectionTypography: Partial<Record<SectionKey, SectionTypography>>;
  sectionGroups: Partial<Record<SectionGroupKey, SectionTypography>>;
  templateOverrides: Partial<Record<TemplateId, TemplateOverride>>;
}

const KEY = "cv:layoutSettings";

export const DEFAULT_LAYOUT: LayoutSettings = {
  maxSummary: 600,
  maxSkills: 24,
  maxExperienceItemChars: 700,
  experiencePageBreakThreshold: 1800,
  autoFixOnExport: true,
  exportOptimizeLevel: "standard",
  sectionTypography: {},
  sectionGroups: {},
  templateOverrides: {},
};

/** Read the per-template preview direction. */
export function getTemplatePreviewDir(s: LayoutSettings, template: TemplateId | undefined): "auto" | "rtl" | "ltr" {
  if (!template) return "auto";
  return s.templateOverrides[template]?.previewDir ?? "auto";
}

/** Write the per-template preview direction (returns new settings). */
export function setTemplatePreviewDir(s: LayoutSettings, template: TemplateId | undefined, dir: "auto" | "rtl" | "ltr"): LayoutSettings {
  if (!template) return s;
  const next: LayoutSettings = { ...s, templateOverrides: { ...s.templateOverrides } };
  const cur = next.templateOverrides[template] ?? {};
  next.templateOverrides[template] = { ...cur, previewDir: dir };
  return next;
}

/** Merge two SectionTypography records — `over` wins when its value is not "inherit". */
function mergeTypo(base: SectionTypography, over?: SectionTypography): SectionTypography {
  if (!over) return base;
  return {
    align: over.align !== "inherit" ? over.align : base.align,
    hyphensLatin: over.hyphensLatin !== "inherit" ? over.hyphensLatin : base.hyphensLatin,
    hyphensArabic: over.hyphensArabic !== "inherit" ? over.hyphensArabic : base.hyphensArabic,
    textJustify: over.textJustify !== "inherit" ? over.textJustify : base.textJustify,
  };
}

/** Resolve effective typography for one section, walking template > base > group > section. */
export function resolveSectionTypography(
  s: LayoutSettings,
  template: TemplateId | undefined,
  key: SectionKey
): SectionTypography {
  const group = GROUP_OF[key];
  const tpl = template ? s.templateOverrides[template] : undefined;
  let cur: SectionTypography = { ...DEFAULT_SECTION_TYPO };
  cur = mergeTypo(cur, s.sectionGroups[group]);
  cur = mergeTypo(cur, tpl?.sectionGroups?.[group]);
  cur = mergeTypo(cur, s.sectionTypography[key]);
  cur = mergeTypo(cur, tpl?.sectionTypography?.[key]);
  return cur;
}

function isDefaultTypo(t: SectionTypography) {
  return t.align === "inherit" && t.hyphensLatin === "inherit" && t.hyphensArabic === "inherit" && t.textJustify === "inherit";
}

/** Build a scoped <style> string applying resolved typography per section. */
export function typographyCSS(s: LayoutSettings, template?: TemplateId): string {
  const rules: string[] = [];
  for (const key of SECTION_KEYS) {
    const t = resolveSectionTypography(s, template, key);
    if (isDefaultTypo(t)) continue;
    const decl: string[] = [];
    if (t.align !== "inherit") decl.push(`text-align:${t.align} !important`);
    if (t.textJustify !== "inherit") decl.push(`text-justify:${t.textJustify} !important`);
    const ltrDecl = [...decl];
    const rtlDecl = [...decl];
    if (t.hyphensLatin !== "inherit") {
      ltrDecl.push(`hyphens:${t.hyphensLatin} !important`, `-webkit-hyphens:${t.hyphensLatin} !important`);
    }
    if (t.hyphensArabic !== "inherit") {
      rtlDecl.push(`hyphens:${t.hyphensArabic} !important`, `-webkit-hyphens:${t.hyphensArabic} !important`);
      if (t.hyphensArabic === "manual" || t.hyphensArabic === "none") {
        rtlDecl.push("word-break:normal !important", "overflow-wrap:normal !important");
      }
    }
    const sel = `.cv-page section[data-cv-section="${key}"]`;
    const targets = `${sel}, ${sel} p, ${sel} li, ${sel} .cv-summary`;
    if (ltrDecl.length) rules.push(`.cv-page[dir="ltr"] :is(${targets}){${ltrDecl.join(";")}}`);
    if (rtlDecl.length) rules.push(`.cv-page[dir="rtl"] :is(${targets}){${rtlDecl.join(";")}}`);
  }
  return rules.join("\n");
}

/** Detect sections where Arabic justify + auto-hyphens would break Arabic words. */
export function validateArabicTypography(
  s: LayoutSettings,
  template: TemplateId | undefined,
  sectionsInUse: SectionKey[]
): SectionKey[] {
  const bad: SectionKey[] = [];
  for (const k of sectionsInUse) {
    const t = resolveSectionTypography(s, template, k);
    if ((t.align === "justify" || t.textJustify === "distribute") && t.hyphensArabic === "auto") bad.push(k);
  }
  return bad;
}

/** Force Arabic hyphens to "manual" for the offending sections, written into the template scope. */
export function autoFixArabicTypography(
  s: LayoutSettings,
  template: TemplateId | undefined,
  offenders: SectionKey[]
): LayoutSettings {
  if (!template || offenders.length === 0) return s;
  const next: LayoutSettings = { ...s, templateOverrides: { ...s.templateOverrides } };
  const cur = next.templateOverrides[template] ?? {};
  const sec: Partial<Record<SectionKey, SectionTypography>> = { ...(cur.sectionTypography ?? {}) };
  for (const k of offenders) {
    const prev = sec[k];
    sec[k] = {
      align: prev?.align ?? "inherit",
      hyphensLatin: prev?.hyphensLatin ?? "inherit",
      textJustify: prev?.textJustify ?? "inherit",
      hyphensArabic: "manual",
    };
  }
  next.templateOverrides[template] = { ...cur, sectionTypography: sec };
  return next;
}

export function getLayoutSettings(): LayoutSettings {
  if (typeof localStorage === "undefined") return DEFAULT_LAYOUT;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_LAYOUT;
    return { ...DEFAULT_LAYOUT, ...(JSON.parse(raw) as Partial<LayoutSettings>) };
  } catch {
    return DEFAULT_LAYOUT;
  }
}

export function setLayoutSettings(s: LayoutSettings) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch { /* ignore */ }
}

/** Trim a paragraph at the nearest sentence boundary <= max chars. */
function smartTrim(text: string, max: number): string {
  const t = text.trim();
  if (t.length <= max) return t;
  const slice = t.slice(0, max);
  const punct = Math.max(
    slice.lastIndexOf("."),
    slice.lastIndexOf("!"),
    slice.lastIndexOf("?"),
    slice.lastIndexOf("؟"),
    slice.lastIndexOf("۔")
  );
  if (punct > max * 0.6) return slice.slice(0, punct + 1).trim();
  const sp = slice.lastIndexOf(" ");
  return (sp > max * 0.6 ? slice.slice(0, sp) : slice).trim() + "…";
}

export interface AutoFixReport {
  changed: boolean;
  notes: string[];
  cv: CVData;
}

export function autoFixCV(cv: CVData, s: LayoutSettings, lang: "ar" | "en"): AutoFixReport {
  const notes: string[] = [];
  let changed = false;
  const next: CVData = JSON.parse(JSON.stringify(cv));

  if (next.contact.summary && next.contact.summary.length > s.maxSummary) {
    const before = next.contact.summary.length;
    next.contact.summary = smartTrim(next.contact.summary, s.maxSummary);
    changed = true;
    notes.push(
      lang === "ar"
        ? `تم تقصير النبذة من ${before} إلى ${next.contact.summary.length} حرفاً`
        : `Summary trimmed ${before} → ${next.contact.summary.length} chars`
    );
  }

  if (next.skills.length > s.maxSkills) {
    const before = next.skills.length;
    next.skills = [...next.skills]
      .map((sk, i) => ({ sk, i, lvl: sk.level ?? 0 }))
      .sort((a, b) => b.lvl - a.lvl || a.i - b.i)
      .slice(0, s.maxSkills)
      .sort((a, b) => a.i - b.i)
      .map((x) => x.sk);
    changed = true;
    notes.push(
      lang === "ar"
        ? `تم إبقاء أهم ${s.maxSkills} مهارة من أصل ${before}`
        : `Kept top ${s.maxSkills} of ${before} skills`
    );
  }

  next.experience = next.experience.map((e, idx) => {
    if ((e.description || "").length > s.maxExperienceItemChars) {
      const before = e.description.length;
      const trimmed = smartTrim(e.description, s.maxExperienceItemChars);
      notes.push(
        lang === "ar"
          ? `تم تقصير وصف تجربة #${idx + 1} (${before} → ${trimmed.length})`
          : `Experience #${idx + 1} trimmed (${before} → ${trimmed.length})`
      );
      changed = true;
      return { ...e, description: trimmed };
    }
    return e;
  });

  if (changed) next.updatedAt = Date.now();
  return { changed, notes, cv: next };
}
