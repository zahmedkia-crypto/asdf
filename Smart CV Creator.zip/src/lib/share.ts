import { toast } from "sonner";
import { tr } from "@/lib/i18n";
import type { Lang } from "@/lib/cv-types";

export async function shareFile(file: File, title: string, lang: Lang) {
  // Web Share API Level 2
  const nav = navigator as Navigator & {
    canShare?: (data: ShareData) => boolean;
    share?: (data: ShareData) => Promise<void>;
  };
  if (nav.canShare && nav.share && nav.canShare({ files: [file] })) {
    try {
      await nav.share({ files: [file], title, text: title });
      return true;
    } catch (e) {
      // user cancelled — silent
      const msg = e instanceof Error ? e.message : "";
      if (!/abort|cancel/i.test(msg)) toast.error(tr("aiError", lang));
      return false;
    }
  }
  // Fallback: download the file
  const url = URL.createObjectURL(file);
  const a = document.createElement("a");
  a.href = url;
  a.download = file.name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  toast.message(tr("shareUnsupported", lang));
  return false;
}
