import { useEffect, useState, useCallback } from "react";
import type { CVData } from "./cv-types";
import { emptyCV } from "./cv-types";

const KEY_LIST = "cv_list_v1";
const KEY_CURRENT = "cv_current_id_v1";
const KEY_PROFILE = "cv_profile_v1";
const KEY_LANG = "cv_lang_v1";
const KEY_THEME = "cv_theme_v1";
const KEY_BACKUP = "cv_backup_v1";

export function snapshotBackup(cv: CVData, reason: string = "auto") {
  try {
    localStorage.setItem(
      KEY_BACKUP,
      JSON.stringify({ at: Date.now(), reason, cv })
    );
  } catch { /* quota — silent */ }
}
export function getBackup(): { at: number; reason: string; cv: CVData } | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY_BACKUP);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}
export function clearBackup() {
  try { localStorage.removeItem(KEY_BACKUP); } catch { /* */ }
}


export function duplicateCV(id: string): CVData | null {
  const orig = getCV(id);
  if (!orig) return null;
  const copy: CVData = JSON.parse(JSON.stringify(orig));
  copy.id = crypto.randomUUID();
  copy.name = orig.name + (orig.lang === "ar" ? " (نسخة)" : " (Copy)");
  copy.updatedAt = Date.now();
  saveCV(copy);
  return copy;
}

export function exportAllCVs(): string {
  return JSON.stringify({ version: 1, exportedAt: Date.now(), cvs: listCVs() }, null, 2);
}

export function importAllCVs(json: string, mode: "merge" | "replace" = "merge"): number {
  const data = JSON.parse(json);
  const incoming: CVData[] = Array.isArray(data) ? data : data.cvs;
  if (!Array.isArray(incoming)) throw new Error("invalid");
  if (mode === "replace") {
    localStorage.setItem(KEY_LIST, JSON.stringify(incoming));
    return incoming.length;
  }
  const current = listCVs();
  const ids = new Set(current.map((c) => c.id));
  const merged = [...current];
  for (const cv of incoming) {
    if (ids.has(cv.id)) cv.id = crypto.randomUUID();
    merged.unshift(cv);
  }
  localStorage.setItem(KEY_LIST, JSON.stringify(merged));
  return incoming.length;
}

export function getTheme(): "light" | "dark" {
  if (typeof window === "undefined") return "light";
  return (localStorage.getItem(KEY_THEME) as "light" | "dark") || "light";
}
export function setTheme(t: "light" | "dark") {
  localStorage.setItem(KEY_THEME, t);
  document.documentElement.classList.toggle("dark", t === "dark");
}

export function listCVs(): CVData[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(KEY_LIST) || "[]");
  } catch {
    return [];
  }
}

export function saveCV(cv: CVData) {
  const list = listCVs();
  const idx = list.findIndex((c) => c.id === cv.id);
  cv.updatedAt = Date.now();
  if (idx >= 0) list[idx] = cv;
  else list.unshift(cv);
  localStorage.setItem(KEY_LIST, JSON.stringify(list));
}

export function deleteCV(id: string) {
  const list = listCVs().filter((c) => c.id !== id);
  localStorage.setItem(KEY_LIST, JSON.stringify(list));
}

export function getCurrentId(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(KEY_CURRENT);
}
export function setCurrentId(id: string) {
  localStorage.setItem(KEY_CURRENT, id);
}

export function getCV(id: string): CVData | null {
  return listCVs().find((c) => c.id === id) ?? null;
}

export function getProfile(): Partial<CVData["contact"]> {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(localStorage.getItem(KEY_PROFILE) || "{}");
  } catch {
    return {};
  }
}
export function saveProfile(p: Partial<CVData["contact"]>) {
  localStorage.setItem(KEY_PROFILE, JSON.stringify(p));
}

export function getLang(): "ar" | "en" {
  if (typeof window === "undefined") return "ar";
  return (localStorage.getItem(KEY_LANG) as "ar" | "en") || "ar";
}
export function setLang(l: "ar" | "en") {
  localStorage.setItem(KEY_LANG, l);
  document.documentElement.lang = l;
  document.documentElement.dir = l === "ar" ? "rtl" : "ltr";
}

export function useCV(id: string | null) {
  const [cv, setCv] = useState<CVData | null>(null);

  useEffect(() => {
    if (!id) return;
    const found = getCV(id);
    if (found) setCv(found);
  }, [id]);

  const update = useCallback((updater: (prev: CVData) => CVData) => {
    setCv((prev) => {
      if (!prev) return prev;
      const next = updater(prev);
      saveCV(next);
      return next;
    });
  }, []);

  return { cv, setCv, update };
}

export function useAppLang() {
  const [lang, setLangState] = useState<"ar" | "en">("ar");
  useEffect(() => {
    const l = getLang();
    setLangState(l);
    setLang(l);
  }, []);
  const change = (l: "ar" | "en") => {
    setLang(l);
    setLangState(l);
  };
  return [lang, change] as const;
}

export function ensureCurrent(): string {
  let id = getCurrentId();
  if (id && getCV(id)) return id;
  const cv = emptyCV(getLang());
  saveCV(cv);
  setCurrentId(cv.id);
  return cv.id;
}

export const uid = () => crypto.randomUUID();
