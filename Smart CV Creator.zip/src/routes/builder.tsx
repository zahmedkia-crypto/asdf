import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ChevronRight, User, Briefcase, GraduationCap, Lightbulb, Award,
  FolderGit2, BookOpen, Trophy, Languages as LangIcon, Eye, Plus,
  FileEdit, Save, MoveVertical, LayoutGrid, Check, Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { CollapsibleSection } from "@/components/cv/CollapsibleSection";
import { ItemCard } from "@/components/cv/ItemCard";
import { AIButton } from "@/components/cv/AIButton";
import { PhotoField } from "@/components/cv/PhotoField";
import { LogoField } from "@/components/cv/LogoField";
import { SkillsSuggestDialog } from "@/components/cv/SkillsSuggestDialog";
import { InlineHint } from "@/components/cv/InlineHint";
import { CVUploadDialog } from "@/components/cv/CVUploadDialog";
import { useCV, getCurrentId, useAppLang, ensureCurrent, saveProfile, saveCV, getBackup, clearBackup, snapshotBackup } from "@/lib/cv-store";
import type { CVData } from "@/lib/cv-types";
import { callAI } from "@/lib/ai";
import { tr } from "@/lib/i18n";
import { toast } from "sonner";

export const Route = createFileRoute("/builder")({
  head: () => ({
    meta: [
      { title: "منشئ السيرة الذاتية" },
      { name: "description", content: "أضف بياناتك الشخصية والخبرات والمهارات وأنشئ سيرة ذاتية احترافية." },
    ],
  }),
  component: BuilderPage,
});

const uid = () => crypto.randomUUID();

function BuilderPage() {
  const [lang] = useAppLang();
  const navigate = useNavigate();
  const [id, setId] = useState<string | null>(null);

  useEffect(() => {
    setId(getCurrentId() || ensureCurrent());
  }, []);

  const { cv, update } = useCV(id);

  // Offer to restore last auto-backup if it differs from current and is recent
  useEffect(() => {
    if (!cv) return;
    const b = getBackup();
    if (!b) return;
    const recent = Date.now() - b.at < 1000 * 60 * 60 * 24; // 24h
    if (!recent || b.cv.id !== cv.id) return;
    if (b.cv.updatedAt <= cv.updatedAt) { clearBackup(); return; }
    toast(lang === "ar" ? "تم العثور على نسخة احتياطية أحدث" : "Newer backup found", {
      duration: 10000,
      action: {
        label: lang === "ar" ? "استعادة" : "Restore",
        onClick: () => { update(() => b.cv); clearBackup(); toast.success(lang === "ar" ? "تم الاستعادة" : "Restored"); },
      },
      cancel: { label: lang === "ar" ? "تجاهل" : "Dismiss", onClick: () => clearBackup() },
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cv?.id]);

  // Periodic safety snapshot of current edits (every 10s if changed)
  useEffect(() => {
    if (!cv) return;
    const t = setInterval(() => { snapshotBackup(cv, "autosave"); }, 10000);
    return () => clearInterval(t);
  }, [cv]);


  if (!cv) return <div className="min-h-screen grid place-items-center text-muted-foreground">...</div>;

  const setContact = (patch: Partial<CVData["contact"]>) => {
    update((c) => ({ ...c, contact: { ...c.contact, ...patch } }));
    saveProfile({ ...cv.contact, ...patch });
  };

  const bulletize = async (text: string, ctx: string, apply: (v: string) => void) => {
    if (!text || text.trim().length < 15) {
      toast.error(lang === "ar" ? "اكتب وصفاً أولاً" : "Write a description first");
      return;
    }
    try {
      const out = await callAI("bullets", `${ctx}\n${text}`, lang);
      apply(out.trim());
      toast.success(lang === "ar" ? "تم!" : "Done!");
    } catch (e) {
      const m = e instanceof Error ? e.message : "";
      toast.error(m === "rate_limit" ? tr("rateLimit", lang) : m === "credits" ? tr("paymentRequired", lang) : tr("aiError", lang));
    }
  };

  return (
    <div className="min-h-[100dvh] bg-gradient-subtle pb-32 safe-x">
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border px-3 sm:px-4 py-3 pt-safe safe-x flex items-center gap-1.5 sm:gap-2">
        <button onClick={() => navigate({ to: "/" })} className="w-9 h-9 shrink-0 rounded-lg flex items-center justify-center hover:bg-muted">
          <ChevronRight className={`w-5 h-5 ${lang === "ar" ? "" : "rotate-180"}`} />
        </button>
        <div className="flex-1 min-w-0">
          <Input
            value={cv.name}
            onChange={(e) => update((c) => ({ ...c, name: e.target.value }))}
            className="h-8 border-0 px-1 font-bold text-sm bg-transparent focus-visible:bg-muted/40 w-full"
          />
        </div>
        <SaveBadge updatedAt={cv.updatedAt} lang={lang} />
        <Link to="/reorder" className="w-9 h-9 shrink-0 rounded-lg flex items-center justify-center hover:bg-muted text-primary" title={tr("reorder", lang)}>
          <MoveVertical className="w-4 h-4" />
        </Link>
        <Link to="/templates" className="w-9 h-9 shrink-0 rounded-lg flex items-center justify-center hover:bg-muted text-primary">
          <FileEdit className="w-4 h-4" />
        </Link>
      </header>

      <div className="px-3 sm:px-4 py-4 space-y-3 max-w-3xl mx-auto">


        <div className="flex justify-center">
          <CVUploadDialog
            lang={lang}
            current={cv}
            onApply={(next) => { saveCV(next); update(() => next); }}
          />
        </div>



        {/* Contact */}
        <CollapsibleSection title={tr("contact", lang)} defaultOpen icon={<User className="w-4 h-4 text-primary" />}>
          <PhotoField value={cv.contact.photo} lang={lang} onChange={(v) => setContact({ photo: v })} />
          <Field label={tr("fullName", lang)} value={cv.contact.fullName} onChange={(v) => setContact({ fullName: v })} />
          <Field label={tr("jobTitle", lang)} value={cv.contact.jobTitle} onChange={(v) => setContact({ jobTitle: v })} />
          <div className="grid grid-cols-2 gap-2">
            <Field label={tr("email", lang)} type="email" value={cv.contact.email} onChange={(v) => setContact({ email: v })} />
            <Field label={tr("phone", lang)} dir="ltr" value={cv.contact.phone} onChange={(v) => setContact({ phone: v })} />
          </div>
          <Field label={tr("location", lang)} value={cv.contact.location} onChange={(v) => setContact({ location: v })} />
          <div className="grid grid-cols-2 gap-2">
            <Field label={tr("website", lang)} dir="ltr" value={cv.contact.website || ""} onChange={(v) => setContact({ website: v })} />
            <Field label={tr("linkedin", lang)} dir="ltr" value={cv.contact.linkedin || ""} onChange={(v) => setContact({ linkedin: v })} />
          </div>
          {(cv.contact.linkedin || cv.contact.website) && (
            <label className="flex items-center gap-2 text-xs pt-1">
              <Checkbox checked={!!cv.showQR} onCheckedChange={(v) => update((c) => ({ ...c, showQR: !!v }))} />
              <span>{tr("showQR", lang)}</span>
              <span className="text-muted-foreground text-[10px]">— {tr("qrHint", lang)}</span>
            </label>
          )}
        </CollapsibleSection>

        {/* Summary */}
        <CollapsibleSection title={tr("summary", lang)} defaultOpen icon={<User className="w-4 h-4 text-primary" />}>
          <Textarea
            value={cv.contact.summary}
            onChange={(e) => setContact({ summary: e.target.value })}
            rows={5}
            placeholder={lang === "ar" ? "اكتب نبذة موجزة عن خبراتك وأهدافك..." : "Write a brief summary..."}
          />
          <div className="text-[10px] text-muted-foreground text-end -mt-1">
            {(cv.contact.summary || "").trim().split(/\s+/).filter(Boolean).length} {tr("words", lang)} · {(cv.contact.summary || "").length} {tr("chars", lang)}
          </div>
          <InlineHint text={cv.contact.summary} lang={lang} onApply={(v) => setContact({ summary: v })} />
          <div className="flex justify-end gap-1 -mt-1">
            <AIButton
              mode="suggest"
              prompt={`Write a 3-line professional CV summary for: ${cv.contact.jobTitle || cv.contact.fullName || "a professional"}`}
              lang={lang}
              onResult={(v) => setContact({ summary: v })}
              label={tr("suggest", lang)}
            />
            <AIButton
              mode="improve"
              prompt={cv.contact.summary || cv.contact.jobTitle}
              lang={lang}
              onResult={(v) => setContact({ summary: v })}
              label={tr("improve", lang)}
            />
          </div>
        </CollapsibleSection>

        {/* Experience */}
        <CollapsibleSection title={tr("experience", lang)} count={cv.experience.length} icon={<Briefcase className="w-4 h-4 text-primary" />}>
          {cv.experience.map((e) => (
            <ItemCard key={e.id} onDelete={() => update((c) => ({ ...c, experience: c.experience.filter((x) => x.id !== e.id) }))}>
              <Field label={tr("position", lang)} value={e.position} onChange={(v) => update((c) => ({ ...c, experience: c.experience.map((x) => x.id === e.id ? { ...x, position: v } : x) }))} />
              <Field label={tr("company", lang)} value={e.company} onChange={(v) => update((c) => ({ ...c, experience: c.experience.map((x) => x.id === e.id ? { ...x, company: v } : x) }))} />
              <Field label={tr("location", lang)} value={e.location || ""} onChange={(v) => update((c) => ({ ...c, experience: c.experience.map((x) => x.id === e.id ? { ...x, location: v } : x) }))} />
              <div className="grid grid-cols-2 gap-2">
                <Field label={tr("startDate", lang)} placeholder="2022/01" value={e.startDate} onChange={(v) => update((c) => ({ ...c, experience: c.experience.map((x) => x.id === e.id ? { ...x, startDate: v } : x) }))} />
                <Field label={tr("endDate", lang)} placeholder="2024/06" value={e.endDate} onChange={(v) => update((c) => ({ ...c, experience: c.experience.map((x) => x.id === e.id ? { ...x, endDate: v } : x) }))} disabled={e.current} />
              </div>
              <label className="flex items-center gap-2 text-xs">
                <Checkbox checked={!!e.current} onCheckedChange={(v) => update((c) => ({ ...c, experience: c.experience.map((x) => x.id === e.id ? { ...x, current: !!v, endDate: v ? "" : x.endDate } : x) }))} />
                {tr("current", lang)}
              </label>
              <Textarea rows={3} placeholder={tr("description", lang)} value={e.description} onChange={(ev) => update((c) => ({ ...c, experience: c.experience.map((x) => x.id === e.id ? { ...x, description: ev.target.value } : x) }))} />
              <InlineHint text={e.description} lang={lang} onApply={(v) => update((c) => ({ ...c, experience: c.experience.map((x) => x.id === e.id ? { ...x, description: v } : x) }))} />
              <div className="flex justify-end gap-1 -mt-1">
                <Button type="button" variant="ghost" size="sm" className="h-8 gap-1.5 text-gold hover:bg-gold/10" onClick={() => bulletize(e.description, `Position: ${e.position} at ${e.company}`, (v) => update((c) => ({ ...c, experience: c.experience.map((x) => x.id === e.id ? { ...x, description: v } : x) })))}>
                  <Sparkles className="w-3.5 h-3.5" /><span className="text-xs">{tr("bulletize", lang)}</span>
                </Button>
                <AIButton mode="improve" prompt={`Position: ${e.position} at ${e.company}\n${e.description}`} lang={lang} onResult={(v) => update((c) => ({ ...c, experience: c.experience.map((x) => x.id === e.id ? { ...x, description: v } : x) }))} />
              </div>
            </ItemCard>
          ))}
          <AddBtn label={tr("add", lang)} onClick={() => update((c) => ({ ...c, experience: [...c.experience, { id: uid(), position: "", company: "", startDate: "", endDate: "", description: "" }] }))} />
        </CollapsibleSection>

        {/* Education */}
        <CollapsibleSection title={tr("education", lang)} count={cv.education.length} icon={<GraduationCap className="w-4 h-4 text-primary" />}>
          {cv.education.map((e) => (
            <ItemCard key={e.id} onDelete={() => update((c) => ({ ...c, education: c.education.filter((x) => x.id !== e.id) }))}>
              <Field label={tr("degree", lang)} value={e.degree} onChange={(v) => update((c) => ({ ...c, education: c.education.map((x) => x.id === e.id ? { ...x, degree: v } : x) }))} />
              <Field label={tr("institution", lang)} value={e.institution} onChange={(v) => update((c) => ({ ...c, education: c.education.map((x) => x.id === e.id ? { ...x, institution: v } : x) }))} />
              <div className="grid grid-cols-2 gap-2">
                <Field label={tr("startDate", lang)} value={e.startDate} onChange={(v) => update((c) => ({ ...c, education: c.education.map((x) => x.id === e.id ? { ...x, startDate: v } : x) }))} />
                <Field label={tr("endDate", lang)} value={e.endDate} onChange={(v) => update((c) => ({ ...c, education: c.education.map((x) => x.id === e.id ? { ...x, endDate: v } : x) }))} />
              </div>
              <Field label={tr("gpa", lang)} value={e.gpa || ""} onChange={(v) => update((c) => ({ ...c, education: c.education.map((x) => x.id === e.id ? { ...x, gpa: v } : x) }))} />
            </ItemCard>
          ))}
          <AddBtn label={tr("add", lang)} onClick={() => update((c) => ({ ...c, education: [...c.education, { id: uid(), degree: "", institution: "", startDate: "", endDate: "" }] }))} />
        </CollapsibleSection>

        {/* Skills */}
        <CollapsibleSection title={tr("skills", lang)} count={cv.skills.length} icon={<Lightbulb className="w-4 h-4 text-primary" />}>
          <div className="flex justify-end -mt-1">
            <SkillsSuggestDialog
              lang={lang}
              defaultRole={cv.contact.jobTitle}
              existing={cv.skills.map((s) => s.name)}
              onAdd={(name) => update((c) => c.skills.some((x) => x.name.toLowerCase() === name.toLowerCase()) ? c : ({ ...c, skills: [...c.skills, { id: uid(), name, level: 4 }] }))}
            />
          </div>
          {cv.skills.map((s) => (
            <div key={s.id} className="flex gap-2 items-center">
              <Input value={s.name} onChange={(e) => update((c) => ({ ...c, skills: c.skills.map((x) => x.id === s.id ? { ...x, name: e.target.value } : x) }))} placeholder={tr("skillName", lang)} />
              <Select value={String(s.level || 3)} onValueChange={(v) => update((c) => ({ ...c, skills: c.skills.map((x) => x.id === s.id ? { ...x, level: parseInt(v) } : x) }))}>
                <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
                <SelectContent>{[1, 2, 3, 4, 5].map((n) => <SelectItem key={n} value={String(n)}>{"★".repeat(n)}</SelectItem>)}</SelectContent>
              </Select>
              <Button variant="ghost" size="sm" className="text-destructive h-9 w-9 p-0" onClick={() => update((c) => ({ ...c, skills: c.skills.filter((x) => x.id !== s.id) }))}>×</Button>
            </div>
          ))}
          <AddBtn label={tr("add", lang)} onClick={() => update((c) => ({ ...c, skills: [...c.skills, { id: uid(), name: "", level: 3 }] }))} />
        </CollapsibleSection>

        {/* Certificates */}
        <CollapsibleSection title={tr("certificates", lang)} count={cv.certificates.length} icon={<Award className="w-4 h-4 text-primary" />}>
          {cv.certificates.map((c) => (
            <ItemCard key={c.id} onDelete={() => update((cv) => ({ ...cv, certificates: cv.certificates.filter((x) => x.id !== c.id) }))}>
              <LogoField value={c.logo} lang={lang} onChange={(v) => update((cv) => ({ ...cv, certificates: cv.certificates.map((x) => x.id === c.id ? { ...x, logo: v } : x) }))} />
              <Field label={tr("certName", lang)} value={c.name} onChange={(v) => update((cv) => ({ ...cv, certificates: cv.certificates.map((x) => x.id === c.id ? { ...x, name: v } : x) }))} />
              <Field label={tr("issuer", lang)} value={c.issuer} onChange={(v) => update((cv) => ({ ...cv, certificates: cv.certificates.map((x) => x.id === c.id ? { ...x, issuer: v } : x) }))} />
              <div className="grid grid-cols-2 gap-2">
                <Field label={tr("date", lang)} value={c.date} onChange={(v) => update((cv) => ({ ...cv, certificates: cv.certificates.map((x) => x.id === c.id ? { ...x, date: v } : x) }))} />
                <Field label={tr("credentialId", lang)} value={c.credentialId || ""} onChange={(v) => update((cv) => ({ ...cv, certificates: cv.certificates.map((x) => x.id === c.id ? { ...x, credentialId: v } : x) }))} />
              </div>
              <Field label={tr("url", lang)} dir="ltr" value={c.url || ""} onChange={(v) => update((cv) => ({ ...cv, certificates: cv.certificates.map((x) => x.id === c.id ? { ...x, url: v } : x) }))} />
            </ItemCard>
          ))}
          <AddBtn label={tr("add", lang)} onClick={() => update((c) => ({ ...c, certificates: [...c.certificates, { id: uid(), name: "", issuer: "", date: "" }] }))} />
        </CollapsibleSection>

        {/* Projects */}
        <CollapsibleSection title={tr("projects", lang)} count={cv.projects.length} icon={<FolderGit2 className="w-4 h-4 text-primary" />}>
          {cv.projects.map((p) => (
            <ItemCard key={p.id} onDelete={() => update((c) => ({ ...c, projects: c.projects.filter((x) => x.id !== p.id) }))}>
              <LogoField value={p.logo} lang={lang} onChange={(v) => update((c) => ({ ...c, projects: c.projects.map((x) => x.id === p.id ? { ...x, logo: v } : x) }))} />
              <Field label={lang === "ar" ? "اسم المشروع" : "Project name"} value={p.name} onChange={(v) => update((c) => ({ ...c, projects: c.projects.map((x) => x.id === p.id ? { ...x, name: v } : x) }))} />
              <Field label={lang === "ar" ? "الدور" : "Role"} value={p.role || ""} onChange={(v) => update((c) => ({ ...c, projects: c.projects.map((x) => x.id === p.id ? { ...x, role: v } : x) }))} />
              <Textarea rows={3} placeholder={tr("description", lang)} value={p.description} onChange={(ev) => update((c) => ({ ...c, projects: c.projects.map((x) => x.id === p.id ? { ...x, description: ev.target.value } : x) }))} />
              <InlineHint text={p.description} lang={lang} onApply={(v) => update((c) => ({ ...c, projects: c.projects.map((x) => x.id === p.id ? { ...x, description: v } : x) }))} />
              <div className="flex justify-end gap-1 -mt-1">
                <Button type="button" variant="ghost" size="sm" className="h-8 gap-1.5 text-gold hover:bg-gold/10" onClick={() => bulletize(p.description, `Project: ${p.name}`, (v) => update((c) => ({ ...c, projects: c.projects.map((x) => x.id === p.id ? { ...x, description: v } : x) })))}>
                  <Sparkles className="w-3.5 h-3.5" /><span className="text-xs">{tr("bulletize", lang)}</span>
                </Button>
                <AIButton mode="improve" prompt={`${p.name}\n${p.description}`} lang={lang} onResult={(v) => update((c) => ({ ...c, projects: c.projects.map((x) => x.id === p.id ? { ...x, description: v } : x) }))} />
              </div>
            </ItemCard>
          ))}
          <AddBtn label={tr("add", lang)} onClick={() => update((c) => ({ ...c, projects: [...c.projects, { id: uid(), name: "", description: "" }] }))} />
        </CollapsibleSection>

        {/* Courses */}
        <CollapsibleSection title={tr("courses", lang)} count={cv.courses.length} icon={<BookOpen className="w-4 h-4 text-primary" />}>
          {cv.courses.map((co) => (
            <ItemCard key={co.id} onDelete={() => update((c) => ({ ...c, courses: c.courses.filter((x) => x.id !== co.id) }))}>
              <Field label={lang === "ar" ? "اسم الدورة" : "Course"} value={co.name} onChange={(v) => update((c) => ({ ...c, courses: c.courses.map((x) => x.id === co.id ? { ...x, name: v } : x) }))} />
              <div className="grid grid-cols-2 gap-2">
                <Field label={lang === "ar" ? "الجهة" : "Provider"} value={co.provider} onChange={(v) => update((c) => ({ ...c, courses: c.courses.map((x) => x.id === co.id ? { ...x, provider: v } : x) }))} />
                <Field label={tr("date", lang)} value={co.date} onChange={(v) => update((c) => ({ ...c, courses: c.courses.map((x) => x.id === co.id ? { ...x, date: v } : x) }))} />
              </div>
            </ItemCard>
          ))}
          <AddBtn label={tr("add", lang)} onClick={() => update((c) => ({ ...c, courses: [...c.courses, { id: uid(), name: "", provider: "", date: "" }] }))} />
        </CollapsibleSection>

        {/* Awards */}
        <CollapsibleSection title={tr("awards", lang)} count={cv.awards.length} icon={<Trophy className="w-4 h-4 text-primary" />}>
          {cv.awards.map((a) => (
            <ItemCard key={a.id} onDelete={() => update((c) => ({ ...c, awards: c.awards.filter((x) => x.id !== a.id) }))}>
              <Field label={lang === "ar" ? "اسم الجائزة" : "Award"} value={a.name} onChange={(v) => update((c) => ({ ...c, awards: c.awards.map((x) => x.id === a.id ? { ...x, name: v } : x) }))} />
              <div className="grid grid-cols-2 gap-2">
                <Field label={tr("issuer", lang)} value={a.issuer} onChange={(v) => update((c) => ({ ...c, awards: c.awards.map((x) => x.id === a.id ? { ...x, issuer: v } : x) }))} />
                <Field label={tr("date", lang)} value={a.date} onChange={(v) => update((c) => ({ ...c, awards: c.awards.map((x) => x.id === a.id ? { ...x, date: v } : x) }))} />
              </div>
            </ItemCard>
          ))}
          <AddBtn label={tr("add", lang)} onClick={() => update((c) => ({ ...c, awards: [...c.awards, { id: uid(), name: "", issuer: "", date: "" }] }))} />
        </CollapsibleSection>

        {/* Languages */}
        <CollapsibleSection title={tr("languages", lang)} count={cv.languages.length} icon={<LangIcon className="w-4 h-4 text-primary" />}>
          {cv.languages.map((l) => (
            <div key={l.id} className="flex gap-2">
              <Input value={l.name} onChange={(e) => update((c) => ({ ...c, languages: c.languages.map((x) => x.id === l.id ? { ...x, name: e.target.value } : x) }))} placeholder={tr("langName", lang)} />
              <Select value={l.proficiency} onValueChange={(v) => update((c) => ({ ...c, languages: c.languages.map((x) => x.id === l.id ? { ...x, proficiency: v as typeof l.proficiency } : x) }))}>
                <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="basic">{tr("basic", lang)}</SelectItem>
                  <SelectItem value="conversational">{tr("conversational", lang)}</SelectItem>
                  <SelectItem value="fluent">{tr("fluent", lang)}</SelectItem>
                  <SelectItem value="native">{tr("native", lang)}</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="ghost" size="sm" className="text-destructive h-9 w-9 p-0" onClick={() => update((c) => ({ ...c, languages: c.languages.filter((x) => x.id !== l.id) }))}>×</Button>
            </div>
          ))}
          <AddBtn label={tr("add", lang)} onClick={() => update((c) => ({ ...c, languages: [...c.languages, { id: uid(), name: "", proficiency: "fluent" }] }))} />
        </CollapsibleSection>

        {/* Custom Sections */}
        {cv.custom.map((sec) => (
          <CollapsibleSection key={sec.id} title={sec.title || tr("customSection", lang)} count={sec.items.length} icon={<LayoutGrid className="w-4 h-4 text-primary" />}>
            <Field
              label={tr("sectionTitle", lang)}
              value={sec.title}
              onChange={(v) => update((c) => ({ ...c, custom: c.custom.map((s) => s.id === sec.id ? { ...s, title: v } : s) }))}
            />
            {sec.items.map((it) => (
              <ItemCard key={it.id} onDelete={() => update((c) => ({ ...c, custom: c.custom.map((s) => s.id === sec.id ? { ...s, items: s.items.filter((x) => x.id !== it.id) } : s) }))}>
                <Field label={tr("itemTitle", lang)} value={it.title} onChange={(v) => update((c) => ({ ...c, custom: c.custom.map((s) => s.id === sec.id ? { ...s, items: s.items.map((x) => x.id === it.id ? { ...x, title: v } : x) } : s) }))} />
                <div className="grid grid-cols-2 gap-2">
                  <Field label={tr("subtitle", lang)} value={it.subtitle || ""} onChange={(v) => update((c) => ({ ...c, custom: c.custom.map((s) => s.id === sec.id ? { ...s, items: s.items.map((x) => x.id === it.id ? { ...x, subtitle: v } : x) } : s) }))} />
                  <Field label={tr("date", lang)} value={it.date || ""} onChange={(v) => update((c) => ({ ...c, custom: c.custom.map((s) => s.id === sec.id ? { ...s, items: s.items.map((x) => x.id === it.id ? { ...x, date: v } : x) } : s) }))} />
                </div>
                <Textarea rows={3} placeholder={tr("description", lang)} value={it.description || ""} onChange={(ev) => update((c) => ({ ...c, custom: c.custom.map((s) => s.id === sec.id ? { ...s, items: s.items.map((x) => x.id === it.id ? { ...x, description: ev.target.value } : x) } : s) }))} />
              </ItemCard>
            ))}
            <div className="flex gap-2">
              <AddBtn label={tr("add", lang)} onClick={() => update((c) => ({ ...c, custom: c.custom.map((s) => s.id === sec.id ? { ...s, items: [...s.items, { id: uid(), title: "" }] } : s) }))} />
              <Button type="button" variant="ghost" size="sm" className="text-destructive h-9" onClick={() => update((c) => ({ ...c, custom: c.custom.filter((s) => s.id !== sec.id), sectionOrder: c.sectionOrder.filter((k) => k !== `custom:${sec.id}`) }))}>{tr("delete", lang)}</Button>
            </div>
          </CollapsibleSection>
        ))}

        <Button
          variant="outline"
          className="w-full border-dashed h-11 text-primary"
          onClick={() => {
            const id = uid();
            update((c) => ({ ...c, custom: [...c.custom, { id, title: lang === "ar" ? "قسم جديد" : "New Section", items: [] }], sectionOrder: [...c.sectionOrder, `custom:${id}`] }));
          }}
        >
          <Plus className="w-4 h-4 ms-1" /> {tr("customSection", lang)}
        </Button>
      </div>

      {/* Sticky footer */}
      <div className="fixed bottom-0 inset-x-0 px-3 sm:px-4 py-3 pb-safe safe-x bg-background/95 backdrop-blur border-t border-border flex gap-2 z-20">
        <Button variant="outline" className="flex-1 h-11 min-w-0" onClick={() => { toast.success(lang === "ar" ? "تم الحفظ" : "Saved"); }}>
          <Save className="w-4 h-4 ms-1 shrink-0" /> <span className="truncate">{tr("save", lang)}</span>
        </Button>
        <Button onClick={() => navigate({ to: "/preview" })} className="flex-1 h-11 min-w-0 gradient-primary text-primary-foreground font-bold">
          <Eye className="w-4 h-4 ms-1 shrink-0" /> <span className="truncate">{tr("preview", lang)}</span>
        </Button>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, placeholder, type = "text", dir, disabled }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; type?: string; dir?: string; disabled?: boolean }) {
  return (
    <div className="space-y-1">
      <Label className="text-[11px] text-muted-foreground font-medium">{label}</Label>
      <Input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} type={type} dir={dir} disabled={disabled} className="h-9 text-sm" />
    </div>
  );
}

function AddBtn({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <Button type="button" variant="outline" size="sm" onClick={onClick} className="w-full border-dashed mt-1 h-9 text-primary hover:bg-primary/5">
      <Plus className="w-3.5 h-3.5 ms-1" /> {label}
    </Button>
  );
}

function SaveBadge({ updatedAt, lang }: { updatedAt: number; lang: "ar" | "en" }) {
  const [, force] = useState(0);
  useEffect(() => {
    const t = setInterval(() => force((n) => n + 1), 5000);
    return () => clearInterval(t);
  }, []);
  const diff = Math.max(0, Math.floor((Date.now() - updatedAt) / 1000));
  const label =
    diff < 5 ? (lang === "ar" ? "تم الحفظ" : "Saved")
    : diff < 60 ? (lang === "ar" ? `قبل ${diff} ث` : `${diff}s ago`)
    : diff < 3600 ? (lang === "ar" ? `قبل ${Math.floor(diff / 60)} د` : `${Math.floor(diff / 60)}m ago`)
    : (lang === "ar" ? "محفوظ" : "Saved");
  return (
    <div className="flex items-center gap-1 text-[10px] text-success font-medium px-2 py-1 rounded-full bg-success/10 whitespace-nowrap" title={tr("savedAgo", lang)}>
      <Check className="w-3 h-3" />
      <span>{label}</span>
    </div>
  );
}
