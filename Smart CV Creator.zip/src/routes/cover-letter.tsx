import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronRight, Sparkles, Loader2, Copy, Check, Mail, Share2, Download, FileType, Eye, Wand2, Gauge, Settings2, RotateCcw, Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Progress } from "@/components/ui/progress";
import { useAppLang, ensureCurrent, getCV } from "@/lib/cv-store";
import { tr } from "@/lib/i18n";
import { callAI, tryParseJSON } from "@/lib/ai";
import { shareFile } from "@/lib/share";
import { toast } from "sonner";
import type { CVData, Lang } from "@/lib/cv-types";
import { LETTER_TEMPLATES, LetterRenderer, defaultGreeting, defaultClosing, PAPER_DIMS, MARGIN_MM, type LetterTemplateId, type PaperSize, type MarginPreset } from "@/components/cover-letter/templates";
import { WordPreview, letterAlignment, formatLetterDate, formatLetterSubject, type WordPreviewProps } from "@/components/cover-letter/WordPreview";

type Tone = "professional" | "friendly" | "creative";
const ACCENTS = ["#0F766E", "#1D4ED8", "#7C3AED", "#B91C1C", "#EA580C", "#0EA5E9", "#16A34A", "#111827"];
const STORAGE_KEY = "cl:settings:v2";

interface Settings {
  templateId: LetterTemplateId;
  accent: string;
  tone: Tone;
  paper: PaperSize;
  margin: MarginPreset;
  greeting?: string;
  closing?: string;
  letterLang?: Lang;
  letterLangByTemplate?: Partial<Record<LetterTemplateId, Lang>>;
}

interface AtsResult { score: number; matched_keywords?: string[]; missing_keywords?: string[]; strengths?: string[]; weaknesses?: string[]; suggestions?: string[] }

function loadSettings(lang: Lang): Settings {
  const base: Settings = { templateId: "classic", accent: ACCENTS[0], tone: "professional", paper: "a4", margin: "normal", letterLang: lang, letterLangByTemplate: {} };
  if (typeof localStorage === "undefined") return base;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return { ...base, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return {
    ...base,
    templateId: (localStorage.getItem("cl:tpl") as LetterTemplateId) || "classic",
    accent: localStorage.getItem("cl:accent") || ACCENTS[0],
    greeting: defaultGreeting(lang),
    closing: defaultClosing(lang),
  };
}

export const Route = createFileRoute("/cover-letter")({
  head: () => ({
    meta: [
      { title: "خطاب تعريفي بالذكاء الاصطناعي" },
      { name: "description", content: "أنشئ خطاب تعريفي مخصص للوظيفة بالذكاء الاصطناعي." },
    ],
  }),
  component: CoverLetterPage,
});

function CoverLetterPage() {
  const [lang] = useAppLang();
  const navigate = useNavigate();
  const [cv, setCv] = useState<CVData | null>(null);
  const [company, setCompany] = useState("");
  const [position, setPosition] = useState("");
  const [jobDesc, setJobDesc] = useState("");
  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);
  const [improving, setImproving] = useState(false);
  const [applying, setApplying] = useState(false);
  const [atsLoading, setAtsLoading] = useState(false);
  const [ats, setAts] = useState<AtsResult | null>(null);
  const [copied, setCopied] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [previewMode, setPreviewMode] = useState<"template" | "word">("template");
  const previewRef = useRef<HTMLDivElement>(null);

  const initial = useMemo(() => loadSettings(lang as Lang), [lang]);
  const [accent, setAccent] = useState<string>(initial.accent);
  const [tone, setTone] = useState<Tone>(initial.tone);
  const [paper, setPaper] = useState<PaperSize>(initial.paper);
  const [margin, setMargin] = useState<MarginPreset>(initial.margin);
  const [letterLangByTemplate, setLetterLangByTemplate] = useState<Partial<Record<LetterTemplateId, Lang>>>(initial.letterLangByTemplate || {});
  const [templateId, setTemplateIdState] = useState<LetterTemplateId>(initial.templateId);
  const initialLetterLang = (letterLangByTemplate[initial.templateId] || initial.letterLang || (lang as Lang)) as Lang;
  const [letterLang, setLetterLang] = useState<Lang>(initialLetterLang);
  const [greeting, setGreeting] = useState<string>(initial.greeting || defaultGreeting(initialLetterLang));
  const [closing, setClosing] = useState<string>(initial.closing || defaultClosing(initialLetterLang));

  // When the template changes, restore that template's saved language (and reset greeting/closing to its defaults)
  const setTemplateId = (id: LetterTemplateId) => {
    setTemplateIdState(id);
    const saved = letterLangByTemplate[id];
    if (saved && saved !== letterLang) {
      setLetterLang(saved);
      setGreeting(defaultGreeting(saved));
      setClosing(defaultClosing(saved));
    }
  };

  useEffect(() => {
    const id = ensureCurrent();
    setCv(getCV(id));
  }, []);

  // persist all settings
  useEffect(() => {
    try {
      const nextMap = { ...letterLangByTemplate, [templateId]: letterLang };
      const s: Settings = { templateId, accent, tone, paper, margin, greeting, closing, letterLang, letterLangByTemplate: nextMap };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
      if (nextMap[templateId] !== letterLangByTemplate[templateId]) setLetterLangByTemplate(nextMap);
    } catch { /* ignore */ }
  }, [templateId, accent, tone, paper, margin, greeting, closing, letterLang, letterLangByTemplate]);

  // Toggle preview language: also reset greeting/closing to that language's defaults
  const toggleLang = () => {
    const next: Lang = letterLang === "ar" ? "en" : "ar";
    setLetterLang(next);
    setGreeting(defaultGreeting(next));
    setClosing(defaultClosing(next));
  };

  const generate = async () => {
    if (!company || !position) {
      toast.error(lang === "ar" ? "أدخل اسم الشركة والمنصب" : "Enter company and position");
      return;
    }
    setLoading(true);
    try {
      const cvSummary = cv ? `Name: ${cv.contact.fullName}\nTitle: ${cv.contact.jobTitle}\nSummary: ${cv.contact.summary}\nKey skills: ${cv.skills.map((s) => s.name).join(", ")}\nRecent: ${cv.experience[0]?.position || ""} at ${cv.experience[0]?.company || ""}` : "";
      const prompt = `COMPANY: ${company}\nPOSITION: ${position}\n${jobDesc ? `JOB DESCRIPTION:\n${jobDesc}\n` : ""}\nCANDIDATE CV:\n${cvSummary}`;
      const result = await callAI("cover_letter", prompt, letterLang, { tone });
      setOutput(result);
      setAts(null);
      setShowPreview(true);
    } catch (e) {
      const m = e instanceof Error ? e.message : "";
      toast.error(m === "rate_limit" ? tr("rateLimit", lang) : m === "credits" ? tr("paymentRequired", lang) : tr("aiError", lang));
    } finally {
      setLoading(false);
    }
  };

  const improve = async () => {
    if (!output) return;
    setImproving(true);
    try {
      const prompt = `${jobDesc ? `JOB DESCRIPTION:\n${jobDesc}\n\n` : ""}LETTER:\n${output}`;
      const result = await callAI("cover_improve", prompt, letterLang, { tone });
      setOutput(result.trim());
      toast.success(lang === "ar" ? "تم التحسين" : "Improved");
    } catch (e) {
      const m = e instanceof Error ? e.message : "";
      toast.error(m === "rate_limit" ? tr("rateLimit", lang) : m === "credits" ? tr("paymentRequired", lang) : tr("aiError", lang));
    } finally { setImproving(false); }
  };

  const runAtsRef = useRef<((silent?: boolean) => Promise<void>) | null>(null);
  const runAts = async (silent = false) => {
    if (!output) return;
    if (!jobDesc.trim()) { if (!silent) toast.error(tr("needJobDesc", lang)); return; }
    setAtsLoading(true);
    try {
      const prompt = `JOB DESCRIPTION:\n${jobDesc}\n\nLETTER:\n${output}`;
      const result = await callAI("cover_ats", prompt, letterLang);
      const parsed = tryParseJSON<AtsResult>(result);
      if (!parsed) throw new Error("parse");
      setAts(parsed);
    } catch (e) {
      if (silent) return;
      const m = e instanceof Error ? e.message : "";
      toast.error(m === "rate_limit" ? tr("rateLimit", lang) : m === "credits" ? tr("paymentRequired", lang) : tr("aiError", lang));
    } finally { setAtsLoading(false); }
  };
  runAtsRef.current = runAts;

  const applyAts = async () => {
    if (!output || !ats) return;
    setApplying(true);
    try {
      const atsCtx = JSON.stringify({ missing_keywords: ats.missing_keywords || [], weaknesses: ats.weaknesses || [], suggestions: ats.suggestions || [] });
      const prompt = `${jobDesc ? `JOB DESCRIPTION:\n${jobDesc}\n\n` : ""}ATS_ANALYSIS:\n${atsCtx}\n\nLETTER:\n${output}`;
      const result = await callAI("cover_apply", prompt, letterLang, { tone });
      setOutput(result.trim());
      toast.success(lang === "ar" ? "تم تطبيق التحسينات" : "Suggestions applied");
      setTimeout(() => runAtsRef.current?.(true), 500);
    } catch (e) {
      const m = e instanceof Error ? e.message : "";
      toast.error(m === "rate_limit" ? tr("rateLimit", lang) : m === "credits" ? tr("paymentRequired", lang) : tr("aiError", lang));
    } finally { setApplying(false); }
  };

  // Auto ATS: re-run analysis (debounced) whenever job description or letter body changes
  useEffect(() => {
    if (!output || !jobDesc.trim()) return;
    const t = setTimeout(() => { runAtsRef.current?.(true); }, 1500);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jobDesc, output, lang]);

  const copy = () => {
    navigator.clipboard.writeText(output);
    setCopied(true);
    toast.success(tr("copied", lang));
    setTimeout(() => setCopied(false), 2000);
  };

  const baseFilename = () => {
    const tag = letterLang === "ar" ? "ar" : "en";
    const safeCompany = (company || "cover-letter").replace(/[^\p{L}\p{N}_-]+/gu, "_");
    return `${safeCompany}-${tag}`;
  };

  const exportPDF = async (mode: "save" | "share" = "save") => {
    if (!previewRef.current || !output) return;
    const html2pdf = (await import("html2pdf.js")).default;
    const filename = `${baseFilename()}.pdf`;
    toast.loading(lang === "ar" ? "جاري التصدير..." : "Exporting...", { id: "exp" });
    try {
      const dim = PAPER_DIMS[paper];
      const worker = html2pdf().set({
        margin: 0,
        filename,
        html2canvas: { scale: 2, useCORS: true, backgroundColor: "#ffffff" },
        jsPDF: { unit: "mm", format: [dim.mm.w, dim.mm.h], orientation: "portrait" },
      }).from(previewRef.current);
      if (mode === "share") {
        const blob: Blob = await worker.outputPdf("blob");
        const title = letterLang === "ar" ? `خطاب تغطية — ${position || ""}` : `Cover Letter — ${position || ""}`;
        await shareFile(new File([blob], filename, { type: "application/pdf" }), title.trim(), letterLang);
      } else {
        await worker.save();
      }
      toast.success(lang === "ar" ? "تم" : "Done", { id: "exp" });
    } catch {
      toast.error(lang === "ar" ? "فشل التصدير" : "Export failed", { id: "exp" });
    }
  };

  const buildWordBlob = async (): Promise<Blob | null> => {
    if (!output || !cv) return null;
    const { Document, Paragraph, TextRun, AlignmentType, Packer } = await import("docx");
    const c = cv.contact;
    const date = formatLetterDate(letterLang);
    const subject = formatLetterSubject(letterLang, position, company);
    const accentHex = accent.replace("#", "");
    const paragraphs = output.split(/\n\n+/).filter(Boolean);
    const dim = PAPER_DIMS[paper];
    const m = MARGIN_MM[margin];
    const mmToTwip = (n: number) => Math.round(n * 56.6929);
    const pageSize = { width: mmToTwip(dim.mm.w), height: mmToTwip(dim.mm.h) };
    const marginTwip = mmToTwip(m);
    // Reuse the SAME alignment helper as <WordPreview /> so RTL output
    // (header / date / subject / greeting / body / closing) cannot drift.
    const a = letterAlignment(letterLang);
    const isRTL = a.isRTL;
    const sideAlign = a.side === "right" ? AlignmentType.RIGHT : AlignmentType.LEFT;
    const headerAlign = a.header === "right" ? AlignmentType.RIGHT : AlignmentType.CENTER;
    const T = (text: string, opts: { bold?: boolean; size?: number; color?: string } = {}) =>
      new TextRun({ text, rightToLeft: isRTL, ...opts });

    const children = [
      new Paragraph({ bidirectional: isRTL, alignment: headerAlign, children: [T(c.fullName || "", { bold: true, size: 36, color: accentHex })] }),
      ...(c.jobTitle ? [new Paragraph({ bidirectional: isRTL, alignment: headerAlign, children: [T(c.jobTitle, { size: 22, color: "6B7280" })] })] : []),
      new Paragraph({ bidirectional: isRTL, alignment: headerAlign, children: [T([c.email, c.phone, c.location].filter(Boolean).join(" • "), { size: 18, color: "6B7280" })] }),
      new Paragraph({ text: "" }),
      new Paragraph({ bidirectional: isRTL, alignment: sideAlign, children: [T(date, { size: 20, color: "6B7280" })] }),
      ...(company ? [new Paragraph({ bidirectional: isRTL, alignment: sideAlign, children: [T(company, { bold: true, size: 22 })] })] : []),
      new Paragraph({ bidirectional: isRTL, alignment: sideAlign, children: [T(subject, { bold: true, size: 24, color: accentHex })] }),
      new Paragraph({ text: "" }),
      new Paragraph({ bidirectional: isRTL, alignment: sideAlign, children: [T(greeting, { size: 22 })] }),
      ...paragraphs.map((p) => new Paragraph({ bidirectional: isRTL, alignment: sideAlign, children: [T(p, { size: 22 })], spacing: { after: 160 } })),
      new Paragraph({ text: "" }),
      new Paragraph({ bidirectional: isRTL, alignment: sideAlign, children: [T(closing, { size: 22 })] }),
      new Paragraph({ bidirectional: isRTL, alignment: sideAlign, children: [T(c.fullName || "", { bold: true, size: 22 })] }),
    ];
    const doc = new Document({
      styles: {
        default: {
          document: {
            run: { rightToLeft: isRTL, language: { value: isRTL ? "ar-SA" : "en-US" } },
          },
        },
      },
      sections: [{
        properties: { page: { size: pageSize, margin: { top: marginTwip, right: marginTwip, bottom: marginTwip, left: marginTwip } } },
        children,
      }],
    });
    return await Packer.toBlob(doc);
  };

  const exportWord = async () => {
    const blob = await buildWordBlob();
    if (!blob) return;
    const { saveAs } = await import("file-saver");
    saveAs(blob, `${baseFilename()}.docx`);
  };

  const shareWord = async () => {
    const blob = await buildWordBlob();
    if (!blob) return;
    const filename = `${baseFilename()}.docx`;
    const title = letterLang === "ar" ? `خطاب تغطية — ${position || ""}` : `Cover Letter — ${position || ""}`;
    await shareFile(new File([blob], filename, { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" }), title.trim(), letterLang);
  };

  const sharePdf = () => exportPDF("share");

  const tones: { v: Tone; k: "toneProfessional" | "toneFriendly" | "toneCreative"; emoji: string }[] = [
    { v: "professional", k: "toneProfessional", emoji: "💼" },
    { v: "friendly", k: "toneFriendly", emoji: "🤝" },
    { v: "creative", k: "toneCreative", emoji: "✨" },
  ];

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border px-4 py-3 flex items-center gap-2">
        <button onClick={() => navigate({ to: "/" })} className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-muted">
          <ChevronRight className={`w-5 h-5 ${lang === "ar" ? "" : "rotate-180"}`} />
        </button>
        <Mail className="w-5 h-5 text-gold" />
        <h1 className="font-bold text-base flex-1">{tr("coverLetter", lang)}</h1>
        <Popover>
          <PopoverTrigger asChild>
            <button className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-muted" aria-label={tr("pageSetup", lang)}>
              <Settings2 className="w-4 h-4" />
            </button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-64 space-y-3">
            <div className="text-xs font-bold">{tr("pageSetup", lang)}</div>
            <div>
              <div className="text-[11px] text-muted-foreground mb-1.5">{tr("paperSize", lang)}</div>
              <div className="grid grid-cols-2 gap-1.5">
                {(["a4", "letter"] as PaperSize[]).map((p) => (
                  <button key={p} onClick={() => setPaper(p)} className={`h-8 rounded-md border text-xs font-semibold ${paper === p ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border"}`}>{p.toUpperCase()}</button>
                ))}
              </div>
            </div>
            <div>
              <div className="text-[11px] text-muted-foreground mb-1.5">{tr("margin", lang)}</div>
              <div className="grid grid-cols-3 gap-1.5">
                {(["narrow", "normal", "wide"] as MarginPreset[]).map((m) => (
                  <button key={m} onClick={() => setMargin(m)} className={`h-8 rounded-md border text-[11px] font-semibold ${margin === m ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border"}`}>
                    {tr(m === "narrow" ? "marginNarrow" : m === "normal" ? "marginNormal" : "marginWide", lang)}
                  </button>
                ))}
              </div>
            </div>
          </PopoverContent>
        </Popover>
        <button onClick={toggleLang} className={`h-9 px-2 rounded-lg flex items-center gap-1 text-[11px] font-bold transition ${letterLang === "ar" ? "bg-primary/10 text-primary border border-primary/30" : "hover:bg-muted text-primary"}`} aria-label="Toggle letter language" title={letterLang === "ar" ? "Switch to English" : "التبديل للعربية"}>
          <Languages className="w-4 h-4" />
          <span>{letterLang === "ar" ? "AR · RTL" : "EN"}</span>
        </button>
        {output && (
          <button onClick={() => setShowPreview((s) => !s)} className="h-9 px-3 rounded-lg flex items-center gap-1.5 hover:bg-muted text-primary text-xs font-bold">
            <Eye className="w-4 h-4" /> {tr("livePreview", lang)}
          </button>
        )}
      </header>

      <div className="px-4 py-4 space-y-4">
        {/* Template picker */}
        <div className="rounded-2xl bg-card border border-border p-4 shadow-card space-y-3">
          <div className="text-xs font-bold">{tr("letterTemplate", lang)}</div>
          <div className="grid grid-cols-3 gap-2">
            {LETTER_TEMPLATES.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTemplateId(t.id)}
                className={`rounded-xl border p-2 text-start transition ${templateId === t.id ? "border-primary ring-2 ring-primary/30 bg-primary/5" : "border-border hover:border-primary/40 bg-card"}`}
              >
                <LetterThumbPreview id={t.id} accent={accent} cv={cv} company={company} position={position} lang={letterLang} greeting={greeting} closing={closing} />
                <div className="text-[11px] font-bold mt-1.5">{t.name[lang]}</div>
                <div className="text-[10px] text-muted-foreground leading-tight">{t.desc[lang]}</div>
              </button>
            ))}
          </div>
          <div>
            <div className="text-[11px] text-muted-foreground mb-1.5">{tr("accentColor", lang)}</div>
            <div className="flex flex-wrap gap-1.5">
              {ACCENTS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setAccent(c)}
                  className={`w-7 h-7 rounded-full border-2 transition ${accent === c ? "border-foreground scale-110" : "border-border"}`}
                  style={{ background: c }}
                  aria-label={c}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-card border border-border p-4 space-y-3 shadow-card">
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label className="text-[11px] text-muted-foreground">{lang === "ar" ? "الشركة" : "Company"}</Label>
              <Input value={company} onChange={(e) => setCompany(e.target.value)} placeholder={lang === "ar" ? "اسم الشركة" : "Company name"} />
            </div>
            <div className="space-y-1">
              <Label className="text-[11px] text-muted-foreground">{lang === "ar" ? "المنصب" : "Position"}</Label>
              <Input value={position} onChange={(e) => setPosition(e.target.value)} placeholder={lang === "ar" ? "المسمى الوظيفي" : "Job title"} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-[11px] text-muted-foreground">{tr("letterTone", lang)}</Label>
            <div className="grid grid-cols-3 gap-1.5">
              {tones.map((t) => (
                <button
                  key={t.v}
                  type="button"
                  onClick={() => setTone(t.v)}
                  className={`h-10 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1 transition ${tone === t.v ? "bg-primary text-primary-foreground border-primary shadow-soft" : "bg-card border-border hover:border-primary/40"}`}
                >
                  <span>{t.emoji}</span>{tr(t.k, lang)}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-1">
            <Label className="text-[11px] text-muted-foreground">{lang === "ar" ? "وصف الوظيفة (اختياري)" : "Job description (optional)"}</Label>
            <Textarea value={jobDesc} onChange={(e) => setJobDesc(e.target.value)} rows={4} placeholder={tr("jdPlaceholder", lang)} />
          </div>
          <Button onClick={generate} disabled={loading} className="w-full gradient-primary text-primary-foreground h-11 font-bold shadow-soft">
            {loading ? <Loader2 className="w-4 h-4 animate-spin ms-1" /> : <Sparkles className="w-4 h-4 ms-1" />}
            {loading ? tr("generating", lang) : tr("generate", lang)}
          </Button>
        </div>

        {output && (
          <div className="rounded-2xl bg-card border border-border p-4 shadow-card space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-sm">{lang === "ar" ? "الخطاب" : "Letter"}</h2>
              <div className="flex gap-1">
                <Button variant="ghost" size="sm" onClick={copy} className="h-8 gap-1.5 text-primary">
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span className="text-xs">{copied ? tr("copied", lang) : tr("copy", lang)}</span>
                </Button>
              </div>
            </div>

            {/* Greeting / Closing */}
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label className="text-[11px] text-muted-foreground flex items-center justify-between">
                  <span>{tr("greeting", lang)}</span>
                  <button type="button" onClick={() => setGreeting(defaultGreeting(letterLang))} className="text-[10px] text-primary inline-flex items-center gap-0.5">
                    <RotateCcw className="w-3 h-3" />{tr("resetDefaults", lang)}
                  </button>
                </Label>
                <Input value={greeting} onChange={(e) => setGreeting(e.target.value)} className="h-8 text-xs" />
              </div>
              <div className="space-y-1">
                <Label className="text-[11px] text-muted-foreground flex items-center justify-between">
                  <span>{tr("closing", lang)}</span>
                  <button type="button" onClick={() => setClosing(defaultClosing(letterLang))} className="text-[10px] text-primary inline-flex items-center gap-0.5">
                    <RotateCcw className="w-3 h-3" />{tr("resetDefaults", lang)}
                  </button>
                </Label>
                <Input value={closing} onChange={(e) => setClosing(e.target.value)} className="h-8 text-xs" />
              </div>
            </div>

            <Textarea value={output} onChange={(e) => setOutput(e.target.value)} rows={12} className="text-sm leading-relaxed" />

            <div className="grid grid-cols-2 gap-2">
              <Button onClick={improve} disabled={improving} variant="outline" className="h-10 text-xs font-bold border-primary/30 text-primary">
                {improving ? <Loader2 className="w-3.5 h-3.5 animate-spin ms-1" /> : <Wand2 className="w-3.5 h-3.5 ms-1" />}
                {tr("improveLetter", lang)}
              </Button>
              <Button onClick={() => runAts(false)} disabled={atsLoading} variant="outline" className="h-10 text-xs font-bold">
                {atsLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin ms-1" /> : <Gauge className="w-3.5 h-3.5 ms-1" />}
                {tr("atsLetter", lang)}
              </Button>
            </div>

            {ats && (
              <div className="rounded-xl border border-border bg-muted/30 p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold">{tr("matchScore", lang)}</span>
                  <span className="text-lg font-extrabold" style={{ color: ats.score >= 75 ? "#16A34A" : ats.score >= 50 ? "#EA580C" : "#B91C1C" }}>{ats.score}/100</span>
                </div>
                <Progress value={ats.score} className="h-2" />
                {ats.matched_keywords && ats.matched_keywords.length > 0 && (
                  <div>
                    <div className="text-[11px] font-bold text-muted-foreground mb-1">{tr("matchedKeywords", lang)}</div>
                    <div className="flex flex-wrap gap-1">
                      {ats.matched_keywords.map((k, i) => <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-green-500/10 text-green-600 border border-green-500/20">{k}</span>)}
                    </div>
                  </div>
                )}
                {ats.missing_keywords && ats.missing_keywords.length > 0 && (
                  <div>
                    <div className="text-[11px] font-bold text-muted-foreground mb-1">{tr("missingKeywords", lang)}</div>
                    <div className="flex flex-wrap gap-1">
                      {ats.missing_keywords.map((k, i) => <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/10 text-red-600 border border-red-500/20">{k}</span>)}
                    </div>
                  </div>
                )}
                {ats.strengths && ats.strengths.length > 0 && (
                  <div>
                    <div className="text-[11px] font-bold text-muted-foreground mb-1">{tr("strengths", lang)}</div>
                    <ul className="text-[11px] leading-snug list-disc ps-4 space-y-0.5 text-green-700 dark:text-green-500">
                      {ats.strengths.map((s, i) => <li key={i}>{s}</li>)}
                    </ul>
                  </div>
                )}
                {ats.weaknesses && ats.weaknesses.length > 0 && (
                  <div>
                    <div className="text-[11px] font-bold text-muted-foreground mb-1">{tr("weaknesses", lang)}</div>
                    <ul className="text-[11px] leading-snug list-disc ps-4 space-y-0.5 text-red-700 dark:text-red-500">
                      {ats.weaknesses.map((s, i) => <li key={i}>{s}</li>)}
                    </ul>
                  </div>
                )}
                {ats.suggestions && ats.suggestions.length > 0 && (
                  <div>
                    <div className="text-[11px] font-bold text-muted-foreground mb-1">{tr("suggestions", lang)}</div>
                    <ul className="text-[11px] leading-snug list-disc ps-4 space-y-0.5">
                      {ats.suggestions.map((s, i) => <li key={i}>{s}</li>)}
                    </ul>
                  </div>
                )}
                <Button onClick={applyAts} disabled={applying} className="w-full h-9 text-xs font-bold gradient-primary text-primary-foreground mt-1">
                  {applying ? <Loader2 className="w-3.5 h-3.5 animate-spin ms-1" /> : <Wand2 className="w-3.5 h-3.5 ms-1" />}
                  {applying ? tr("applying", lang) : tr("applyAtsLetter", lang)}
                </Button>
              </div>
            )}
          </div>
        )}

        {output && showPreview && (
          <div className={`rounded-2xl bg-muted/40 border p-3 overflow-auto relative ${letterLang === "ar" ? "border-primary/40 ring-1 ring-primary/20" : "border-border"}`} dir={letterLang === "ar" ? "rtl" : "ltr"}>
            <div className={`absolute top-2 ${letterLang === "ar" ? "left-2" : "right-2"} z-10 flex gap-1`}>
              <button onClick={() => setPreviewMode("template")} className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${previewMode === "template" ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border text-muted-foreground"}`}>{tr("livePreviewLabel", lang)}</button>
              <button onClick={() => setPreviewMode("word")} className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${previewMode === "word" ? "bg-blue-600 text-white border-blue-600" : "bg-card border-border text-muted-foreground"}`}>{tr("wordPreview", lang)}</button>
              <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${letterLang === "ar" ? "bg-primary/10 text-primary border border-primary/30" : "bg-muted text-muted-foreground border border-border"}`}>{letterLang === "ar" ? "RTL · ع" : "LTR · EN"}</span>
            </div>
            {previewMode === "template" ? (
              <div ref={previewRef} className="origin-top mx-auto" style={{ transform: "scale(0.46)", width: `${100 / 0.46}%`, marginInline: `-${(100 / 0.46 - 100) / 2}%`, marginBottom: `-${(1 - 0.46) * 254}%` }}>
                <LetterRenderer templateId={templateId} body={output} cv={cv} company={company} position={position} accentColor={accent} lang={letterLang} greeting={greeting} closing={closing} paperSize={paper} marginPreset={margin} />
              </div>
            ) : (
              <WordPreview {...({
                body: output,
                cv,
                company,
                position,
                accent,
                lang: letterLang,
                greeting,
                closing,
                paper,
                margin,
              } satisfies WordPreviewProps)} />
            )}
          </div>
        )}
      </div>

      {output && (
        <div className="fixed bottom-0 inset-x-0 p-3 bg-background/95 backdrop-blur border-t border-border grid grid-cols-4 gap-2">
          <Button onClick={() => exportPDF("save")} className="h-11 gradient-primary text-primary-foreground font-bold flex-col gap-0.5 leading-none">
            <Download className="w-4 h-4" />
            <span className="text-[10px]">PDF</span>
          </Button>
          <Button onClick={exportWord} variant="outline" className="h-11 flex-col gap-0.5 leading-none">
            <FileType className="w-4 h-4" />
            <span className="text-[10px]">Word</span>
          </Button>
          <Button onClick={sharePdf} variant="outline" className="h-11 flex-col gap-0.5 leading-none text-primary border-primary/30">
            <Share2 className="w-4 h-4" />
            <span className="text-[10px]">PDF</span>
          </Button>
          <Button onClick={shareWord} variant="outline" className="h-11 flex-col gap-0.5 leading-none text-primary border-primary/30">
            <Share2 className="w-4 h-4" />
            <span className="text-[10px]">Word</span>
          </Button>
        </div>
      )}
    </div>
  );
}

function LetterThumbPreview({ id, accent, cv, company, position, lang, greeting, closing }: { id: LetterTemplateId; accent: string; cv: CVData | null; company: string; position: string; lang: Lang; greeting: string; closing: string }) {
  const sampleBody = lang === "ar"
    ? "يسعدني التقدم لهذه الوظيفة. أحمل خبرة عملية واسعة في هذا المجال وقد قدت مشاريع أثمرت نتائج ملموسة.\n\nأمتلك مهارات قوية في حل المشكلات والعمل ضمن فريق، مع شغف حقيقي بتقديم قيمة مضافة لشركتكم.\n\nأتطلع للقاء فريقكم لمناقشة كيف يمكنني المساهمة بنجاح."
    : "I am excited to apply for this role. I bring proven experience and have led initiatives delivering measurable impact.\n\nMy strengths in problem-solving and collaboration align well with your team's mission, and I am passionate about adding value.\n\nI welcome the chance to discuss how I can contribute to your continued success.";
  const safeCv: CVData | null = cv && cv.contact.fullName ? cv : (cv ? { ...cv, contact: { ...cv.contact, fullName: lang === "ar" ? "اسمك هنا" : "Your Name", jobTitle: cv.contact.jobTitle || (lang === "ar" ? "المسمى الوظيفي" : "Your Title"), email: cv.contact.email || "you@example.com", phone: cv.contact.phone || "+1 555 0100", location: cv.contact.location || (lang === "ar" ? "المدينة" : "City") } } : null);
  return (
    <div className="aspect-[3/4] rounded-md bg-white border border-border overflow-hidden relative">
      <div className="absolute inset-0 origin-top-left pointer-events-none" style={{ transform: "scale(0.18)", width: `${100 / 0.18}%`, height: `${100 / 0.18}%` }}>
        <LetterRenderer
          templateId={id}
          body={sampleBody}
          cv={safeCv}
          company={company || (lang === "ar" ? "اسم الشركة" : "Company Inc.")}
          position={position || (lang === "ar" ? "المنصب" : "Position")}
          accentColor={accent}
          lang={lang}
          greeting={greeting}
          closing={closing}
          paperSize="a4"
          marginPreset="normal"
        />
      </div>
    </div>
  );
}
