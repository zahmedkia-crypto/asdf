import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState, memo } from "react";
import { ChevronRight, Download, FileText, FileType, Share2, Sparkles, Loader2, Target, Wand2, Eye, EyeOff, X, ZoomIn, ZoomOut, RotateCcw, Settings2, Languages, Check, Plus, Trash2, MapPin } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { CVRenderer } from "@/components/templates/all";
import { getCurrentId, getCV, useAppLang, ensureCurrent, saveCV } from "@/lib/cv-store";
import { tr } from "@/lib/i18n";
import { callAI, tryParseJSON } from "@/lib/ai";
import { shareFile } from "@/lib/share";
import { toast } from "sonner";
import type { CVData, TemplateId } from "@/lib/cv-types";
import { TemplateRecommendDialog } from "@/components/cv/TemplateRecommendDialog";
import { SkillGapDialog } from "@/components/cv/SkillGapDialog";
import { LayoutInspector } from "@/components/cv/LayoutInspector";
import { ATSInspector } from "@/components/cv/ATSInspector";
import { ComparePreviewDialog } from "@/components/cv/ComparePreviewDialog";
import { autoFixCV, getLayoutSettings, setLayoutSettings, DEFAULT_LAYOUT, DEFAULT_SECTION_TYPO, SECTION_KEYS, SECTION_GROUPS, typographyCSS, resolveSectionTypography, validateArabicTypography, autoFixArabicTypography, getTemplatePreviewDir, setTemplatePreviewDir, type LayoutSettings, type SectionKey, type SectionGroupKey, type SectionTypography, type AlignOption, type HyphensOption, type TextJustifyOption, type ExportOptimizeLevel } from "@/lib/layout-settings";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";

export const Route = createFileRoute("/preview")({
  head: () => ({
    meta: [
      { title: "معاينة وتصدير السيرة الذاتية" },
      { name: "description", content: "عاين سيرتك الذاتية واحفظها كـ PDF أو Word، أو حسّنها بالذكاء الاصطناعي." },
    ],
  }),
  component: PreviewPage,
});

interface MatchResult { score: number; matched_keywords?: string[]; missing_keywords?: string[]; suggestions?: string[]; }
interface ATSResult { score: number; strengths?: string[]; weaknesses?: string[]; keywords_to_add?: string[]; matched_keywords?: string[]; missing_keywords?: string[]; placement_plan?: { keyword: string; section: "summary" | "experience" | "skills" | "projects" | "other"; reason?: string }[]; }
interface JobDescItem { id: string; title: string; content: string; }
const JOBS_KEY = "cv:jobs";
const JOB_SEL_KEY = "cv:jobSel";

function PreviewPage() {
  const [lang] = useAppLang();
  const navigate = useNavigate();
  const [id, setId] = useState<string | null>(null);
  const [cv, setCv] = useState<CVData | null>(null);
  const previewRef = useRef<HTMLDivElement>(null);

  const [jobs, setJobs] = useState<JobDescItem[]>(() => {
    if (typeof localStorage === "undefined") return [];
    try { return JSON.parse(localStorage.getItem(JOBS_KEY) || "[]") as JobDescItem[]; } catch { return []; }
  });
  const [selectedJobId, setSelectedJobId] = useState<string | null>(() => {
    if (typeof localStorage === "undefined") return null;
    return localStorage.getItem(JOB_SEL_KEY);
  });
  useEffect(() => { const t = window.setTimeout(() => { try { localStorage.setItem(JOBS_KEY, JSON.stringify(jobs)); } catch { /* ignore */ } }, 400); return () => window.clearTimeout(t); }, [jobs]);
  useEffect(() => { try { if (selectedJobId) localStorage.setItem(JOB_SEL_KEY, selectedJobId); else localStorage.removeItem(JOB_SEL_KEY); } catch { /* ignore */ } }, [selectedJobId]);
  const selectedJob = jobs.find((j) => j.id === selectedJobId) ?? null;
  const jobDesc = selectedJob?.content ?? "";
  const addJob = () => {
    const j: JobDescItem = { id: crypto.randomUUID(), title: lang === "ar" ? `وصف ${jobs.length + 1}` : `Job ${jobs.length + 1}`, content: "" };
    setJobs((p) => [...p, j]);
    setSelectedJobId(j.id);
  };
  const updateJob = (id: string, patch: Partial<JobDescItem>) => setJobs((p) => p.map((j) => (j.id === id ? { ...j, ...patch } : j)));
  const removeJob = (id: string) => {
    setJobs((p) => p.filter((j) => j.id !== id));
    if (selectedJobId === id) setSelectedJobId(null);
  };
  const [matchResult, setMatchResult] = useState<MatchResult | null>(null);
  const [atsResult, setAtsResult] = useState<ATSResult | null>(null);
  const [aiLoading, setAiLoading] = useState<"match" | "ats" | "apply" | null>(null);
  const [showMatch, setShowMatch] = useState(false);
  const [showATS, setShowATS] = useState(false);
  const [readOnly, setReadOnly] = useState(false);
  const [warnExport, setWarnExport] = useState<null | "pdf" | "word">(null);
  const [pendingCV, setPendingCV] = useState<CVData | null>(null);
  const [highlightedSection, setHighlightedSection] = useState<string | null>(null);
  const lastAtsKey = useRef<string>("");
  const highlightTimer = useRef<number | null>(null);

  const focusSection = (section: string) => {
    setShowATS(false);
    setHighlightedSection(section);
    if (highlightTimer.current) window.clearTimeout(highlightTimer.current);
    window.setTimeout(() => {
      const el = previewRef.current?.querySelector(`[data-cv-section="${section}"]`) as HTMLElement | null;
      el?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 250);
    highlightTimer.current = window.setTimeout(() => setHighlightedSection(null), 3500);
  };
  const [zoom, setZoom] = useState(0.46);
  const [paperSize, setPaperSize] = useState<"a4" | "letter">(() => (typeof localStorage !== "undefined" && (localStorage.getItem("cv:paper") as "a4" | "letter")) || "a4");
  const [marginPreset, setMarginPreset] = useState<"narrow" | "normal" | "wide">(() => (typeof localStorage !== "undefined" && (localStorage.getItem("cv:margin") as "narrow" | "normal" | "wide")) || "normal");
  useEffect(() => { try { localStorage.setItem("cv:paper", paperSize); localStorage.setItem("cv:margin", marginPreset); } catch { /* ignore */ } }, [paperSize, marginPreset]);
  // Margin in mm for PDF, and in DXA twips for Word (1 inch = 25.4 mm = 1440 dxa)
  const marginMM = marginPreset === "narrow" ? 8 : marginPreset === "wide" ? 20 : 12;
  const marginDXA = Math.round((marginMM / 25.4) * 1440);

  // Layout / pagination settings
  const [layout, setLayoutState] = useState<LayoutSettings>(() => getLayoutSettings());
  const updateLayout = (patch: Partial<LayoutSettings>) => {
    const next = { ...layout, ...patch };
    setLayoutState(next);
    setLayoutSettings(next);
  };

  const runAutoFix = (): CVData | null => {
    if (!cv) return null;
    const { changed, notes, cv: fixed } = autoFixCV(cv, layout, lang);
    if (!changed) {
      toast.info(lang === "ar" ? "لا حاجة لإصلاح" : "Nothing to fix");
      return cv;
    }
    saveCV(fixed);
    setCv(fixed);
    toast.success(`${tr("autoFixed", lang)} — ${notes.join(" · ")}`);
    return fixed;
  };

  const [previewDir, setPreviewDirState] = useState<"auto" | "rtl" | "ltr">("auto");
  // Persist per-template preview direction so it follows the selected template
  const setPreviewDir = (dir: "auto" | "rtl" | "ltr") => {
    setPreviewDirState(dir);
    if (cv?.template) {
      const next = setTemplatePreviewDir(layout, cv.template, dir);
      setLayoutState(next);
      setLayoutSettings(next);
    }
  };
  // Restore the template's saved direction whenever the active template changes
  useEffect(() => {
    if (!cv?.template) return;
    setPreviewDirState(getTemplatePreviewDir(layout, cv.template));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cv?.template]);

  /** Sections currently rendered in the CV (used to scope Arabic safety checks). */
  const sectionsInUse = (data: CVData): SectionKey[] => {
    const list: SectionKey[] = [];
    if (data.contact.summary) list.push("summary");
    if (data.experience.length) list.push("experience");
    if (data.education.length) list.push("education");
    if (data.skills.length) list.push("skills");
    if (data.projects.length) list.push("projects");
    if (data.certificates.length) list.push("certificates");
    if (data.courses.length) list.push("courses");
    if (data.awards.length) list.push("awards");
    if (data.languages.length) list.push("languages");
    return list;
  };

  /** Run Arabic-typography safety check; auto-fix offending sections. Returns true if anything was fixed. */
  const ensureArabicSafe = (data: CVData): boolean => {
    if (data.lang !== "ar" && previewDir !== "rtl") return false;
    const offenders = validateArabicTypography(layout, data.template, sectionsInUse(data));
    if (offenders.length === 0) return false;
    const next = autoFixArabicTypography(layout, data.template, offenders);
    setLayoutState(next);
    setLayoutSettings(next);
    toast.warning(tr("arabicSafetyFix", lang));
    return true;
  };

  useEffect(() => {
    const cid = getCurrentId() || ensureCurrent();
    setId(cid);
    setCv(getCV(cid));
  }, []);

  // Apply visual highlight to matching section in preview
  useEffect(() => {
    const root = previewRef.current;
    if (!root) return;
    const all = root.querySelectorAll<HTMLElement>("[data-cv-section]");
    all.forEach((el) => { el.style.boxShadow = ""; el.style.background = ""; el.style.borderRadius = ""; });
    if (!highlightedSection) return;
    const el = root.querySelector<HTMLElement>(`[data-cv-section="${highlightedSection}"]`);
    if (el) {
      el.style.boxShadow = "0 0 0 4px hsl(var(--primary) / 0.6), 0 0 24px hsl(var(--primary) / 0.35)";
      el.style.background = "hsl(var(--primary) / 0.08)";
      el.style.borderRadius = "12px";
    }
  }, [highlightedSection, cv, pendingCV]);

  // Auto re-analyze ATS when active JD content or selection changes
  useEffect(() => {
    if (!cv || !atsResult) return;
    if (pendingCV || aiLoading) return;
    if (!jobDesc.trim()) return;
    const key = `${selectedJobId ?? ""}::${jobDesc}`;
    if (key === lastAtsKey.current) return;
    const t = window.setTimeout(() => { runATS({ silent: true }); }, 1400);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jobDesc, selectedJobId]);

  // Keyboard shortcut: Ctrl/Cmd+P → export PDF
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "p") {
        e.preventDefault();
        exportPDF("save");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cv]);

  const exportPDF = async (mode: "save" | "share" = "save") => {
    if (!previewRef.current || !cv) return;
    if (ensureArabicSafe(cv)) await new Promise((r) => requestAnimationFrame(() => r(null)));
    // Auto-fix layout issues before exporting (non-destructive trim + skill re-rank)
    if (layout.autoFixOnExport) {
      const { changed, notes, cv: fixed } = autoFixCV(cv, layout, lang);
      if (changed) {
        saveCV(fixed);
        setCv(fixed);
        toast.success(`${tr("autoFixed", lang)} — ${notes.slice(0, 2).join(" · ")}`);
        // Wait one frame for the DOM to reflect the trimmed content
        await new Promise((r) => requestAnimationFrame(() => r(null)));
      }
    }
    if (mode === "save" && (cv.lastATSScore ?? 100) < 90) { setWarnExport("pdf"); return; }
    const html2pdf = (await import("html2pdf.js")).default;
    toast.loading(lang === "ar" ? "جاري التصدير..." : "Exporting...", { id: "exp" });
    try {
      const filename = `${cv.contact.fullName || cv.name || "CV"}.pdf`;
      const worker = html2pdf()
        .set({
          margin: marginMM,
          filename,
          html2canvas: { scale: layout.exportOptimizeLevel === "aggressive" ? 2.5 : 2, useCORS: true, backgroundColor: "#ffffff", letterRendering: true },
          jsPDF: { unit: "mm", format: paperSize, orientation: "portrait", ...(layout.exportOptimizeLevel !== "off" ? { compress: true } : {}) } as { unit: string; format: string; orientation: "portrait" },
          // pagebreak supported at runtime; not in the type defs
          ...({
            pagebreak: {
              mode: ["css", "legacy"],
              avoid: layout.exportOptimizeLevel === "aggressive"
                ? [".cv-item", ".tpl-h2", ".cv-summary", "li", "[data-cv-section]:not(.cv-allow-break)"]
                : layout.exportOptimizeLevel === "standard"
                ? [".cv-item", ".tpl-h2", "[data-cv-section]:not(.cv-allow-break)"]
                : [],
            },
          } as object),
        })
        .from(previewRef.current);
      if (mode === "share") {
        const blob: Blob = await worker.outputPdf("blob");
        const file = new File([blob], filename, { type: "application/pdf" });
        await shareFile(file, cv.name || filename, lang);
      } else {
        await worker.save();
      }
      toast.success(lang === "ar" ? "تم" : "Done", { id: "exp" });
    } catch {
      toast.error(lang === "ar" ? "فشل التصدير" : "Export failed", { id: "exp" });
    }
  };

  const exportTXT = () => {
    if (!cv) return;
    const L = cv.lang;
    const lines: string[] = [];
    const c = cv.contact;
    lines.push(c.fullName, c.jobTitle, [c.email, c.phone, c.location].filter(Boolean).join(" | "), "");
    if (c.summary) lines.push("--- " + (L === "ar" ? "نبذة" : "Summary") + " ---", c.summary, "");
    if (cv.experience.length) {
      lines.push("--- " + (L === "ar" ? "الخبرة" : "Experience") + " ---");
      cv.experience.forEach((e) => lines.push(`${e.position} @ ${e.company} (${e.startDate} - ${e.current ? "Now" : e.endDate})`, e.description, ""));
    }
    if (cv.education.length) {
      lines.push("--- " + (L === "ar" ? "التعليم" : "Education") + " ---");
      cv.education.forEach((e) => lines.push(`${e.degree} - ${e.institution} (${e.startDate} - ${e.endDate})`));
      lines.push("");
    }
    if (cv.skills.length) lines.push("--- " + (L === "ar" ? "المهارات" : "Skills") + " ---", cv.skills.map((s) => s.name).join(", "), "");
    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    import("file-saver").then(({ saveAs }) => saveAs(blob, `${c.fullName || "CV"}.txt`));
  };

  const exportWord = async () => {
    if (!cv) return;
    ensureArabicSafe(cv);
    let activeCV = cv;
    if (layout.autoFixOnExport) {
      const { changed, notes, cv: fixed } = autoFixCV(cv, layout, lang);
      if (changed) {
        saveCV(fixed);
        setCv(fixed);
        activeCV = fixed;
        toast.success(`${tr("autoFixed", lang)} — ${notes.slice(0, 2).join(" · ")}`);
      }
    }
    const docx = await import("docx");
    const { Document, Paragraph, TextRun, HeadingLevel, AlignmentType, Packer } = docx;
    const c = activeCV.contact;
    const L = activeCV.lang;
    const isRTL = L === "ar";
    const opt = layout.exportOptimizeLevel;
    const widowExtra = opt === "aggressive" ? { widowControl: true } : {};
    // RTL paragraph helper — keepLines keeps a paragraph's lines together
    const P = (opts: Exclude<ConstructorParameters<typeof Paragraph>[0], string>) =>
      new Paragraph({ keepLines: true, ...widowExtra, ...opts, bidirectional: isRTL, alignment: opts.alignment ?? (isRTL ? AlignmentType.RIGHT : AlignmentType.LEFT) });
    const T = (opts: ConstructorParameters<typeof TextRun>[0] | string) => {
      const o = typeof opts === "string" ? { text: opts } : opts;
      return new TextRun({ ...o, rightToLeft: isRTL });
    };
    const sections: InstanceType<typeof Paragraph>[] = [
      new Paragraph({ bidirectional: isRTL, alignment: AlignmentType.CENTER, keepLines: true, children: [T({ text: c.fullName || "", bold: true, size: 40 })] }),
      new Paragraph({ bidirectional: isRTL, alignment: AlignmentType.CENTER, keepLines: true, children: [T({ text: c.jobTitle || "", size: 24 })] }),
      new Paragraph({ bidirectional: isRTL, alignment: AlignmentType.CENTER, keepLines: true, children: [T({ text: [c.email, c.phone, c.location].filter(Boolean).join(" | "), size: 20 })] }),
      new Paragraph({ text: "" }),
    ];
    // keepNext on heading so it sticks to the next paragraph; first body para also keeps with heading.
    const addSection = (title: string, body: () => InstanceType<typeof Paragraph>[]) => {
      sections.push(new Paragraph({ bidirectional: isRTL, alignment: isRTL ? AlignmentType.RIGHT : AlignmentType.LEFT, heading: HeadingLevel.HEADING_2, keepNext: true, keepLines: true, children: [T({ text: title, bold: true })] }));
      const bodyParas = body();
      if (bodyParas[0]) {
        // ensure heading + first paragraph stay together
        bodyParas[0] = new Paragraph({ ...({ keepLines: true } as object), ...bodyParas[0] } as never);
      }
      sections.push(...bodyParas);
      sections.push(new Paragraph({ text: "" }));
    };
    if (c.summary) addSection(L === "ar" ? "نبذة" : "Summary", () => [P({ alignment: AlignmentType.JUSTIFIED, children: [T(c.summary)] })]);
    // Compute total experience length to decide whether to allow a 2nd-page break
    const expTotal = activeCV.experience.reduce((n, e) => n + (e.description?.length || 0), 0);
    const expAllowBreak = expTotal > layout.experiencePageBreakThreshold;
    if (activeCV.experience.length) addSection(L === "ar" ? "الخبرة" : "Experience", () =>
      activeCV.experience.flatMap((e) => [
        // keepNext binds the title/date pair to its description so a single experience never splits;
        // when expAllowBreak is true, the section can move between experiences across pages.
        P({ keepNext: true, children: [T({ text: `${e.position} — ${e.company}`, bold: true })] }),
        P({ keepNext: true, children: [T(`${e.startDate} - ${e.current ? (L === "ar" ? "حالياً" : "Present") : e.endDate}`)] }),
        P({ keepNext: expAllowBreak ? false : true, children: [T(e.description || "")] }),
      ])
    );
    if (activeCV.education.length) addSection(L === "ar" ? "التعليم" : "Education", () =>
      activeCV.education.map((e) => P({ children: [T(`${e.degree} — ${e.institution} (${e.startDate} - ${e.endDate})`)] }))
    );
    if (activeCV.skills.length) addSection(L === "ar" ? "المهارات" : "Skills", () => [P({ children: [T(activeCV.skills.map((s) => s.name).join(" • "))] })]);
    if (activeCV.certificates.length) addSection(L === "ar" ? "الشهادات" : "Certificates", () =>
      activeCV.certificates.map((x) => P({ children: [T(`${x.name} — ${x.issuer} (${x.date})`)] }))
    );
    if (activeCV.languages.length) addSection(L === "ar" ? "اللغات" : "Languages", () =>
      [P({ children: [T(activeCV.languages.map((l) => `${l.name}: ${l.proficiency}`).join(" • "))] })]
    );

    const pageSize = paperSize === "letter"
      ? { width: 12240, height: 15840 }
      : { width: 11906, height: 16838 };
    const doc = new Document({ sections: [{
      properties: { page: { size: pageSize, margin: { top: marginDXA, right: marginDXA, bottom: marginDXA, left: marginDXA } } },
      children: sections,
    }] });
    const blob = await Packer.toBlob(doc);
    import("file-saver").then(({ saveAs }) => saveAs(blob, `${c.fullName || "CV"}.docx`));
  };

  const handleShare = async () => {
    if (!cv) return;
    const text = `${cv.contact.fullName} - ${cv.contact.jobTitle}\n${cv.contact.email}`;
    if (navigator.share) {
      try { await navigator.share({ title: cv.name, text }); } catch {}
    } else {
      navigator.clipboard.writeText(text);
      toast.success(tr("copied", lang));
    }
  };

  const cvText = (cv: CVData) => {
    const c = cv.contact;
    return `${c.fullName} - ${c.jobTitle}\n${c.summary}\n\nExperience:\n${cv.experience.map((e) => `${e.position} @ ${e.company}: ${e.description}`).join("\n")}\n\nEducation:\n${cv.education.map((e) => `${e.degree} - ${e.institution}`).join("\n")}\n\nSkills: ${cv.skills.map((s) => s.name).join(", ")}\nCertificates: ${cv.certificates.map((c) => c.name).join(", ")}`;
  };

  const runMatch = async () => {
    if (!cv || !jobDesc.trim()) return toast.error(lang === "ar" ? "ألصق وصف الوظيفة" : "Paste a job description");
    setAiLoading("match");
    try {
      const out = await callAI("match", `JOB DESCRIPTION:\n${jobDesc}\n\nCV:\n${cvText(cv)}`, lang);
      const parsed = tryParseJSON<MatchResult>(out);
      if (parsed) setMatchResult(parsed);
      else toast.error(lang === "ar" ? "تعذر تحليل الرد" : "Could not parse response");
    } catch (e) {
      const m = e instanceof Error ? e.message : "";
      toast.error(m === "rate_limit" ? tr("rateLimit", lang) : m === "credits" ? tr("paymentRequired", lang) : tr("aiError", lang));
    } finally {
      setAiLoading(null);
    }
  };

  const runATS = async (opts?: { silent?: boolean }) => {
    if (!cv) return;
    setAiLoading("ats");
    if (!opts?.silent) setShowATS(true);
    lastAtsKey.current = `${selectedJobId ?? ""}::${jobDesc}`;
    try {
      const payload = jobDesc.trim()
        ? `JOB DESCRIPTION:\n${jobDesc}\n\nCV:\n${cvText(cv)}`
        : cvText(cv);
      const out = await callAI("ats", payload, lang);
      const parsed = tryParseJSON<ATSResult>(out);
      if (parsed) {
        setAtsResult(parsed);
        const updated = { ...cv, lastATSScore: parsed.score, updatedAt: Date.now() };
        saveCV(updated);
        setCv(updated);
        if (opts?.silent) toast.success(lang === "ar" ? `تم تحديث ATS تلقائياً (${parsed.score})` : `ATS auto-updated (${parsed.score})`);
      } else if (!opts?.silent) toast.error(lang === "ar" ? "تعذر تحليل الرد" : "Could not parse response");
    } catch (e) {
      const m = e instanceof Error ? e.message : "";
      if (!opts?.silent) toast.error(m === "rate_limit" ? tr("rateLimit", lang) : m === "credits" ? tr("paymentRequired", lang) : tr("aiError", lang));
    } finally {
      setAiLoading(null);
    }
  };

  const runApplyATS = async () => {
    if (!cv || !atsResult) return;
    setAiLoading("apply");
    try {
      const jdBlock = jobDesc.trim() ? `JOB DESCRIPTION:\n${jobDesc}\n\n` : "";
      const payload = `${jdBlock}ATS_ANALYSIS:\n${JSON.stringify({
        weaknesses: atsResult.weaknesses,
        keywords_to_add: atsResult.keywords_to_add,
        missing_keywords: atsResult.missing_keywords,
        placement_plan: atsResult.placement_plan,
        previous_score: atsResult.score,
      })}\n\nCV_JSON:\n${JSON.stringify(cv)}`;
      const out = await callAI("ats_apply", payload, lang);
      const updated = tryParseJSON<CVData>(out);
      if (!updated || !updated.contact || !Array.isArray(updated.experience)) {
        toast.error(tr("parseFail", lang));
        return;
      }
      // Stage as pending — user must accept in preview before it commits
      const merged: CVData = { ...cv, ...updated, id: cv.id, updatedAt: Date.now() };
      setPendingCV(merged);
      setShowATS(false);
      toast.success(lang === "ar" ? "عاين التغييرات قبل الاعتماد" : "Preview the changes before accepting");
    } catch (e) {
      const m = e instanceof Error ? e.message : "";
      toast.error(m === "rate_limit" ? tr("rateLimit", lang) : m === "credits" ? tr("paymentRequired", lang) : tr("aiError", lang));
    } finally {
      setAiLoading(null);
    }
  };

  const acceptPending = async () => {
    if (!pendingCV) return;
    saveCV(pendingCV);
    setCv(pendingCV);
    setPendingCV(null);
    toast.success(tr("applied", lang));
    // Re-analyze in the background
    setAiLoading("ats");
    try {
      const payload = jobDesc.trim()
        ? `JOB DESCRIPTION:\n${jobDesc}\n\nCV:\n${cvText(pendingCV)}`
        : cvText(pendingCV);
      const out2 = await callAI("ats", payload, lang);
      const parsed = tryParseJSON<ATSResult>(out2);
      if (parsed) {
        setAtsResult(parsed);
        const withScore = { ...pendingCV, lastATSScore: parsed.score, updatedAt: Date.now() };
        saveCV(withScore);
        setCv(withScore);
      }
    } catch { /* ignore */ }
    finally { setAiLoading(null); }
  };

  const discardPending = () => {
    setPendingCV(null);
    toast.success(lang === "ar" ? "تم تجاهل التغييرات" : "Changes discarded");
  };

  if (!cv) return <div className="min-h-screen grid place-items-center text-muted-foreground">...</div>;

  return (
    <div className="min-h-[100dvh] bg-muted/40 pb-32 safe-x">
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border px-3 sm:px-4 py-3 pt-safe safe-x flex items-center gap-2">

        <button onClick={() => navigate({ to: "/builder" })} className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-muted">
          <ChevronRight className={`w-5 h-5 ${lang === "ar" ? "" : "rotate-180"}`} />
        </button>
        <h1 className="font-bold text-base flex-1">{tr("preview", lang)}</h1>
        <Popover>
          <PopoverTrigger asChild>
            <button className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-muted" aria-label={tr("pageSetup", lang)}>
              <Settings2 className="w-4 h-4" />
            </button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-72 p-3 space-y-3 max-h-[80vh] overflow-auto">
            <div className="text-xs font-bold">{tr("pageSetup", lang)}</div>
            <div>
              <div className="text-[11px] text-muted-foreground mb-1.5">{tr("paperSize", lang)}</div>
              <div className="grid grid-cols-2 gap-1.5">
                {(["a4", "letter"] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => setPaperSize(s)}
                    className={`h-8 rounded-md text-xs font-medium border ${paperSize === s ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:bg-muted"}`}
                  >
                    {s.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div className="text-[11px] text-muted-foreground mb-1.5">{tr("margin", lang)}</div>
              <div className="grid grid-cols-3 gap-1.5">
                {(["narrow", "normal", "wide"] as const).map((m) => (
                  <button
                    key={m}
                    onClick={() => setMarginPreset(m)}
                    className={`h-8 rounded-md text-[11px] font-medium border ${marginPreset === m ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:bg-muted"}`}
                  >
                    {tr(m === "narrow" ? "marginNarrow" : m === "wide" ? "marginWide" : "marginNormal", lang)}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-border space-y-3">
              <div className="text-xs font-bold flex items-center justify-between">
                <span>{tr("layoutRules", lang)}</span>
                <button
                  type="button"
                  onClick={() => { setLayoutState(DEFAULT_LAYOUT); setLayoutSettings(DEFAULT_LAYOUT); }}
                  className="text-[10px] font-medium text-muted-foreground hover:text-primary"
                >
                  {tr("resetDefaults", lang)}
                </button>
              </div>
              <label className="flex items-center justify-between gap-2">
                <span className="text-[11px] flex-1">
                  <span className="block font-medium">{tr("autoFixOnExport", lang)}</span>
                  <span className="block text-muted-foreground text-[10px] leading-snug">{tr("autoFixHint", lang)}</span>
                </span>
                <Switch checked={layout.autoFixOnExport} onCheckedChange={(v) => updateLayout({ autoFixOnExport: v })} />
              </label>
              <div>
                <div className="text-[11px] text-muted-foreground mb-1.5">{tr("exportOptimize", lang)}</div>
                <div className="grid grid-cols-3 gap-1.5">
                  {(["off", "standard", "aggressive"] as const).map((m) => (
                    <button key={m} type="button" onClick={() => updateLayout({ exportOptimizeLevel: m })}
                      className={`h-8 rounded-md text-[10px] font-medium border ${layout.exportOptimizeLevel === m ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:bg-muted"}`}>
                      {tr(m === "off" ? "exportOpt_off" : m === "standard" ? "exportOpt_standard" : "exportOpt_aggressive", lang)}
                    </button>
                  ))}
                </div>
                <p className="text-[10px] text-muted-foreground leading-snug mt-1">{tr("exportOptHint", lang)}</p>
              </div>
              <div>
                <div className="text-[11px] flex items-center justify-between mb-1.5">
                  <span>{tr("maxSummary", lang)}</span>
                  <span className="font-mono text-muted-foreground">{layout.maxSummary}</span>
                </div>
                <Slider min={300} max={1200} step={50} value={[layout.maxSummary]} onValueChange={([v]) => updateLayout({ maxSummary: v })} />
              </div>
              <div>
                <div className="text-[11px] flex items-center justify-between mb-1.5">
                  <span>{tr("maxSkills", lang)}</span>
                  <span className="font-mono text-muted-foreground">{layout.maxSkills}</span>
                </div>
                <Slider min={8} max={40} step={1} value={[layout.maxSkills]} onValueChange={([v]) => updateLayout({ maxSkills: v })} />
              </div>
              <div>
                <div className="text-[11px] flex items-center justify-between mb-1.5">
                  <span>{tr("maxExpItem", lang)}</span>
                  <span className="font-mono text-muted-foreground">{layout.maxExperienceItemChars}</span>
                </div>
                <Slider min={300} max={1500} step={50} value={[layout.maxExperienceItemChars]} onValueChange={([v]) => updateLayout({ maxExperienceItemChars: v })} />
              </div>
              <div>
                <div className="text-[11px] flex items-center justify-between mb-1.5">
                  <span>{tr("expBreakThreshold", lang)}</span>
                  <span className="font-mono text-muted-foreground">{layout.experiencePageBreakThreshold}</span>
                </div>
                <Slider min={800} max={4000} step={100} value={[layout.experiencePageBreakThreshold]} onValueChange={([v]) => updateLayout({ experiencePageBreakThreshold: v })} />
              </div>
            </div>

            <div className="pt-2 border-t border-border">
              <div className="text-[11px] text-muted-foreground mb-1.5">{tr("previewDir", lang)}</div>
              <div className="grid grid-cols-3 gap-1.5">
                {(["auto", "rtl", "ltr"] as const).map((d) => (
                  <button
                    key={d}
                    onClick={() => setPreviewDir(d)}
                    className={`h-8 rounded-md text-[11px] font-medium border ${previewDir === d ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:bg-muted"}`}
                  >
                    {tr(d === "auto" ? "previewDirAuto" : d === "rtl" ? "previewDirRTL" : "previewDirLTR", lang)}
                  </button>
                ))}
              </div>
            </div>

            <SectionTypographyEditor
              lang={lang}
              template={cv?.template}
              settings={layout}
              onChange={(next) => { setLayoutState(next); setLayoutSettings(next); }}
            />
          </PopoverContent>
        </Popover>
        <button
          onClick={() => {
            if (!cv) return;
            const next = cv.lang === "ar" ? "en" : "ar";
            const updated = { ...cv, lang: next as "ar" | "en", updatedAt: Date.now() };
            saveCV(updated);
            setCv(updated);
          }}
          className="h-9 px-2 rounded-lg flex items-center gap-1 hover:bg-muted text-primary text-[11px] font-bold"
          aria-label="Toggle preview language"
          title={cv.lang === "ar" ? "Switch to English" : "التبديل للعربية"}
        >
          <Languages className="w-4 h-4" />
          <span>{cv.lang === "ar" ? "AR" : "EN"}</span>
        </button>
        <button onClick={handleShare} className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-muted text-primary">
          <Share2 className="w-4 h-4" />
        </button>
      </header>

      {/* AI tools row */}
      <div className="px-4 pt-4 grid grid-cols-2 gap-2">
        <Sheet open={showMatch} onOpenChange={setShowMatch}>
          <SheetTrigger asChild>
            <Button variant="outline" className="h-11 justify-start gap-2 text-primary border-primary/30">
              <Target className="w-4 h-4" />
              <span className="text-xs font-bold">{tr("matchJob", lang)}</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="bottom" className="h-[85vh] overflow-y-auto">
            <SheetHeader><SheetTitle>{tr("matchJob", lang)}</SheetTitle></SheetHeader>
            <div className="mt-4 space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold">{tr("jobsList", lang)}</div>
                  <Button type="button" size="sm" variant="outline" onClick={addJob} className="h-8 text-xs gap-1 text-primary border-primary/30">
                    <Plus className="w-3.5 h-3.5" /> {tr("addJob", lang)}
                  </Button>
                </div>
                {jobs.length === 0 && (
                  <div className="rounded-lg border border-dashed border-border p-3 text-[11px] text-muted-foreground text-center">
                    {tr("jdPlaceholder", lang)}
                  </div>
                )}
                {jobs.map((j) => {
                  const isActive = j.id === selectedJobId;
                  return (
                    <div key={j.id} className={`rounded-lg border p-2.5 space-y-2 ${isActive ? "border-primary/50 bg-primary/5" : "border-border bg-card"}`}>
                      <div className="flex items-center gap-2">
                        <Input value={j.title} onChange={(e) => updateJob(j.id, { title: e.target.value })} placeholder={tr("jobLabel", lang)} className="h-8 text-xs flex-1" />
                        {isActive ? (
                          <span className="text-[10px] font-bold px-2 py-1 rounded-full bg-primary text-primary-foreground inline-flex items-center gap-1">
                            <Check className="w-3 h-3" /> {tr("active", lang)}
                          </span>
                        ) : (
                          <Button type="button" size="sm" variant="outline" onClick={() => setSelectedJobId(j.id)} className="h-8 text-[10px] px-2">
                            {tr("useThisJob", lang)}
                          </Button>
                        )}
                        <button type="button" onClick={() => removeJob(j.id)} className="w-8 h-8 rounded-md grid place-items-center text-destructive hover:bg-destructive/10" aria-label="Remove">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <Textarea value={j.content} onChange={(e) => updateJob(j.id, { content: e.target.value })} rows={isActive ? 6 : 3} placeholder={tr("jdPlaceholder", lang)} />
                    </div>
                  );
                })}
              </div>
              <Button onClick={runMatch} disabled={aiLoading === "match"} className="w-full gradient-primary text-primary-foreground">
                {aiLoading === "match" ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4 ms-1" />}
                {aiLoading === "match" ? tr("generating", lang) : tr("matchJob", lang)}
              </Button>
              {matchResult && (
                <div className="space-y-3 pt-2">
                  <div className="rounded-xl gradient-primary text-primary-foreground p-4 text-center">
                    <div className="text-[11px] opacity-80">{tr("matchScore", lang)}</div>
                    <div className="text-4xl font-extrabold">{matchResult.score}<span className="text-lg opacity-60">/100</span></div>
                  </div>
                  {matchResult.matched_keywords && matchResult.matched_keywords.length > 0 && (
                    <ChipBlock title={tr("matchedKeywords", lang)} items={matchResult.matched_keywords} variant="success" />
                  )}
                  {matchResult.missing_keywords && matchResult.missing_keywords.length > 0 && (
                    <ChipBlock title={tr("missingKeywords", lang)} items={matchResult.missing_keywords} variant="destructive" />
                  )}
                  {matchResult.suggestions && matchResult.suggestions.length > 0 && (
                    <div>
                      <div className="text-xs font-bold mb-2">{tr("suggestions", lang)}</div>
                      <ul className="space-y-1.5 text-sm list-disc ps-5 text-muted-foreground">
                        {matchResult.suggestions.map((s, i) => <li key={i}>{s}</li>)}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>
          </SheetContent>
        </Sheet>

        <Button onClick={() => runATS()} variant="outline" className="h-11 justify-start gap-2 text-gold border-gold/40 hover:bg-gold/10" disabled={aiLoading === "ats"}>
          {aiLoading === "ats" ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          <span className="text-xs font-bold">{tr("atsCheck", lang)}</span>
        </Button>
      </div>

      <div className="px-4 pt-2 grid grid-cols-2 gap-2">
        <TemplateRecommendDialog
          lang={lang}
          cv={cv}
          jobDesc={jobDesc}
          onApply={(tid: TemplateId) => { const u = { ...cv, template: tid, updatedAt: Date.now() }; saveCV(u); setCv(u); }}
        />
        <SkillGapDialog
          lang={lang}
          cv={cv}
          jobDesc={jobDesc}
          onUpdate={(next) => { saveCV(next); setCv(next); }}
        />
      </div>

      <div className="px-4 pt-2">
        <LayoutInspector
          lang={lang}
          cv={pendingCV ?? cv}
          containerRef={previewRef}
          paperSize={paperSize}
          onFocus={focusSection}
          onAutoFix={() => runAutoFix()}
        />
      </div>

      <div className="px-4 pt-2 grid grid-cols-2 gap-2">
        <ATSInspector lang={lang} cv={pendingCV ?? cv} jobDesc={jobDesc} onFocus={focusSection} />
        <ComparePreviewDialog lang={lang} cv={pendingCV ?? cv} layout={layout} />
      </div>


      <Dialog open={showATS} onOpenChange={setShowATS}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{tr("atsCheck", lang)}</DialogTitle></DialogHeader>
          {aiLoading === "ats" && <div className="py-8 text-center"><Loader2 className="w-6 h-6 animate-spin mx-auto text-primary" /></div>}
          {atsResult && (
            <div className="space-y-3">
              <div className="rounded-xl gradient-gold text-primary p-4 text-center">
                <div className="text-[11px] opacity-80">ATS Score</div>
                <div className="text-4xl font-extrabold">{atsResult.score}<span className="text-lg opacity-60">/100</span></div>
              </div>
              {atsResult.strengths && atsResult.strengths.length > 0 && (
                <div>
                  <div className="text-xs font-bold mb-1.5 text-success">{tr("strengths", lang)}</div>
                  <ul className="text-sm list-disc ps-5 space-y-1 text-muted-foreground">{atsResult.strengths.map((s, i) => <li key={i}>{s}</li>)}</ul>
                </div>
              )}
              {atsResult.weaknesses && atsResult.weaknesses.length > 0 && (
                <div>
                  <div className="text-xs font-bold mb-1.5 text-destructive">{tr("weaknesses", lang)}</div>
                  <ul className="text-sm list-disc ps-5 space-y-1 text-muted-foreground">{atsResult.weaknesses.map((s, i) => <li key={i}>{s}</li>)}</ul>
                </div>
              )}
              {atsResult.matched_keywords && atsResult.matched_keywords.length > 0 && (
                <ChipBlock title={tr("matchedKeywords", lang)} items={atsResult.matched_keywords} variant="success" />
              )}
              {atsResult.missing_keywords && atsResult.missing_keywords.length > 0 && (
                <ChipBlock title={tr("missingKeywords", lang)} items={atsResult.missing_keywords} variant="destructive" />
              )}
              {atsResult.keywords_to_add && atsResult.keywords_to_add.length > 0 && (
                <ChipBlock title={lang === "ar" ? "كلمات مفتاحية مقترحة" : "Keywords to add"} items={atsResult.keywords_to_add} variant="primary" />
              )}
              {atsResult.placement_plan && atsResult.placement_plan.length > 0 && (
                <div className="rounded-xl border-2 border-primary/30 bg-primary/5 p-3 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-primary">
                    <MapPin className="w-3.5 h-3.5" /> {tr("placementMap", lang)}
                  </div>
                  <div className="text-[10px] text-muted-foreground leading-snug">{tr("placementHint", lang)}</div>
                  <ul className="space-y-1.5">
                    {atsResult.placement_plan.map((p, i) => {
                      const sectionLabel = tr(
                        p.section === "summary" ? "sectionSummary"
                        : p.section === "experience" ? "sectionExperience"
                        : p.section === "skills" ? "sectionSkills"
                        : p.section === "projects" ? "sectionProjects"
                        : "sectionOther",
                        lang
                      );
                      const isSel = highlightedSection === p.section;
                      return (
                        <li key={i}>
                          <button
                            type="button"
                            onClick={() => focusSection(p.section)}
                            className={`w-full text-start flex items-start gap-2 text-[11px] rounded-md p-2 border transition ${isSel ? "bg-primary/10 border-primary" : "bg-card border-border hover:bg-primary/5 hover:border-primary/40"}`}
                          >
                            <span className="px-2 py-0.5 rounded-full bg-destructive/10 text-destructive font-semibold whitespace-nowrap">{p.keyword}</span>
                            <ChevronRight className={`w-3 h-3 mt-1 shrink-0 text-muted-foreground ${lang === "ar" ? "rotate-180" : ""}`} />
                            <span className="px-2 py-0.5 rounded-full bg-primary/15 text-primary font-semibold whitespace-nowrap">{sectionLabel}</span>
                            {p.reason && <span className="text-muted-foreground leading-snug">{p.reason}</span>}
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              )}
              {atsResult.score < 95 && (
                <Button
                  onClick={runApplyATS}
                  disabled={aiLoading === "apply" || aiLoading === "ats"}
                  className="w-full h-11 gradient-primary text-primary-foreground font-bold gap-2 mt-2"
                >
                  {aiLoading === "apply" ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                  {aiLoading === "apply" ? tr("applying", lang) : tr("applyATS", lang)}
                </Button>
              )}
              <Button
                onClick={() => runATS()}
                disabled={!!aiLoading}
                variant="outline"
                className="w-full h-9 text-xs gap-2"
              >
                {aiLoading === "ats" ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                {tr("reanalyze", lang)}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Zoom controls */}
      <div className="px-4 pt-3 flex items-center justify-end gap-1">
        <button onClick={() => setZoom((z) => Math.max(0.25, z - 0.08))} className="w-8 h-8 rounded-md border border-border bg-card hover:bg-muted grid place-items-center" aria-label={tr("zoomOut", lang)}>
          <ZoomOut className="w-3.5 h-3.5" />
        </button>
        <button onClick={() => setZoom(0.46)} className="px-2 h-8 rounded-md border border-border bg-card hover:bg-muted text-[11px] font-mono" aria-label={tr("resetZoom", lang)}>
          {Math.round(zoom * 100)}%
        </button>
        <button onClick={() => setZoom((z) => Math.min(1.2, z + 0.08))} className="w-8 h-8 rounded-md border border-border bg-card hover:bg-muted grid place-items-center" aria-label={tr("zoomIn", lang)}>
          <ZoomIn className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Pending changes banner — preview before commit */}
      {pendingCV && (
        <div className="mx-3 mt-3 rounded-xl border-2 border-primary/40 bg-primary/5 p-3 space-y-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-primary" />
            <div className="text-xs font-bold text-primary flex-1">
              {lang === "ar" ? "معاينة تغييرات ATS" : "ATS changes preview"}
            </div>
          </div>
          <div className="text-[11px] text-muted-foreground leading-snug">
            {lang === "ar"
              ? "هذه معاينة للتعديلات المقترحة. اعتمدها لحفظها أو تجاهلها للعودة للنسخة الأصلية."
              : "This is a preview of suggested edits. Accept to save, or discard to revert."}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Button onClick={discardPending} variant="outline" className="h-9 text-xs">
              <X className="w-3.5 h-3.5 ms-1" />
              {lang === "ar" ? "تجاهل" : "Discard"}
            </Button>
            <Button onClick={acceptPending} className="h-9 text-xs gradient-primary text-primary-foreground font-bold">
              <Check className="w-3.5 h-3.5 ms-1" />
              {lang === "ar" ? "اعتماد" : "Accept"}
            </Button>
          </div>
        </div>
      )}

      {/* Preview canvas */}
      <div className="px-3 py-4 overflow-auto">
        {(() => {
          const active = pendingCV ?? cv;
          const expTotal = active.experience.reduce((n, e) => n + (e.description?.length || 0), 0);
          const forceKeep = expTotal <= layout.experiencePageBreakThreshold;
          return (
            <>
              {/* Override: keep Experience together when it's short enough to fit one page */}
              {forceKeep && (
                <style>{`.cv-page section[data-cv-section="experience"].cv-allow-break{break-inside:avoid;page-break-inside:avoid}`}</style>
              )}
              {/* Per-section typography overrides (resolved against the active template) */}
              <style>{typographyCSS(layout, active.template)}</style>
              {/* Preview direction override — lets users sanity-check RTL/LTR before exporting */}
              {previewDir !== "auto" && (
                <style>{`[data-cv-preview-dir="${previewDir}"] .cv-page{direction:${previewDir} !important}`}</style>
              )}
              <div ref={previewRef} data-cv-preview-dir={previewDir} className="origin-top mx-auto" style={{ transform: `scale(${zoom})`, width: `${100 / zoom}%`, marginInline: `-${(100 / zoom - 100) / 2}%`, marginBottom: `-${(1 - zoom) * 254}%` }}>
                <MemoCV cv={active} />
              </div>
            </>
          );
        })()}
      </div>
      <div className="px-4 text-[10px] text-muted-foreground text-center">{tr("shortcuts", lang)}</div>

      {/* Export footer */}
      <div className="fixed bottom-0 inset-x-0 px-3 sm:px-4 py-3 pb-safe safe-x bg-background/95 backdrop-blur border-t border-border grid grid-cols-3 gap-2 z-20">
        <Button onClick={() => exportPDF("save")} disabled={!!pendingCV} className="h-11 gradient-primary text-primary-foreground font-bold flex-col gap-0.5 leading-none">
          <Download className="w-4 h-4" />
          <span className="text-[10px]">PDF</span>
        </Button>
        <Button onClick={() => exportPDF("share")} disabled={!!pendingCV} variant="outline" className="h-11 flex-col gap-0.5 leading-none text-primary border-primary/30">
          <Share2 className="w-4 h-4" />
          <span className="text-[10px]">{tr("share", lang)}</span>
        </Button>
        <Button onClick={() => exportWord()} disabled={!!pendingCV} variant="outline" className="h-11 flex-col gap-0.5 leading-none">
          <FileType className="w-4 h-4" />
          <span className="text-[10px]">Word</span>
        </Button>
      </div>
    </div>
  );
}


const MemoCV = memo(function MemoCV({ cv }: { cv: CVData | null }) {
  if (!cv) return null;
  return <CVRenderer cv={cv} />;
}, (a, b) => a.cv === b.cv);

function ChipBlock({ title, items, variant }: { title: string; items: string[]; variant: "success" | "destructive" | "primary" }) {
  const cls = variant === "success" ? "bg-success/10 text-success" : variant === "destructive" ? "bg-destructive/10 text-destructive" : "bg-primary/10 text-primary";
  return (
    <div>
      <div className="text-xs font-bold mb-2">{title}</div>
      <div className="flex flex-wrap gap-1.5">
        {items.map((s, i) => <span key={i} className={`text-[11px] px-2.5 py-1 rounded-full font-medium ${cls}`}>{s}</span>)}
      </div>
    </div>
  );
}

function SectionTypographyEditor({
  lang,
  template,
  settings,
  onChange,
}: {
  lang: "ar" | "en";
  template: import("@/lib/cv-types").TemplateId | undefined;
  settings: LayoutSettings;
  onChange: (next: LayoutSettings) => void;
}) {
  const [mode, setMode] = useState<"section" | "group">("section");
  const [scope, setScope] = useState<"global" | "template">(template ? "template" : "global");
  const [section, setSection] = useState<SectionKey>("summary");
  const [group, setGroup] = useState<SectionGroupKey>("summary");

  const tplOverride = template ? settings.templateOverrides[template] ?? {} : {};

  // Effective current value for the editor controls
  const currentSection: SectionTypography =
    mode === "section"
      ? (scope === "template" ? tplOverride.sectionTypography?.[section] : settings.sectionTypography[section]) ?? DEFAULT_SECTION_TYPO
      : DEFAULT_SECTION_TYPO;
  const currentGroup: SectionTypography =
    mode === "group"
      ? (scope === "template" ? tplOverride.sectionGroups?.[group] : settings.sectionGroups[group]) ?? DEFAULT_SECTION_TYPO
      : DEFAULT_SECTION_TYPO;
  const current = mode === "section" ? currentSection : currentGroup;

  const update = (patch: Partial<SectionTypography>) => {
    const merged: SectionTypography = { ...current, ...patch };
    const isDefault =
      merged.align === "inherit" &&
      merged.hyphensLatin === "inherit" &&
      merged.hyphensArabic === "inherit" &&
      merged.textJustify === "inherit";
    const next: LayoutSettings = { ...settings };
    if (scope === "template" && template) {
      const ov: typeof tplOverride = { ...(next.templateOverrides[template] ?? {}) };
      if (mode === "section") {
        const sec = { ...(ov.sectionTypography ?? {}) };
        if (isDefault) delete sec[section]; else sec[section] = merged;
        ov.sectionTypography = sec;
      } else {
        const grp = { ...(ov.sectionGroups ?? {}) };
        if (isDefault) delete grp[group]; else grp[group] = merged;
        ov.sectionGroups = grp;
      }
      next.templateOverrides = { ...next.templateOverrides, [template]: ov };
    } else if (mode === "section") {
      const sec = { ...next.sectionTypography };
      if (isDefault) delete sec[section]; else sec[section] = merged;
      next.sectionTypography = sec;
    } else {
      const grp = { ...next.sectionGroups };
      if (isDefault) delete grp[group]; else grp[group] = merged;
      next.sectionGroups = grp;
    }
    onChange(next);
  };

  const reset = () => {
    const next: LayoutSettings = { ...settings };
    if (scope === "template" && template) {
      const ov = { ...(next.templateOverrides[template] ?? {}) };
      if (mode === "section") {
        const sec = { ...(ov.sectionTypography ?? {}) }; delete sec[section]; ov.sectionTypography = sec;
      } else {
        const grp = { ...(ov.sectionGroups ?? {}) }; delete grp[group]; ov.sectionGroups = grp;
      }
      next.templateOverrides = { ...next.templateOverrides, [template]: ov };
    } else if (mode === "section") {
      const sec = { ...next.sectionTypography }; delete sec[section]; next.sectionTypography = sec;
    } else {
      const grp = { ...next.sectionGroups }; delete grp[group]; next.sectionGroups = grp;
    }
    onChange(next);
  };

  const sectionLabels: Record<SectionKey, { ar: string; en: string }> = {
    summary: { ar: "النبذة", en: "Summary" },
    experience: { ar: "الخبرة", en: "Experience" },
    education: { ar: "التعليم", en: "Education" },
    skills: { ar: "المهارات", en: "Skills" },
    projects: { ar: "المشاريع", en: "Projects" },
    certificates: { ar: "الشهادات", en: "Certificates" },
    courses: { ar: "الدورات", en: "Courses" },
    awards: { ar: "الجوائز", en: "Awards" },
    languages: { ar: "اللغات", en: "Languages" },
  };
  const isOverridden = (k: SectionKey) =>
    !!(settings.sectionTypography[k] || (template && tplOverride.sectionTypography?.[k]));
  const dot = (k: SectionKey) => (isOverridden(k) ? "•" : "");

  const Row = <T extends string>({ label, val, options, onPick }: { label: string; val: T; options: { v: T; label: string }[]; onPick: (v: T) => void; }) => (
    <div>
      <div className="text-[11px] text-muted-foreground mb-1">{label}</div>
      <div className="flex flex-wrap gap-1">
        {options.map((o) => (
          <button key={o.v} type="button" onClick={() => onPick(o.v)} className={`h-7 px-2 rounded-md text-[10px] font-medium border ${val === o.v ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:bg-muted"}`}>
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );

  // Show what's effectively applied (after resolving group → template → section cascade)
  const resolvedPreview = mode === "section" && template ? resolveSectionTypography(settings, template, section) : null;

  return (
    <div className="pt-2 border-t border-border space-y-3">
      <div className="text-xs font-bold flex items-center justify-between gap-2">
        <span>{tr("sectionTypography", lang)}</span>
        {scope === "template" && template && (
          <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-primary/15 text-primary font-semibold">{tr("typoTemplateBadge", lang)}</span>
        )}
      </div>

      {/* Scope: global vs per-template */}
      <div className="grid grid-cols-2 gap-1.5">
        {(["global", "template"] as const).map((s) => (
          <button key={s} type="button" disabled={s === "template" && !template} onClick={() => setScope(s)}
            className={`h-8 rounded-md text-[10px] font-medium border ${scope === s ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:bg-muted"} disabled:opacity-40`}>
            {tr(s === "global" ? "typoScopeGlobal" : "typoScopeTemplate", lang)}
          </button>
        ))}
      </div>

      {/* Mode: per-section vs per-group */}
      <div>
        <div className="text-[11px] text-muted-foreground mb-1">{tr("typoMode", lang)}</div>
        <div className="grid grid-cols-2 gap-1.5">
          {(["group", "section"] as const).map((m) => (
            <button key={m} type="button" onClick={() => setMode(m)}
              className={`h-8 rounded-md text-[10px] font-medium border ${mode === m ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:bg-muted"}`}>
              {tr(m === "group" ? "typoModeGroup" : "typoModeSection", lang)}
            </button>
          ))}
        </div>
      </div>

      {mode === "section" ? (
        <div>
          <div className="text-[11px] text-muted-foreground mb-1.5">{tr("typoSection", lang)}</div>
          <select value={section} onChange={(e) => setSection(e.target.value as SectionKey)} className="w-full h-8 rounded-md border border-border bg-card px-2 text-xs">
            {SECTION_KEYS.map((k) => (
              <option key={k} value={k}>{sectionLabels[k][lang]} {dot(k)}</option>
            ))}
          </select>
        </div>
      ) : (
        <div>
          <div className="text-[11px] text-muted-foreground mb-1.5">{tr("typoGroup", lang)}</div>
          <select value={group} onChange={(e) => setGroup(e.target.value as SectionGroupKey)} className="w-full h-8 rounded-md border border-border bg-card px-2 text-xs">
            {(Object.keys(SECTION_GROUPS) as SectionGroupKey[]).map((g) => (
              <option key={g} value={g}>{tr(g === "summary" ? "typoGroup_summary" : g === "history" ? "typoGroup_history" : "typoGroup_lists", lang)}</option>
            ))}
          </select>
        </div>
      )}

      <Row<AlignOption> label={tr("typoAlign", lang)} val={current.align} onPick={(v) => update({ align: v })} options={[
        { v: "inherit", label: tr("typoAlignInherit", lang) },
        { v: "start", label: tr("typoAlignStart", lang) },
        { v: "justify", label: tr("typoAlignJustify", lang) },
        { v: "center", label: tr("typoAlignCenter", lang) },
      ]} />

      <Row<TextJustifyOption> label={tr("typoTextJustify", lang)} val={current.textJustify} onPick={(v) => update({ textJustify: v })} options={[
        { v: "inherit", label: tr("typoOpt_inherit", lang) },
        { v: "inter-word", label: tr("typoOpt_interword", lang) },
        { v: "auto", label: tr("typoOpt_auto", lang) },
        { v: "distribute", label: tr("typoOpt_distribute", lang) },
        { v: "none", label: tr("typoOpt_none", lang) },
      ]} />

      <Row<HyphensOption> label={tr("typoHyphensLatin", lang)} val={current.hyphensLatin} onPick={(v) => update({ hyphensLatin: v })} options={[
        { v: "inherit", label: tr("typoOpt_inherit", lang) },
        { v: "auto", label: tr("typoOpt_auto", lang) },
        { v: "manual", label: tr("typoOpt_manual", lang) },
        { v: "none", label: tr("typoOpt_none", lang) },
      ]} />

      <Row<HyphensOption> label={tr("typoHyphensArabic", lang)} val={current.hyphensArabic} onPick={(v) => update({ hyphensArabic: v })} options={[
        { v: "inherit", label: tr("typoOpt_inherit", lang) },
        { v: "manual", label: tr("typoOpt_manual", lang) },
        { v: "none", label: tr("typoOpt_none", lang) },
        { v: "auto", label: tr("typoOpt_auto", lang) },
      ]} />
      <p className="text-[10px] text-muted-foreground leading-snug">{tr("typoArabicHint", lang)}</p>

      {resolvedPreview && (
        <p className="text-[10px] text-muted-foreground leading-snug">
          <span className="font-semibold">↳</span> {resolvedPreview.align} / {resolvedPreview.textJustify} / ar:{resolvedPreview.hyphensArabic} / la:{resolvedPreview.hyphensLatin}
        </p>
      )}

      <button type="button" onClick={reset} className="text-[10px] font-medium text-muted-foreground hover:text-primary">
        {tr("typoResetSection", lang)}
      </button>
    </div>
  );
}

