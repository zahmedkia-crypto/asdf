import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ChevronRight, MoveVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCV, getCurrentId, useAppLang, ensureCurrent } from "@/lib/cv-store";
import { tr } from "@/lib/i18n";
import { SortableSections } from "@/components/cv/SortableSections";
import type { SectionKey } from "@/lib/cv-types";
import { toast } from "sonner";

export const Route = createFileRoute("/reorder")({
  head: () => ({
    meta: [
      { title: "ترتيب الأقسام" },
      { name: "description", content: "أعد ترتيب أقسام السيرة الذاتية بالسحب والإفلات." },
    ],
  }),
  component: ReorderPage,
});

function ReorderPage() {
  const [lang] = useAppLang();
  const navigate = useNavigate();
  const [id, setId] = useState<string | null>(null);
  useEffect(() => { setId(getCurrentId() || ensureCurrent()); }, []);
  const { cv, update } = useCV(id);

  if (!cv) return <div className="min-h-screen grid place-items-center text-muted-foreground">...</div>;

  const labels: Record<string, string> = {
    summary: tr("summary", lang),
    experience: tr("experience", lang),
    education: tr("education", lang),
    skills: tr("skills", lang),
    certificates: tr("certificates", lang),
    projects: tr("projects", lang),
    courses: tr("courses", lang),
    awards: tr("awards", lang),
    languages: tr("languages", lang),
  };
  cv.custom.forEach((s) => { labels[`custom:${s.id}`] = s.title || (lang === "ar" ? "قسم مخصص" : "Custom section"); });

  return (
    <div className="min-h-screen bg-background pb-32">
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border px-4 py-3 flex items-center gap-2">
        <button onClick={() => navigate({ to: "/builder" })} className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-muted">
          <ChevronRight className={`w-5 h-5 ${lang === "ar" ? "" : "rotate-180"}`} />
        </button>
        <MoveVertical className="w-4 h-4 text-primary" />
        <h1 className="font-bold text-base flex-1">{tr("reorder", lang)}</h1>
      </header>

      <div className="px-4 py-5">
        <p className="text-xs text-muted-foreground mb-4">{tr("reorderHint", lang)}</p>
        <SortableSections
          order={cv.sectionOrder}
          labels={labels}
          onChange={(next) => update((c) => ({ ...c, sectionOrder: next as SectionKey[] }))}
        />
      </div>

      <div className="fixed bottom-0 inset-x-0 p-4 bg-background/95 backdrop-blur border-t border-border">
        <Button onClick={() => { toast.success(lang === "ar" ? "تم الحفظ" : "Saved"); navigate({ to: "/builder" }); }} className="w-full gradient-primary text-primary-foreground h-12 font-bold shadow-elegant">
          {tr("save", lang)}
        </Button>
      </div>
    </div>
  );
}
