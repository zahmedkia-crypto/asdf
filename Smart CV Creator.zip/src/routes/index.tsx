import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { FileText, Sparkles, Plus, Trash2, Languages, FileEdit, Mail, Eye, MoveVertical, Settings, Moon, Sun, Download, Upload, Copy, KeyRound } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { listCVs, deleteCV, setCurrentId, useAppLang, ensureCurrent, duplicateCV, exportAllCVs, importAllCVs, getTheme, setTheme } from "@/lib/cv-store";
import { emptyCV, TEMPLATES, type CVData } from "@/lib/cv-types";
import { saveCV } from "@/lib/cv-store";
import { tr } from "@/lib/i18n";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { SettingsDialog } from "@/components/cv/SettingsDialog";
import { toast } from "sonner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "صانع السيرة الذاتية بالذكاء الاصطناعي" },
      { name: "description", content: "أنشئ سيرة ذاتية احترافية وخطاب تعريفي بالعربية والإنجليزية." },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const [lang, setLang] = useAppLang();
  const [cvs, setCvs] = useState<CVData[]>([]);
  const [theme, setThemeState] = useState<"light" | "dark">("light");
  const navigate = useNavigate();
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setCvs(listCVs());
    setThemeState(getTheme());
  }, []);

  const refresh = () => setCvs(listCVs());

  const handleNew = () => {
    const cv = emptyCV(lang);
    saveCV(cv);
    setCurrentId(cv.id);
    navigate({ to: "/builder" });
  };

  const handleOpen = (id: string) => {
    setCurrentId(id);
    navigate({ to: "/builder" });
  };

  const handleDelete = (id: string) => {
    if (!confirm(lang === "ar" ? "هل تريد حذف هذه السيرة؟" : "Delete this CV?")) return;
    deleteCV(id);
    refresh();
  };

  const handleDuplicate = (id: string) => {
    duplicateCV(id);
    refresh();
    toast.success(tr("duplicate", lang));
  };

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    setThemeState(next);
  };

  const handleExport = () => {
    const json = exportAllCVs();
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `cv-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(tr("exportAll", lang));
  };

  const handleImport = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const n = importAllCVs(reader.result as string, "merge");
        refresh();
        toast.success(`${tr("imported", lang)}: ${n}`);
      } catch {
        toast.error(tr("invalidFile", lang));
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-[100dvh] bg-background pb-24 safe-x">
      <input ref={fileRef} type="file" accept="application/json" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) handleImport(f); e.target.value = ""; }} />
      {/* Hero */}
      <header className="gradient-hero text-primary-foreground px-5 pt-10 pb-12 rounded-b-[2rem] shadow-elegant relative overflow-hidden">
        <div className="absolute -top-10 -end-10 w-40 h-40 rounded-full bg-gold/20 blur-3xl" />
        <div className="absolute -bottom-16 -start-16 w-56 h-56 rounded-full bg-primary-glow/30 blur-3xl" />
        <div className="relative">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl gradient-gold flex items-center justify-center shadow-soft">
                <FileText className="w-5 h-5 text-primary" />
              </div>
              <span className="font-bold text-base">{tr("appName", lang)}</span>
            </div>
            <div className="flex items-center gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="w-8 h-8 rounded-full bg-white/15 backdrop-blur flex items-center justify-center hover:bg-white/25 transition" aria-label={tr("settings", lang)}>
                    <Settings className="w-3.5 h-3.5" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem onClick={toggleTheme}>
                    {theme === "dark" ? <Sun className="w-4 h-4 me-2" /> : <Moon className="w-4 h-4 me-2" />}
                    {theme === "dark" ? tr("lightMode", lang) : tr("darkMode", lang)}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleExport}>
                    <Download className="w-4 h-4 me-2" />
                    {tr("exportAll", lang)}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => fileRef.current?.click()}>
                    <Upload className="w-4 h-4 me-2" />
                    {tr("importAll", lang)}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <SettingsDialog
                    lang={lang}
                    trigger={
                      <button className="relative flex w-full cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-accent">
                        <KeyRound className="w-4 h-4 me-2" />
                        {tr("apiSettings", lang)}
                      </button>
                    }
                  />
                </DropdownMenuContent>
              </DropdownMenu>
              <button
                onClick={() => setLang(lang === "ar" ? "en" : "ar")}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/15 backdrop-blur text-xs font-semibold hover:bg-white/25 transition"
              >
                <Languages className="w-3.5 h-3.5" />
                {lang === "ar" ? "EN" : "ع"}
              </button>
            </div>
          </div>

          <h1 className="text-2xl font-extrabold leading-tight mt-2 text-balance">
            {lang === "ar" ? (
              <>سيرة ذاتية تترك<br /><span className="text-gold">انطباعاً يدوم</span></>
            ) : (
              <>Build a CV that<br /><span className="text-gold">opens doors</span></>
            )}
          </h1>
          <p className="text-sm opacity-85 mt-2 leading-relaxed">{tr("tagline", lang)}</p>

          <Button onClick={handleNew} className="mt-6 w-full gradient-gold text-primary font-bold h-12 text-sm shadow-elegant hover:opacity-95">
            <Plus className="w-4 h-4 ms-1" />
            {tr("newCV", lang)}
          </Button>
        </div>
      </header>

      {/* Quick actions */}
      <section className="px-5 mt-6 grid grid-cols-4 gap-2">
        <Link to="/templates" className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-card border border-border shadow-card hover:shadow-soft transition">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <FileEdit className="w-5 h-5 text-primary" />
          </div>
          <span className="text-[10.5px] font-semibold text-center leading-tight">{tr("templates", lang)}</span>
        </Link>
        <Link to="/cover-letter" className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-card border border-border shadow-card hover:shadow-soft transition">
          <div className="w-10 h-10 rounded-lg bg-gold/15 flex items-center justify-center">
            <Mail className="w-5 h-5 text-gold" />
          </div>
          <span className="text-[10.5px] font-semibold text-center leading-tight">{tr("coverLetter", lang)}</span>
        </Link>
        <button onClick={() => { ensureCurrent(); navigate({ to: "/reorder" }); }} className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-card border border-border shadow-card hover:shadow-soft transition">
          <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center">
            <MoveVertical className="w-5 h-5 text-primary" />
          </div>
          <span className="text-[10.5px] font-semibold text-center leading-tight">{tr("reorder", lang)}</span>
        </button>
        <button onClick={() => { ensureCurrent(); navigate({ to: "/preview" }); }} className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-card border border-border shadow-card hover:shadow-soft transition">
          <div className="w-10 h-10 rounded-lg bg-success/15 flex items-center justify-center">
            <Eye className="w-5 h-5 text-success" />
          </div>
          <span className="text-[10.5px] font-semibold text-center leading-tight">{tr("preview", lang)}</span>
        </button>
      </section>

      {/* CVs */}
      <section className="px-5 mt-7">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-bold text-base">{tr("myCVs", lang)}</h2>
          <span className="text-xs text-muted-foreground">{cvs.length}</span>
        </div>

        {cvs.length === 0 ? (
          <div className="text-center py-10 px-6 rounded-2xl bg-card border border-dashed border-border">
            <Sparkles className="w-8 h-8 mx-auto text-muted-foreground/60" />
            <p className="text-sm text-muted-foreground mt-2">{tr("empty", lang)}</p>
            <Button onClick={handleNew} variant="outline" size="sm" className="mt-4">
              <Plus className="w-3.5 h-3.5 ms-1" />
              {tr("newCV", lang)}
            </Button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {cvs.map((cv) => {
              const tpl = TEMPLATES.find((t) => t.id === cv.template);
              return (
                <div key={cv.id} className="group flex items-center gap-3 p-3 rounded-xl bg-card border border-border shadow-card">
                  <button onClick={() => handleOpen(cv.id)} className="flex-1 flex items-center gap-3 text-start min-w-0">
                    {cv.contact.photo ? (
                      <img src={cv.contact.photo} alt="" className="w-11 h-14 rounded-md object-cover shadow-soft shrink-0" />
                    ) : (
                      <div className="w-11 h-14 rounded-md gradient-primary flex items-center justify-center shadow-soft shrink-0">
                        <FileText className="w-5 h-5 text-primary-foreground" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm truncate">{cv.contact.fullName || cv.name}</div>
                      <div className="text-[11px] text-muted-foreground truncate">
                        {cv.contact.jobTitle || (lang === "ar" ? "بدون مسمى" : "No title")} · {cv.lang === "ar" ? tpl?.nameAr : tpl?.nameEn}
                      </div>
                    </div>
                  </button>
                  <button onClick={() => handleDuplicate(cv.id)} className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:bg-muted hover:text-primary transition" title={tr("duplicate", lang)}>
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => handleDelete(cv.id)} className="w-8 h-8 rounded-lg flex items-center justify-center text-destructive/70 hover:bg-destructive/10 hover:text-destructive transition">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
