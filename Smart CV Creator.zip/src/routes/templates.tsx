import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ChevronRight, Check, Palette } from "lucide-react";
import { useEffect, useState } from "react";
import { TEMPLATES, ACCENT_COLORS, type TemplateId } from "@/lib/cv-types";
import { ensureCurrent, getCV, saveCV, useAppLang } from "@/lib/cv-store";
import { Button } from "@/components/ui/button";
import { CVRenderer } from "@/components/templates/all";
import { sampleCV } from "@/lib/sample-cv";
import { tr } from "@/lib/i18n";

export const Route = createFileRoute("/templates")({
  head: () => ({
    meta: [
      { title: "اختر قالب السيرة الذاتية" },
      { name: "description", content: "ستة قوالب احترافية للسيرة الذاتية: كلاسيكي، عصري، أنيق، بسيط، إبداعي، ATS." },
    ],
  }),
  component: TemplatesPage,
});

function TemplatesPage() {
  const [lang] = useAppLang();
  const navigate = useNavigate();
  const [selected, setSelected] = useState<TemplateId>("modern");
  const [accent, setAccent] = useState<string>("");
  const [cvId, setCvId] = useState<string | null>(null);
  const [previewLang, setPreviewLang] = useState<"ar" | "en">(lang as "ar" | "en");

  useEffect(() => {
    const id = ensureCurrent();
    setCvId(id);
    const cv = getCV(id);
    if (cv) { setSelected(cv.template); setAccent(cv.accentColor || ""); }
  }, []);

  const apply = () => {
    if (!cvId) return;
    const cv = getCV(cvId);
    if (!cv) return;
    saveCV({ ...cv, template: selected, accentColor: accent || undefined, lang: previewLang });
    navigate({ to: "/builder" });
  };

  return (
    <div className="min-h-screen bg-background pb-32">
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border px-4 py-3 flex items-center gap-2">
        <button onClick={() => history.back()} className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-muted">
          <ChevronRight className={`w-5 h-5 ${lang === "ar" ? "" : "rotate-180"}`} />
        </button>
        <h1 className="font-bold text-base flex-1">{tr("pickTemplate", lang)}</h1>
        <div className="inline-flex rounded-lg border border-border bg-card overflow-hidden text-[11px] font-bold">
          {(["ar", "en"] as const).map((l) => (
            <button
              key={l}
              type="button"
              onClick={() => setPreviewLang(l)}
              className={`px-2.5 h-8 transition ${previewLang === l ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}
              aria-label={l === "ar" ? "Arabic preview" : "English preview"}
            >{l === "ar" ? "عربي" : "EN"}</button>
          ))}
        </div>
      </header>

      {/* Accent colour picker */}
      <div className="px-4 pt-4">
        <div className="rounded-xl border border-border bg-card p-3">
          <div className="flex items-center gap-2 mb-2">
            <Palette className="w-4 h-4 text-primary" />
            <span className="text-xs font-bold">{tr("accentColor", lang)}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setAccent("")}
              className={`w-7 h-7 rounded-full border-2 grid place-items-center text-[10px] ${accent === "" ? "border-primary" : "border-border"}`}
              title={tr("default", lang)}
            >A</button>
            {ACCENT_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setAccent(c)}
                className={`w-7 h-7 rounded-full border-2 transition ${accent === c ? "border-primary scale-110" : "border-border"}`}
                style={{ background: c }}
                aria-label={c}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="px-4 py-5 space-y-4">
        {TEMPLATES.map((t) => {
          const cv = cvId ? getCV(cvId) : null;
          if (!cv) return null;
          // Use sample data when the user's CV is mostly empty so each template thumbnail looks real
          const isEmpty = !cv.contact.fullName && cv.experience.length === 0 && cv.skills.length === 0;
          const base = isEmpty ? sampleCV(previewLang) : { ...cv, lang: previewLang };
          const previewCV = { ...base, template: t.id, accentColor: accent || cv.accentColor || base.accentColor };
          const isSelected = selected === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setSelected(t.id)}
              className={`group block w-full text-start rounded-2xl overflow-hidden border-2 transition-all ${isSelected ? "border-primary shadow-elegant" : "border-border hover:border-primary/40"}`}
            >
              <div className="flex items-center justify-between px-4 py-3 bg-card">
                <div>
                  <div className="font-bold text-sm flex items-center gap-1.5">
                    {lang === "ar" ? t.nameAr : t.nameEn}
                    {isEmpty && <span className="text-[9px] font-medium text-muted-foreground bg-muted px-1.5 py-0.5 rounded">{lang === "ar" ? "معاينة" : "Preview"}</span>}
                  </div>
                  <div className="text-[11px] text-muted-foreground">{t.type}</div>
                </div>
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition ${isSelected ? "border-primary bg-primary" : "border-border"}`}>
                  {isSelected && <Check className="w-3.5 h-3.5 text-primary-foreground" />}
                </div>
              </div>
              <div className="bg-muted/40 p-3 overflow-hidden max-h-[420px]">
                <div className="origin-top mx-auto pointer-events-none" style={{ transform: "scale(0.42)", width: "238%", marginInline: "-69%", marginBottom: "-58%" }}>
                  <CVRenderer cv={previewCV} />
                </div>
              </div>
            </button>
          );
        })}
      </div>

      <div className="fixed bottom-0 inset-x-0 p-4 bg-background/95 backdrop-blur border-t border-border">
        <Button onClick={apply} className="w-full gradient-primary text-primary-foreground h-12 font-bold shadow-elegant">
          {lang === "ar" ? "تطبيق هذا القالب" : "Apply this template"}
        </Button>
      </div>
    </div>
  );
}
