import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, CheckCircle2, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import type { CVData, Lang } from "@/lib/cv-types";
import { runLocalATS } from "@/lib/ats-local";

interface Props {
  lang: Lang;
  cv: CVData;
  jobDesc?: string;
  onFocus?: (section: string) => void;
}

export function ATSInspector({ lang, cv, jobDesc, onFocus }: Props) {
  const [open, setOpen] = useState(false);
  const report = useMemo(() => runLocalATS(cv, jobDesc), [cv, jobDesc]);
  const errs = report.issues.filter((i) => i.level === "error").length;
  const warns = report.issues.filter((i) => i.level === "warn").length;

  // Auto-open the first time issues spike to errors
  useEffect(() => { /* no-op: keeps Hook count stable */ }, [report.score]);

  const color = errs > 0 ? "border-destructive/40 text-destructive" : warns > 2 ? "border-gold/40 text-gold" : "border-success/40 text-success";

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" className={`h-11 justify-start gap-2 w-full ${color}`}>
          {errs > 0 ? <AlertTriangle className="w-4 h-4" /> : <Shield className="w-4 h-4" />}
          <span className="text-xs font-bold">
            {lang === "ar" ? `فحص ATS للقالب (${report.score})` : `Template ATS (${report.score})`}
          </span>
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-3 space-y-2 max-h-[60vh] overflow-auto">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold">{lang === "ar" ? "تقرير توافق ATS" : "ATS compatibility"}</span>
          <span className={`font-mono ${errs > 0 ? "text-destructive" : "text-success"}`}>{report.score}/100</span>
        </div>
        {report.issues.length === 0 ? (
          <div className="flex items-center gap-2 text-success text-xs p-2 rounded-md bg-success/10">
            <CheckCircle2 className="w-4 h-4" />
            {lang === "ar" ? "القالب جاهز لأنظمة ATS." : "Template is ATS-ready."}
          </div>
        ) : (
          <ul className="space-y-1.5">
            {report.issues.map((i, idx) => (
              <li key={idx}>
                <button
                  type="button"
                  onClick={() => i.section && onFocus?.(i.section)}
                  className={`w-full text-start flex items-start gap-2 text-[11px] rounded-md p-2 border ${i.level === "error" ? "bg-destructive/5 border-destructive/30 text-destructive" : i.level === "warn" ? "bg-gold/5 border-gold/30 text-gold" : "bg-muted/40 border-border text-muted-foreground"}`}
                >
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <span className="flex-1 leading-snug">{i.message}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
        {report.missingKeywords.length > 0 && (
          <div className="pt-2 border-t border-border">
            <div className="text-[11px] font-bold mb-1">{lang === "ar" ? "كلمات مفتاحية مفقودة" : "Missing keywords"}</div>
            <div className="flex flex-wrap gap-1">
              {report.missingKeywords.map((k) => (
                <span key={k} className="text-[10px] px-2 py-0.5 rounded-full bg-destructive/10 text-destructive font-medium">{k}</span>
              ))}
            </div>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}
