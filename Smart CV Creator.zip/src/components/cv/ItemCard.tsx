import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ReactNode } from "react";

interface Props {
  children: ReactNode;
  onDelete: () => void;
}

export function ItemCard({ children, onDelete }: Props) {
  return (
    <div className="rounded-lg border border-border bg-card p-3 space-y-2.5 relative">
      {children}
      <div className="flex justify-end pt-1">
        <Button type="button" variant="ghost" size="sm" onClick={onDelete} className="h-7 text-destructive hover:text-destructive hover:bg-destructive/10">
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  );
}
