import { DndContext, closestCenter, PointerSensor, TouchSensor, useSensor, useSensors, type DragEndEvent } from "@dnd-kit/core";
import { SortableContext, arrayMove, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical } from "lucide-react";
import type { SectionKey } from "@/lib/cv-types";

interface Props {
  order: SectionKey[];
  labels: Record<string, string>;
  onChange: (next: SectionKey[]) => void;
}

export function SortableSections({ order, labels, onChange }: Props) {
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 150, tolerance: 8 } })
  );
  const handleEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const oldIdx = order.indexOf(active.id as SectionKey);
    const newIdx = order.indexOf(over.id as SectionKey);
    onChange(arrayMove(order, oldIdx, newIdx));
  };
  return (
    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleEnd}>
      <SortableContext items={order} strategy={verticalListSortingStrategy}>
        <div className="space-y-2">
          {order.map((k) => <Row key={k} id={k} label={labels[k] ?? k} />)}
        </div>
      </SortableContext>
    </DndContext>
  );
}

function Row({ id, label }: { id: string; label: string }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id });
  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition }}
      className={`flex items-center gap-3 p-3.5 rounded-xl bg-card border border-border shadow-card touch-none ${isDragging ? "opacity-60 shadow-elegant" : ""}`}
      {...attributes}
      {...listeners}
    >
      <GripVertical className="w-4 h-4 text-muted-foreground" />
      <span className="font-semibold text-sm">{label}</span>
    </div>
  );
}
