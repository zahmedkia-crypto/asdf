import { useState, useRef } from "react";
import { Upload, Loader2, FileText, Sparkles, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { callAI, tryParseJSON } from "@/lib/ai";
import { snapshotBackup, clearBackup } from "@/lib/cv-store";
import { toast } from "sonner";
import { tr } from "@/lib/i18n";
import type { CVData, Lang } from "@/lib/cv-types";

interface Props {
  lang: Lang;
  current: CVData;
  onApply: (next: CVData) => void;
}

type ParsedCV = Partial<{
  contact: Partial<CVData["contact"]>;
  experience: CVData["experience"];
  education: CVData["education"];
  skills: CVData["skills"];
  certificates: CVData["certificates"];
  projects: CVData["projects"];
  courses: CVData["courses"];
  awards: CVData["awards"];
  languages: CVData["languages"];
}>;

type MergeMode = "merge" | "replace" | "skip";

const SECTIONS: { key: keyof ParsedCV; labelAr: string; labelEn: string }[] = [
  { key: "contact", labelAr: "البيانات الشخصية", labelEn: "Contact" },
  { key: "experience", labelAr: "الخبرة", labelEn: "Experience" },
  { key: "education", labelAr: "التعليم", labelEn: "Education" },
  { key: "skills", labelAr: "المهارات", labelEn: "Skills" },
  { key: "certificates", labelAr: "الشهادات", labelEn: "Certificates" },
  { key: "projects", labelAr: "المشاريع", labelEn: "Projects" },
  { key: "courses", labelAr: "الدورات", labelEn: "Courses" },
  { key: "awards", labelAr: "الجوائز", labelEn: "Awards" },
  { key: "languages", labelAr: "اللغات", labelEn: "Languages" },
];

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result as string);
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}
function readAsText(file: File): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result as string);
    r.onerror = rej;
    r.readAsText(file);
  });
}

const uid = () => crypto.randomUUID();

function withIds<T extends { id?: string }>(arr: T[] | undefined): (T & { id: string })[] {
  return (arr || []).map((x) => ({ ...x, id: x.id || uid() }));
}

export function CVUploadDialog({ lang, current, onApply }: Props) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [parsed, setParsed] = useState<ParsedCV | null>(null);
  const [modes, setModes] = useState<Record<string, MergeMode>>({});
  const [autoImprove, setAutoImprove] = useState(true);
  const [fileName, setFileName] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const reset = () => {
    setParsed(null);
    setModes({});
    setFileName("");
    setLoading(false);
  };

  const handleFile = async (file: File) => {
    setFileName(file.name);
    setLoading(true);
    // Safety snapshot before any destructive operation
    snapshotBackup(current, "cv_upload_start");
    try {
      let raw = "";
      const name = file.name.toLowerCase();
      const mime = file.type;

      if (name.endsWith(".txt") || mime === "text/plain") {
        const text = await readAsText(file);
        raw = await callAI("cv_parse", text, lang);
      } else if (name.endsWith(".docx") || mime.includes("officedocument.wordprocessingml")) {
        // Use mammoth client-side
        const mammoth = await import("mammoth");
        const arrayBuffer = await file.arrayBuffer();
        const { value } = await mammoth.extractRawText({ arrayBuffer });
        raw = await callAI("cv_parse", value, lang);
      } else if (mime.startsWith("image/") || mime === "application/pdf" || name.endsWith(".pdf")) {
        const dataUrl = await readAsDataUrl(file);
        raw = await callAI(
          "cv_parse",
          lang === "ar" ? "استخرج بيانات السيرة الذاتية من الملف المرفق." : "Extract CV data from the attached file.",
          lang,
          { file: { dataUrl, mime, name: file.name } }
        );
      } else {
        // Try as text fallback
        const text = await readAsText(file);
        raw = await callAI("cv_parse", text, lang);
      }

      const json = tryParseJSON<ParsedCV>(raw);
      if (!json) {
        toast.error(tr("parseFail", lang));
        return;
      }
      setParsed(json);
      // default modes: merge for arrays, replace for contact if mostly empty
      const init: Record<string, MergeMode> = {};
      for (const s of SECTIONS) {
        const v = json[s.key];
        if (!v) { init[s.key] = "skip"; continue; }
        if (s.key === "contact") {
          const hasExisting = !!(current.contact.fullName || current.contact.email);
          init[s.key] = hasExisting ? "merge" : "replace";
        } else {
          init[s.key] = "merge";
        }
      }
      setModes(init);
      toast.success(lang === "ar" ? "تم استخراج البيانات!" : "Extracted!");
    } catch (e) {
      const m = e instanceof Error ? e.message : "";
      toast.error(m === "rate_limit" ? tr("rateLimit", lang) : m === "credits" ? tr("paymentRequired", lang) : tr("aiError", lang));
    } finally {
      setLoading(false);
    }
  };

  const apply = async () => {
    if (!parsed) return;
    setLoading(true);
    try {
      let next: CVData = { ...current };

      // Contact
      if (parsed.contact && modes.contact !== "skip") {
        if (modes.contact === "replace") {
          next.contact = { ...next.contact, ...parsed.contact } as CVData["contact"];
        } else {
          const merged = { ...next.contact };
          for (const [k, v] of Object.entries(parsed.contact)) {
            const key = k as keyof CVData["contact"];
            if (v && !merged[key]) (merged as Record<string, unknown>)[key] = v;
          }
          next.contact = merged;
        }
      }

      // Arrays
      const arrayKeys: (keyof ParsedCV)[] = ["experience", "education", "skills", "certificates", "projects", "courses", "awards", "languages"];
      for (const k of arrayKeys) {
        const incoming = parsed[k];
        if (!incoming || !Array.isArray(incoming) || modes[k] === "skip") continue;
        const withId = withIds(incoming as { id?: string }[]);
        if (modes[k] === "replace") {
          (next as unknown as Record<string, unknown>)[k] = withId;
        } else {
          const existing = (next as unknown as Record<string, unknown[]>)[k] || [];
          (next as unknown as Record<string, unknown>)[k] = [...existing, ...withId];
        }
      }

      next.updatedAt = Date.now();
      // Snapshot the pre-apply state for undo
      const prev = current;
      snapshotBackup(prev, "cv_upload_apply");
      // Apply + close immediately so the UI is responsive
      onApply(next);
      toast.success(lang === "ar" ? "تم تطبيق السيرة!" : "CV applied!", {
        duration: 8000,
        action: {
          label: lang === "ar" ? "تراجع" : "Undo",
          onClick: () => { onApply(prev); clearBackup(); toast.success(lang === "ar" ? "تم التراجع" : "Reverted"); },
        },
      });
      setOpen(false);
      reset();

      // Background auto-improve — does not block UI
      if (autoImprove && next.contact.summary && next.contact.summary.trim().length > 20) {
        const baseSummary = next.contact.summary;
        callAI("improve", baseSummary, lang)
          .then((improved) => {
            if (improved && improved.trim() && improved.trim() !== baseSummary) {
              onApply({ ...next, contact: { ...next.contact, summary: improved.trim() }, updatedAt: Date.now() });
              toast.success(lang === "ar" ? "تم تحسين النبذة" : "Summary improved");
            }
          })
          .catch(() => { /* silent */ });
      }
    } finally {
      setLoading(false);
    }
  };

  const countItems = (k: keyof ParsedCV): number => {
    const v = parsed?.[k];
    if (!v) return 0;
    if (Array.isArray(v)) return v.length;
    return Object.values(v).filter(Boolean).length;
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) reset(); }}>
      <DialogTrigger asChild>
        <Button type="button" variant="outline" size="sm" className="h-9 gap-1.5 border-primary/30 text-primary">
          <Upload className="w-4 h-4" />
          <span className="text-xs font-medium">{lang === "ar" ? "رفع سيرة ذاتية" : "Upload CV"}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-primary" />
            {lang === "ar" ? "رفع وتعبئة تلقائية بالذكاء" : "AI CV Upload & Autofill"}
          </DialogTitle>
        </DialogHeader>

        {!parsed && !loading && (
          <div className="space-y-3">
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="w-full border-2 border-dashed border-primary/30 rounded-xl p-8 text-center hover:border-primary/60 hover:bg-primary/5 transition"
            >
              <Upload className="w-10 h-10 mx-auto text-primary mb-2" />
              <div className="font-semibold text-sm">{lang === "ar" ? "اختر ملف السيرة" : "Choose CV file"}</div>
              <div className="text-xs text-muted-foreground mt-1">PDF · DOCX · TXT · PNG · JPG</div>
            </button>
            <input
              ref={inputRef}
              type="file"
              accept=".pdf,.docx,.txt,.png,.jpg,.jpeg,.webp,application/pdf,image/*,text/plain"
              className="hidden"
              onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
            />
            <p className="text-[11px] text-muted-foreground text-center">
              {lang === "ar"
                ? "سيقوم الذكاء الاصطناعي بقراءة ملفك واستخراج جميع الأقسام تلقائيًا. لن نحتفظ بالملف."
                : "AI will read your file and extract all sections automatically. We don't store the file."}
            </p>
          </div>
        )}

        {loading && (
          <div className="py-10 text-center space-y-2">
            <Loader2 className="w-8 h-8 mx-auto animate-spin text-primary" />
            <p className="text-sm font-medium">
              {parsed
                ? (lang === "ar" ? "جاري التطبيق والتحسين..." : "Applying & improving...")
                : (lang === "ar" ? "جاري قراءة السيرة..." : "Reading CV...")}
            </p>
            {fileName && <p className="text-xs text-muted-foreground truncate">{fileName}</p>}
          </div>
        )}

        {parsed && !loading && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs bg-success/10 text-success rounded-lg px-3 py-2">
              <FileText className="w-4 h-4" />
              <span className="font-medium">{fileName}</span>
            </div>
            <p className="text-xs text-muted-foreground">
              {lang === "ar"
                ? "اختر طريقة دمج كل قسم مع سيرتك الحالية:"
                : "Choose how each section merges with your current CV:"}
            </p>
            <div className="space-y-1.5">
              {SECTIONS.map((s) => {
                const count = countItems(s.key);
                if (count === 0) return null;
                const mode = modes[s.key] || "skip";
                return (
                  <div key={s.key} className="flex items-center gap-2 rounded-lg border border-border p-2.5 bg-card">
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium">{lang === "ar" ? s.labelAr : s.labelEn}</div>
                      <div className="text-[11px] text-muted-foreground">
                        {count} {lang === "ar" ? "عنصر" : "items"}
                      </div>
                    </div>
                    <div className="flex gap-1 text-[11px]">
                      {(["merge", "replace", "skip"] as MergeMode[]).map((m) => (
                        <button
                          key={m}
                          type="button"
                          onClick={() => setModes((p) => ({ ...p, [s.key]: m }))}
                          className={`px-2.5 py-1 rounded-md font-medium transition ${
                            mode === m
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted text-muted-foreground hover:bg-muted/70"
                          }`}
                        >
                          {m === "merge" && (lang === "ar" ? "دمج" : "Merge")}
                          {m === "replace" && (lang === "ar" ? "استبدال" : "Replace")}
                          {m === "skip" && (lang === "ar" ? "تخطي" : "Skip")}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
            <label className="flex items-center gap-2 text-xs pt-2">
              <Checkbox checked={autoImprove} onCheckedChange={(v) => setAutoImprove(!!v)} />
              <Sparkles className="w-3.5 h-3.5 text-primary" />
              <span>{lang === "ar" ? "تحسين النبذة تلقائيًا بالذكاء بعد التطبيق" : "Auto-improve summary after applying"}</span>
            </label>
          </div>
        )}

        {parsed && !loading && (
          <DialogFooter className="gap-2">
            <Button type="button" variant="ghost" onClick={reset}>
              <X className="w-4 h-4" />
              {lang === "ar" ? "إعادة" : "Restart"}
            </Button>
            <Button type="button" onClick={apply} className="gradient-primary text-primary-foreground gap-1.5">
              <Check className="w-4 h-4" />
              {lang === "ar" ? "تطبيق على السيرة" : "Apply to CV"}
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}
