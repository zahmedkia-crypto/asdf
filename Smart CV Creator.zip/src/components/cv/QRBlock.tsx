import { useEffect, useState } from "react";
import QRCode from "qrcode";

export function QRBlock({ value, size = 64, color = "#000" }: { value: string; size?: number; color?: string }) {
  const [src, setSrc] = useState<string>("");
  useEffect(() => {
    if (!value) return;
    QRCode.toDataURL(value, { margin: 0, width: size * 2, color: { dark: color, light: "#ffffff00" } })
      .then(setSrc).catch(() => setSrc(""));
  }, [value, size, color]);
  if (!src) return null;
  return <img src={src} alt="QR" style={{ width: size, height: size }} />;
}
