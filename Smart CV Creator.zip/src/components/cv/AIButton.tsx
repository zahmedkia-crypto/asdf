import { useState } from "react";
import { Sparkles, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { callAI, type AIMode } from "@/lib/ai";
import { toast } from "sonner";
import { tr } from "@/lib/i18n";
import type { Lang } from "@/lib/cv-types";

interface Props {
  mode: AIMode;
  prompt: string;
  lang: Lang;
  disabled?: boolean;
  onResult: (text: string) => void;
  label?: string;
  size?: "sm" | "default";
}

export function AIButton({ mode, prompt, lang, disabled, onResult, label, size = "sm" }: Props) {
  const [loading, setLoading] = useState(false);
  const handle = async () => {
    if (!prompt.trim()) {
      toast.error(lang === "ar" ? "الحقل فارغ — اكتب شيئاً أولاً" : "Empty field — write something first");
      return;
    }
    setLoading(true);
    try {
      const out = await callAI(mode, prompt, lang);
      onResult(out);
      toast.success(lang === "ar" ? "تم!" : "Done!");
    } catch (e) {
      const msg = e instanceof Error ? e.message : "ai_error";
      if (msg === "rate_limit") toast.error(tr("rateLimit", lang));
      else if (msg === "credits") toast.error(tr("paymentRequired", lang));
      else toast.error(tr("aiError", lang));
    } finally {
      setLoading(false);
    }
  };
  return (
    <Button type="button" variant="ghost" size={size} disabled={disabled || loading} onClick={handle} className="text-primary hover:text-primary hover:bg-primary/10 gap-1.5 h-8">
      {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
      <span className="text-xs font-medium">{label ?? tr("improve", lang)}</span>
    </Button>
  );
}
