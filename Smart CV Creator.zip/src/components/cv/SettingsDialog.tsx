import { useState } from "react";
import { Settings2, CheckCircle2, XCircle, Loader2, ExternalLink, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { tr } from "@/lib/i18n";
import type { Lang } from "@/lib/cv-types";
import { getUserKey, setUserKey, getPreferUserKey, setPreferUserKey, pingAI, type AIProvider } from "@/lib/ai";
import { toast } from "sonner";

const FREE_PROVIDERS: { id: AIProvider; name: string; url: string; note: { ar: string; en: string } }[] = [
  { id: "google", name: "Google Gemini", url: "https://aistudio.google.com/apikey", note: { ar: "مجاني — يدعم Gemini 2.0 Flash", en: "Free — supports Gemini 2.0 Flash" } },
  { id: "openrouter", name: "OpenRouter", url: "https://openrouter.ai/keys", note: { ar: "مجاني مع نماذج :free مفتوحة المصدر", en: "Free with :free open-source models" } },
  { id: "groq", name: "Groq", url: "https://console.groq.com/keys", note: { ar: "سريع جداً — Llama 3.3 مجاني", en: "Ultra-fast — free Llama 3.3" } },
];

interface Props { lang: Lang; trigger?: React.ReactNode }

export function SettingsDialog({ lang, trigger }: Props) {
  const [open, setOpen] = useState(false);
  const existing = getUserKey();
  const [provider, setProvider] = useState<AIProvider>(existing?.provider || "google");
  const [keyVal, setKeyVal] = useState(existing?.key || "");
  const [prefer, setPrefer] = useState(getPreferUserKey());
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<null | { ok: boolean; ms: number; via?: string }>(null);

  const handleTest = async () => {
    setTesting(true); setResult(null);
    const r = await pingAI();
    setResult(r);
    setTesting(false);
    if (r.ok) toast.success(`${tr("apiSuccess", lang)} (${r.ms}ms)`);
    else toast.error(tr("apiFail", lang));
  };

  const handleSave = () => {
    if (keyVal.trim()) setUserKey({ provider, key: keyVal.trim() });
    else setUserKey(null);
    setPreferUserKey(prefer && !!keyVal.trim());
    toast.success(tr("apiSave", lang));
    setOpen(false);
  };

  const handleClear = () => {
    setUserKey(null); setPreferUserKey(false);
    setKeyVal(""); setPrefer(false);
    toast.success(tr("apiClear", lang));
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="ghost" size="sm" className="gap-1.5">
            <Settings2 className="w-4 h-4" />
            <span className="text-xs">{tr("apiSettings", lang)}</span>
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings2 className="w-4 h-4 text-primary" />
            {tr("apiSettings", lang)}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Status */}
          <div className="rounded-xl border-2 border-success/30 bg-success/5 p-3 space-y-2">
            <div className="flex items-center justify-between">
              <div className="text-xs font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-success" />
                {tr("apiStatus", lang)}: <span className="text-success">{tr("apiActive", lang)}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-success/15 text-success font-bold">Lovable AI</span>
            </div>
            <div className="text-[11px] text-muted-foreground leading-snug">
              {lang === "ar"
                ? "مفتاح Lovable مفعّل تلقائيًا برصيد مجاني يومي. يمكنك استخدام مفتاح خاص بك من المزوّدات المجانية أدناه."
                : "Lovable key is auto-activated with daily free credits. Optionally use your own key from the free providers below."}
            </div>
            <Button onClick={handleTest} size="sm" variant="outline" disabled={testing} className="h-8 w-full text-xs">
              {testing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
              {testing ? tr("apiTesting", lang) : tr("apiTest", lang)}
            </Button>
            {result && (
              <div className={`text-[11px] rounded-md p-2 flex items-start gap-1.5 ${result.ok ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"}`}>
                {result.ok ? <CheckCircle2 className="w-3.5 h-3.5 mt-0.5" /> : <XCircle className="w-3.5 h-3.5 mt-0.5" />}
                <div>
                  <div className="font-bold">{result.ok ? tr("apiSuccess", lang) : tr("apiFail", lang)} · {result.ms}ms</div>
                  {result.via && <div className="opacity-80 text-[10px]">{result.via}…</div>}
                </div>
              </div>
            )}
          </div>

          {/* Free providers list */}
          <div>
            <div className="text-xs font-bold mb-2">{tr("apiFreeProviders", lang)}</div>
            <div className="text-[10px] text-muted-foreground mb-2">{tr("apiFreeHint", lang)}</div>
            <div className="space-y-1.5">
              {FREE_PROVIDERS.map((p) => (
                <a key={p.id} href={p.url} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-2 rounded-lg border border-border p-2.5 hover:bg-muted transition">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold">{p.name}</div>
                    <div className="text-[10px] text-muted-foreground">{p.note[lang]}</div>
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 text-primary" />
                </a>
              ))}
            </div>
          </div>

          {/* User key form */}
          <div className="space-y-2 pt-2 border-t border-border">
            <Label className="text-xs font-bold">{tr("apiUserKey", lang)}</Label>
            <div>
              <Label className="text-[10px] text-muted-foreground">{tr("apiProvider", lang)}</Label>
              <Select value={provider} onValueChange={(v) => setProvider(v as AIProvider)}>
                <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {FREE_PROVIDERS.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Input
              type="password"
              value={keyVal}
              onChange={(e) => setKeyVal(e.target.value)}
              placeholder="sk-... / AIza..."
              dir="ltr"
              className="h-9 text-sm font-mono"
            />
            <label className="flex items-center gap-2 text-xs pt-1">
              <Switch checked={prefer} onCheckedChange={setPrefer} disabled={!keyVal.trim()} />
              <span>{tr("apiPreferUser", lang)}</span>
            </label>
          </div>

          <div className="flex gap-2 pt-1">
            {existing && (
              <Button onClick={handleClear} variant="outline" size="sm" className="text-destructive border-destructive/30 gap-1">
                <Trash2 className="w-3.5 h-3.5" /> {tr("apiClear", lang)}
              </Button>
            )}
            <Button onClick={handleSave} className="flex-1 gradient-primary text-primary-foreground">
              {tr("apiSave", lang)}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
