import { useState } from "react";
import { Wand2, Loader2, Check, LayoutGrid } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { callAI, tryParseJSON } from "@/lib/ai";
import { toast } from "sonner";
import { tr } from "@/lib/i18n";
import type { CVData, Lang, TemplateId } from "@/lib/cv-types";
import { TEMPLATES } from "@/lib/cv-types";

interface Props {
  lang: Lang;
  cv: CVData;
  jobDesc?: string;
  onApply: (templateId: TemplateId) => void;
}

interface Result { template: TemplateId; reason: string }

export function TemplateRecommendDialog({ lang, cv, jobDesc, onApply }: Props) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  const run = async () => {
    setLoading(true); setResult(null);
    try {
      const payload = `CV summary: ${cv.contact.jobTitle || ""} - ${cv.contact.summary || ""}\nExperience: ${cv.experience.length} entries\nSkills: ${cv.skills.map(s => s.name).join(", ")}\nAvailable templates: ${TEMPLATES.map(t => t.id).join(", ")}\n${jobDesc ? `\nTarget JOB:\n${jobDesc}` : ""}`;
      const out = await callAI("template_recommend", payload, lang);
      const parsed = tryParseJSON<Result>(out);
      if (parsed && TEMPLATES.some(t => t.id === parsed.template)) {
        setResult(parsed);
      } else toast.error(tr("parseFail", lang));
    } catch (e) {
      const m = e instanceof Error ? e.message : "";
      toast.error(m === "rate_limit" ? tr("rateLimit", lang) : m === "credits" ? tr("paymentRequired", lang) : tr("aiError", lang));
    } finally { setLoading(false); }
  };

  const apply = () => {
    if (!result) return;
    onApply(result.template);
    toast.success(tr("applied", lang));
    setOpen(false);
    setResult(null);
  };

  const tpl = result ? TEMPLATES.find(t => t.id === result.template) : null;

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (o && !result) run(); if (!o) setResult(null); }}>
      <DialogTrigger asChild>
        <Button variant="outline" className="h-11 justify-start gap-2 text-primary border-primary/30 w-full">
          <Wand2 className="w-4 h-4" />
          <span className="text-xs font-bold">{tr("templateRecommend", lang)}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Wand2 className="w-4 h-4 text-primary" />{tr("templateRecommend", lang)}</DialogTitle>
        </DialogHeader>
        {loading && (
          <div className="py-8 text-center space-y-2">
            <Loader2 className="w-6 h-6 mx-auto animate-spin text-primary" />
            <div className="text-sm">{tr("templateRecommending", lang)}</div>
          </div>
        )}
        {result && tpl && (
          <div className="space-y-3">
            <div className="rounded-xl gradient-primary text-primary-foreground p-4 text-center space-y-1">
              <LayoutGrid className="w-6 h-6 mx-auto opacity-90" />
              <div className="text-[11px] opacity-80">{tr("templates", lang)}</div>
              <div className="text-xl font-extrabold">{lang === "ar" ? tpl.nameAr : tpl.nameEn}</div>
              <div className="text-[10px] opacity-70">{tpl.type}</div>
            </div>
            <div className="text-xs text-muted-foreground leading-relaxed bg-muted/40 rounded-lg p-3">{result.reason}</div>
            <Button onClick={apply} className="w-full gradient-primary text-primary-foreground gap-2">
              <Check className="w-4 h-4" /> {tr("applyTemplate", lang)}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
