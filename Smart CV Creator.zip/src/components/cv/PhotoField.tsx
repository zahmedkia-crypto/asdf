import { useRef } from "react";
import { Camera, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { tr } from "@/lib/i18n";
import type { Lang } from "@/lib/cv-types";
import { toast } from "sonner";

interface Props {
  value?: string;
  lang: Lang;
  onChange: (v: string | undefined) => void;
}

export function PhotoField({ value, lang, onChange }: Props) {
  const ref = useRef<HTMLInputElement>(null);
  const handle = (file: File) => {
    if (file.size > 2 * 1024 * 1024) {
      toast.error(lang === "ar" ? "الصورة أكبر من 2MB" : "Image larger than 2MB");
      return;
    }
    // Resize via canvas to keep storage small
    const img = new Image();
    const reader = new FileReader();
    reader.onload = () => {
      img.onload = () => {
        const max = 320;
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const c = document.createElement("canvas");
        c.width = w; c.height = h;
        c.getContext("2d")?.drawImage(img, 0, 0, w, h);
        onChange(c.toDataURL("image/jpeg", 0.85));
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  };
  return (
    <div className="flex items-center gap-3">
      <div className="w-16 h-16 rounded-full bg-muted overflow-hidden border border-border shrink-0 flex items-center justify-center">
        {value ? <img src={value} alt="" className="w-full h-full object-cover" /> : <Camera className="w-5 h-5 text-muted-foreground" />}
      </div>
      <div className="flex-1 flex gap-2">
        <Button type="button" variant="outline" size="sm" onClick={() => ref.current?.click()}>
          {tr("uploadPhoto", lang)}
        </Button>
        {value && (
          <Button type="button" variant="ghost" size="sm" className="text-destructive" onClick={() => onChange(undefined)}>
            <X className="w-3.5 h-3.5" />
          </Button>
        )}
        <input ref={ref} type="file" accept="image/*" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) handle(f); e.target.value = ""; }} />
      </div>
    </div>
  );
}
