import { useEffect, useRef, useState } from "react";
import { Sparkles, Loader2, X, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { callAI } from "@/lib/ai";
import { tr } from "@/lib/i18n";
import type { Lang } from "@/lib/cv-types";

const KEY = "cv_inline_hints_v1";
export function getInlineHintsEnabled(): boolean {
  if (typeof window === "undefined") return false;
  return localStorage.getItem(KEY) === "1";
}
export function setInlineHintsEnabled(v: boolean) {
  localStorage.setItem(KEY, v ? "1" : "0");
}

interface Props {
  text: string;
  lang: Lang;
  onApply: (v: string) => void;
}

export function InlineHint({ text, lang, onApply }: Props) {
  const [hint, setHint] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [dismissedFor, setDismissedFor] = useState<string>("");
  const lastFetched = useRef<string>("");
  const enabled = getInlineHintsEnabled();

  useEffect(() => {
    if (!enabled) return;
    if (!text || text.trim().length < 30) { setHint(null); return; }
    if (text === dismissedFor) return;
    const t = setTimeout(async () => {
      if (lastFetched.current === text) return;
      lastFetched.current = text;
      setLoading(true);
      try {
        const out = await callAI("hint", text, lang);
        if (out && out.trim() && out.trim() !== text.trim()) setHint(out.trim());
        else setHint(null);
      } catch { /* silent */ }
      finally { setLoading(false); }
    }, 1500);
    return () => clearTimeout(t);
  }, [text, lang, enabled, dismissedFor]);

  if (!enabled) return null;
  if (loading) {
    return (
      <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground mt-1">
        <Loader2 className="w-3 h-3 animate-spin" /> {tr("inlineHintTip", lang)}…
      </div>
    );
  }
  if (!hint) return null;
  return (
    <div className="mt-2 rounded-lg border border-primary/30 bg-primary/5 p-2.5 text-xs space-y-1.5 animate-in fade-in slide-in-from-top-1">
      <div className="flex items-center gap-1.5 text-primary font-semibold">
        <Sparkles className="w-3 h-3" /> {tr("inlineHintTip", lang)}
      </div>
      <div className="text-foreground/90 leading-relaxed">{hint}</div>
      <div className="flex gap-1.5 justify-end pt-0.5">
        <Button type="button" size="sm" variant="ghost" className="h-7 text-xs gap-1" onClick={() => { setDismissedFor(text); setHint(null); }}>
          <X className="w-3 h-3" /> {tr("dismissHint", lang)}
        </Button>
        <Button type="button" size="sm" className="h-7 text-xs gap-1 gradient-primary text-primary-foreground" onClick={() => { onApply(hint); setHint(null); }}>
          <Check className="w-3 h-3" /> {tr("applyHint", lang)}
        </Button>
      </div>
    </div>
  );
}
