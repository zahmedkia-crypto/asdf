import { useEffect, useState } from "react";
import { Download, X } from "lucide-react";

type BIPEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: "accepted" | "dismissed" }> };

const DISMISS_KEY = "pwa-install-dismissed";

export function PWARegister() {
  const [deferred, setDeferred] = useState<BIPEvent | null>(null);
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;

    // Skip in iframe / preview hosts to avoid SW interfering with the editor
    const inIframe = (() => { try { return window.self !== window.top; } catch { return true; } })();
    const isPreview =
      window.location.hostname.includes("id-preview--") ||
      window.location.hostname.includes("lovableproject.com") ||
      window.location.hostname.includes("lovable.app");

    if (inIframe || isPreview) {
      navigator.serviceWorker?.getRegistrations().then((regs) => regs.forEach((r) => r.unregister())).catch(() => {});
      return;
    }

    if ("serviceWorker" in navigator) {
      const onLoad = () => { navigator.serviceWorker.register("/sw.js").catch(() => {}); };
      if (document.readyState === "complete") onLoad();
      else window.addEventListener("load", onLoad, { once: true });
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BIPEvent);
      if (!localStorage.getItem(DISMISS_KEY)) setShow(true);
    };
    window.addEventListener("beforeinstallprompt", handler);
    window.addEventListener("appinstalled", () => { setShow(false); setDeferred(null); });
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const install = async () => {
    if (!deferred) return;
    await deferred.prompt();
    await deferred.userChoice;
    setShow(false);
    setDeferred(null);
  };

  const dismiss = () => {
    localStorage.setItem(DISMISS_KEY, "1");
    setShow(false);
  };

  if (!show || !deferred) return null;

  return (
    <div className="fixed bottom-4 inset-x-4 z-50 flex items-center gap-3 p-3 rounded-2xl bg-card border border-border shadow-elegant animate-in slide-in-from-bottom">
      <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center shrink-0">
        <Download className="w-5 h-5 text-primary-foreground" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="font-semibold text-sm">ثبّت التطبيق</div>
        <div className="text-[11px] text-muted-foreground truncate">للوصول السريع والعمل بدون إنترنت</div>
      </div>
      <button onClick={install} className="px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-bold">تثبيت</button>
      <button onClick={dismiss} aria-label="إغلاق" className="w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground hover:bg-muted">
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}
