import { useState } from "react";
import { Sparkles, Loader2, Plus, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { callAI, tryParseJSON } from "@/lib/ai";
import { tr } from "@/lib/i18n";
import { toast } from "sonner";
import type { Lang } from "@/lib/cv-types";

interface Props {
  lang: Lang;
  defaultRole: string;
  existing: string[];
  onAdd: (skill: string) => void;
}

export function SkillsSuggestDialog({ lang, defaultRole, existing, onAdd }: Props) {
  const [open, setOpen] = useState(false);
  const [role, setRole] = useState(defaultRole);
  const [loading, setLoading] = useState(false);
  const [skills, setSkills] = useState<string[]>([]);
  const [added, setAdded] = useState<Set<string>>(new Set());

  const run = async () => {
    if (!role.trim()) {
      toast.error(lang === "ar" ? "أدخل المسمى الوظيفي" : "Enter a job title");
      return;
    }
    setLoading(true);
    try {
      const out = await callAI("skills_suggest", `Job title: ${role}`, lang);
      const parsed = tryParseJSON<{ skills: string[] }>(out);
      const list = parsed?.skills ?? [];
      const lower = new Set(existing.map((s) => s.toLowerCase()));
      setSkills(list.filter((s) => !lower.has(s.toLowerCase())));
      setAdded(new Set());
    } catch (e) {
      const m = e instanceof Error ? e.message : "";
      toast.error(m === "rate_limit" ? tr("rateLimit", lang) : m === "credits" ? tr("paymentRequired", lang) : tr("aiError", lang));
    } finally {
      setLoading(false);
    }
  };

  const add = (s: string) => {
    onAdd(s);
    setAdded((prev) => new Set(prev).add(s));
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (o) { setRole(defaultRole); setSkills([]); setAdded(new Set()); } }}>
      <DialogTrigger asChild>
        <Button type="button" variant="outline" size="sm" className="h-8 gap-1.5 text-primary border-primary/30">
          <Sparkles className="w-3.5 h-3.5" />
          <span className="text-xs">{tr("suggestSkills", lang)}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>{tr("suggestSkills", lang)}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="flex gap-2">
            <Input value={role} onChange={(e) => setRole(e.target.value)} placeholder={lang === "ar" ? "مثل: مهندس برمجيات" : "e.g. Software Engineer"} />
            <Button onClick={run} disabled={loading} className="gradient-primary text-primary-foreground gap-1.5 shrink-0">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {lang === "ar" ? "اقتراح" : "Suggest"}
            </Button>
          </div>
          {skills.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-1">
              {skills.map((s) => {
                const isAdded = added.has(s);
                return (
                  <button
                    key={s}
                    type="button"
                    disabled={isAdded}
                    onClick={() => add(s)}
                    className={`text-xs px-2.5 py-1.5 rounded-full border inline-flex items-center gap-1 transition ${isAdded ? "bg-success/10 text-success border-success/30" : "bg-card hover:bg-primary/10 text-foreground border-border hover:border-primary/40"}`}
                  >
                    {isAdded ? <Check className="w-3 h-3" /> : <Plus className="w-3 h-3" />}
                    {s}
                  </button>
                );
              })}
            </div>
          )}
          {!loading && skills.length === 0 && (
            <p className="text-xs text-muted-foreground">{lang === "ar" ? "اضغط اقتراح للحصول على مهارات مناسبة." : "Tap Suggest to get tailored skills."}</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
