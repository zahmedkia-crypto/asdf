import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, CheckCircle2, ChevronRight, ScanLine } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import type { CVData, Lang } from "@/lib/cv-types";
import { getLayoutSettings } from "@/lib/layout-settings";

interface Issue {
  level: "warn" | "info";
  section?: string;
  message: string;
}

interface Props {
  lang: Lang;
  cv: CVData;
  containerRef: React.RefObject<HTMLDivElement | null>;
  onFocus?: (section: string) => void;
  paperSize: "a4" | "letter";
  onAutoFix?: () => void;
}

export function LayoutInspector({ lang, cv, containerRef, onFocus, paperSize, onAutoFix }: Props) {
  const settings = getLayoutSettings();
  const SUMMARY_MAX = settings.maxSummary;
  const SKILLS_MAX = settings.maxSkills;
  const EXP_ITEM_MAX = settings.maxExperienceItemChars;
  const [open, setOpen] = useState(false);
  const [domIssues, setDomIssues] = useState<Issue[]>([]);
  const [pageCount, setPageCount] = useState(1);

  const contentIssues = useMemo<Issue[]>(() => {
    const out: Issue[] = [];
    const sLen = (cv.contact.summary || "").trim().length;
    if (sLen > SUMMARY_MAX) {
      out.push({
        level: "warn",
        section: "summary",
        message:
          lang === "ar"
            ? `النبذة طويلة (${sLen} حرف). قلّلها إلى أقل من ${SUMMARY_MAX} لتنسيق justify نظيف.`
            : `Summary is long (${sLen} chars). Trim under ${SUMMARY_MAX} for a clean justified block.`,
      });
    }
    if (cv.skills.length > SKILLS_MAX) {
      out.push({
        level: "warn",
        section: "skills",
        message:
          lang === "ar"
            ? `المهارات (${cv.skills.length}) قد لا تتسع في صفحة واحدة. اختر أهم ${SKILLS_MAX}.`
            : `Skills (${cv.skills.length}) may overflow a page. Keep the top ${SKILLS_MAX}.`,
      });
    }
    cv.experience.forEach((e, i) => {
      if ((e.description || "").length > EXP_ITEM_MAX) {
        out.push({
          level: "info",
          section: "experience",
          message:
            lang === "ar"
              ? `تجربة #${i + 1} (${e.position}) طويلة جداً — قسّمها إلى نقاط أقصر.`
              : `Experience #${i + 1} (${e.position}) is very long — split into shorter bullets.`,
        });
      }
    });
    return out;
  }, [cv, lang]);

  // Page boundary check
  useEffect(() => {
    if (!open) return;
    const root = containerRef.current;
    if (!root) return;
    const page = root.querySelector<HTMLElement>(".cv-page");
    if (!page) return;
    const pageH = paperSize === "letter" ? 1056 : 1123; // 96dpi A4=1123, Letter=1056
    const total = page.offsetHeight;
    setPageCount(Math.max(1, Math.ceil(total / pageH)));
    const issues: Issue[] = [];
    const sections = page.querySelectorAll<HTMLElement>("[data-cv-section]");
    sections.forEach((el) => {
      const key = el.dataset.cvSection || "";
      const top = el.offsetTop;
      const bottom = top + el.offsetHeight;
      const startPage = Math.floor(top / pageH);
      const endPage = Math.floor(Math.max(0, bottom - 1) / pageH);
      const allowBreak = el.classList.contains("cv-allow-break") || key === "experience" || key === "projects";
      if (endPage > startPage && !allowBreak) {
        issues.push({
          level: "warn",
          section: key,
          message:
            lang === "ar"
              ? `قسم "${labelFor(key, lang)}" ينقسم بين صفحتين. اختصر المحتوى.`
              : `Section "${labelFor(key, lang)}" splits across pages. Shorten it.`,
        });
      }
      // Heading orphan: heading near page bottom
      const h2 = el.querySelector<HTMLElement>(".tpl-h2");
      if (h2) {
        const hTop = h2.offsetTop;
        const pageBottom = (Math.floor(hTop / pageH) + 1) * pageH;
        if (pageBottom - hTop < 80) {
          issues.push({
            level: "warn",
            section: key,
            message:
              lang === "ar"
                ? `عنوان "${labelFor(key, lang)}" قريب جداً من نهاية الصفحة.`
                : `Heading "${labelFor(key, lang)}" sits too close to the page edge.`,
          });
        }
      }
    });
    setDomIssues(issues);
  }, [open, cv, containerRef, paperSize, lang]);

  const all = [...contentIssues, ...domIssues];
  const warnCount = all.filter((i) => i.level === "warn").length;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className={`h-11 justify-start gap-2 w-full ${warnCount > 0 ? "border-destructive/40 text-destructive" : "border-success/40 text-success"}`}
        >
          {warnCount > 0 ? <AlertTriangle className="w-4 h-4" /> : <ScanLine className="w-4 h-4" />}
          <span className="text-xs font-bold">
            {lang === "ar" ? "فحص الإخراج" : "Layout Inspector"}
            {warnCount > 0 ? ` (${warnCount})` : ""}
          </span>
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-3 space-y-2 max-h-[60vh] overflow-auto">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold">{lang === "ar" ? "تقرير الإخراج" : "Layout report"}</span>
          <span className="text-muted-foreground">
            {lang === "ar" ? `${pageCount} صفحة` : `${pageCount} page${pageCount > 1 ? "s" : ""}`}
          </span>
        </div>
        {all.length === 0 ? (
          <div className="flex items-center gap-2 text-success text-xs p-2 rounded-md bg-success/10">
            <CheckCircle2 className="w-4 h-4" />
            {lang === "ar" ? "الإخراج نظيف — لا توجد تحذيرات." : "Layout is clean — no warnings."}
          </div>
        ) : (
          <>
            <ul className="space-y-1.5">
              {all.map((i, idx) => (
                <li key={idx}>
                  <button
                    type="button"
                    onClick={() => i.section && onFocus?.(i.section)}
                    className={`w-full text-start flex items-start gap-2 text-[11px] rounded-md p-2 border ${i.level === "warn" ? "bg-destructive/5 border-destructive/30 text-destructive" : "bg-muted/40 border-border text-muted-foreground"}`}
                  >
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                    <span className="flex-1 leading-snug">{i.message}</span>
                    {i.section && <ChevronRight className="w-3 h-3 shrink-0 mt-0.5 opacity-60" />}
                  </button>
                </li>
              ))}
            </ul>
            {onAutoFix && warnCount > 0 && (
              <Button
                type="button"
                size="sm"
                onClick={() => { onAutoFix(); setOpen(false); }}
                className="w-full h-8 text-[11px] gradient-primary text-primary-foreground font-bold"
              >
                {lang === "ar" ? "إصلاح تلقائي الآن" : "Auto-fix now"}
              </Button>
            )}
          </>
        )}
      </PopoverContent>
    </Popover>
  );
}

function labelFor(key: string, lang: Lang) {
  const map: Record<string, { ar: string; en: string }> = {
    summary: { ar: "النبذة", en: "Summary" },
    experience: { ar: "الخبرة", en: "Experience" },
    education: { ar: "التعليم", en: "Education" },
    skills: { ar: "المهارات", en: "Skills" },
    certificates: { ar: "الشهادات", en: "Certificates" },
    projects: { ar: "المشاريع", en: "Projects" },
    courses: { ar: "الدورات", en: "Courses" },
    awards: { ar: "الجوائز", en: "Awards" },
    languages: { ar: "اللغات", en: "Languages" },
  };
  return map[key]?.[lang] || key;
}
