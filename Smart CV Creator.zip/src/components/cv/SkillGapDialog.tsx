import { useState } from "react";
import { GitCompare, Loader2, Plus, ExternalLink, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { callAI, tryParseJSON } from "@/lib/ai";
import { toast } from "sonner";
import { tr } from "@/lib/i18n";
import type { CVData, Lang } from "@/lib/cv-types";

interface Resource { title: string; url: string }
interface Gap { skill: string; why: string; resources: Resource[] }
interface Result { gaps: Gap[]; strengths: string[] }

interface Props {
  lang: Lang;
  cv: CVData;
  jobDesc: string;
  onUpdate: (next: CVData) => void;
}

const cvText = (cv: CVData) => {
  const c = cv.contact;
  return `${c.fullName} - ${c.jobTitle}\n${c.summary}\nExperience: ${cv.experience.map(e => `${e.position}@${e.company}`).join("; ")}\nSkills: ${cv.skills.map(s => s.name).join(", ")}\nProjects: ${cv.projects.map(p => p.name).join(", ")}`;
};

export function SkillGapDialog({ lang, cv, jobDesc, onUpdate }: Props) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [selected, setSelected] = useState<Record<string, boolean>>({});

  const run = async () => {
    if (!jobDesc.trim()) { toast.error(tr("skillGapNeedJob", lang)); return; }
    setLoading(true); setResult(null); setSelected({});
    try {
      const out = await callAI("skill_gap", `JOB DESCRIPTION:\n${jobDesc}\n\nCV:\n${cvText(cv)}`, lang);
      const parsed = tryParseJSON<Result>(out);
      if (parsed && Array.isArray(parsed.gaps)) {
        setResult(parsed);
        const sel: Record<string, boolean> = {};
        parsed.gaps.forEach(g => { sel[g.skill] = true; });
        setSelected(sel);
      } else toast.error(tr("parseFail", lang));
    } catch (e) {
      const m = e instanceof Error ? e.message : "";
      toast.error(m === "rate_limit" ? tr("rateLimit", lang) : m === "credits" ? tr("paymentRequired", lang) : tr("aiError", lang));
    } finally { setLoading(false); }
  };

  const addSelectedSkills = () => {
    if (!result) return;
    const picked = result.gaps.filter(g => selected[g.skill]);
    if (!picked.length) return;
    const existing = new Set(cv.skills.map(s => s.name.toLowerCase()));
    const newSkills = picked
      .filter(g => !existing.has(g.skill.toLowerCase()))
      .map(g => ({ id: crypto.randomUUID(), name: g.skill, level: 3 }));
    if (!newSkills.length) { toast.info(lang === "ar" ? "كل المهارات موجودة" : "All already exist"); return; }
    onUpdate({ ...cv, skills: [...cv.skills, ...newSkills], updatedAt: Date.now() });
    toast.success(`+${newSkills.length} ${tr("skills", lang)}`);
  };

  const addResourcesAsCourses = () => {
    if (!result) return;
    const picked = result.gaps.filter(g => selected[g.skill]);
    const newCourses = picked.flatMap(g => g.resources.slice(0, 2).map(r => ({
      id: crypto.randomUUID(), name: r.title, provider: new URL(r.url).hostname.replace("www.", ""), date: "", url: r.url,
    })));
    if (!newCourses.length) return;
    onUpdate({ ...cv, courses: [...cv.courses, ...newCourses], updatedAt: Date.now() });
    toast.success(`+${newCourses.length} ${tr("courses", lang)}`);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (o && !result && !loading) run(); }}>
      <DialogTrigger asChild>
        <Button variant="outline" className="h-11 justify-start gap-2 text-gold border-gold/40 w-full">
          <GitCompare className="w-4 h-4" />
          <span className="text-xs font-bold">{tr("skillGap", lang)}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md max-h-[88vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><GitCompare className="w-4 h-4 text-gold" />{tr("skillGap", lang)}</DialogTitle>
        </DialogHeader>
        {loading && (
          <div className="py-10 text-center space-y-2">
            <Loader2 className="w-6 h-6 mx-auto animate-spin text-primary" />
            <div className="text-sm">{tr("skillGapAnalyzing", lang)}</div>
          </div>
        )}
        {result && !loading && (
          <div className="space-y-3">
            {result.strengths?.length > 0 && (
              <div>
                <div className="text-xs font-bold mb-1.5 text-success">{tr("gapStrengths", lang)}</div>
                <div className="flex flex-wrap gap-1.5">
                  {result.strengths.map((s, i) => <span key={i} className="text-[11px] px-2 py-0.5 rounded-full bg-success/10 text-success font-medium">{s}</span>)}
                </div>
              </div>
            )}
            {result.gaps?.length > 0 && (
              <div>
                <div className="text-xs font-bold mb-2 text-destructive">{tr("gapMissing", lang)}</div>
                <div className="space-y-2">
                  {result.gaps.map((g) => (
                    <label key={g.skill} className="flex items-start gap-2 rounded-lg border border-border p-2.5 bg-card cursor-pointer">
                      <Checkbox
                        checked={!!selected[g.skill]}
                        onCheckedChange={(v) => setSelected((p) => ({ ...p, [g.skill]: !!v }))}
                        className="mt-0.5"
                      />
                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="font-semibold text-sm">{g.skill}</div>
                        <div className="text-[11px] text-muted-foreground leading-snug">{g.why}</div>
                        {g.resources?.length > 0 && (
                          <div className="space-y-0.5 pt-1">
                            {g.resources.slice(0, 3).map((r, i) => (
                              <a key={i} href={r.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-[11px] text-primary hover:underline">
                                <ExternalLink className="w-3 h-3" /> {r.title}
                              </a>
                            ))}
                          </div>
                        )}
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            )}
            <div className="grid grid-cols-2 gap-2 pt-2">
              <Button onClick={addSelectedSkills} variant="outline" className="text-xs gap-1 h-10">
                <Plus className="w-3.5 h-3.5" /> {tr("addAllSkills", lang)}
              </Button>
              <Button onClick={addResourcesAsCourses} className="text-xs gap-1 gradient-primary text-primary-foreground h-10">
                <Check className="w-3.5 h-3.5" /> {tr("addAllCourses", lang)}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
