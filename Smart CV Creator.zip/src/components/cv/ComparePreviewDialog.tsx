import { useMemo, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Columns2 } from "lucide-react";
import { CVRenderer } from "@/components/templates/all";
import type { CVData, Lang } from "@/lib/cv-types";
import { typographyCSS, type LayoutSettings } from "@/lib/layout-settings";

type Variant = "rtl" | "ltr" | "current" | "no-typo";

interface Props {
  lang: Lang;
  cv: CVData;
  layout: LayoutSettings;
}

const VARIANT_LABELS: Record<Variant, { ar: string; en: string }> = {
  rtl: { ar: "اتجاه عربي (RTL)", en: "Arabic (RTL)" },
  ltr: { ar: "اتجاه لاتيني (LTR)", en: "Latin (LTR)" },
  current: { ar: "الإعدادات الحالية", en: "Current settings" },
  "no-typo": { ar: "بدون تجاوزات تنسيق", en: "Without typography overrides" },
};

export function ComparePreviewDialog({ lang, cv, layout }: Props) {
  const [open, setOpen] = useState(false);
  const [left, setLeft] = useState<Variant>("rtl");
  const [right, setRight] = useState<Variant>("ltr");
  const baseCSS = useMemo(() => typographyCSS(layout, cv.template), [layout, cv.template]);

  const renderPane = (v: Variant, side: "left" | "right") => {
    const useTypo = v !== "no-typo";
    const forcedDir = v === "rtl" ? "rtl" : v === "ltr" ? "ltr" : undefined;
    const paneId = `cmp-${side}`;
    return (
      <div className="flex-1 min-w-0 border border-border rounded-lg overflow-hidden bg-card">
        <div className="text-[11px] font-bold px-2 py-1 border-b border-border bg-muted/40 flex items-center gap-2">
          <span className="flex-1">{VARIANT_LABELS[v][lang]}</span>
          <select value={v} onChange={(e) => (side === "left" ? setLeft : setRight)(e.target.value as Variant)} className="text-[10px] h-6 rounded border border-border bg-card px-1">
            {(Object.keys(VARIANT_LABELS) as Variant[]).map((k) => <option key={k} value={k}>{VARIANT_LABELS[k][lang]}</option>)}
          </select>
        </div>
        <div className="overflow-auto max-h-[70vh]">
          {useTypo && <style>{baseCSS.replaceAll(".cv-page", `#${paneId} .cv-page`)}</style>}
          {forcedDir && <style>{`#${paneId} .cv-page{direction:${forcedDir} !important}`}</style>}
          <div id={paneId} className="origin-top" style={{ transform: "scale(0.4)", width: "250%", marginBottom: "-150%" }}>
            <CVRenderer cv={cv} />
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <Button variant="outline" onClick={() => setOpen(true)} className="h-11 justify-start gap-2 w-full border-primary/30 text-primary">
        <Columns2 className="w-4 h-4" />
        <span className="text-xs font-bold">{lang === "ar" ? "مقارنة جنبًا إلى جنب" : "Side-by-side compare"}</span>
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-5xl w-[95vw]">
          <DialogHeader>
            <DialogTitle>{lang === "ar" ? "معاينة مقارنة" : "Compare preview"}</DialogTitle>
          </DialogHeader>
          <div className="flex gap-2 flex-col sm:flex-row">
            {renderPane(left, "left")}
            {renderPane(right, "right")}
          </div>
          <p className="text-[10px] text-muted-foreground leading-snug">
            {lang === "ar" ? "تحقّق من الاتجاهين أو إعدادي typography مختلفين قبل التصدير. الإعدادات الفعلية لا تتغير من هذه النافذة." : "Sanity-check directions or typography presets before export. This view does not change your saved settings."}
          </p>
        </DialogContent>
      </Dialog>
    </>
  );
}
