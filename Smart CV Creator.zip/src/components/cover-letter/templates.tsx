import type { CVData, Lang } from "@/lib/cv-types";

export type LetterTemplateId = "classic" | "modern" | "elegant";
export type PaperSize = "a4" | "letter";
export type MarginPreset = "narrow" | "normal" | "wide";

export interface LetterTemplateMeta {
  id: LetterTemplateId;
  name: { ar: string; en: string };
  desc: { ar: string; en: string };
}

export const LETTER_TEMPLATES: LetterTemplateMeta[] = [
  { id: "classic", name: { ar: "كلاسيكي", en: "Classic" }, desc: { ar: "تنسيق رسمي تقليدي", en: "Traditional formal layout" } },
  { id: "modern", name: { ar: "عصري", en: "Modern" }, desc: { ar: "شريط جانبي ملوّن", en: "Colored sidebar" } },
  { id: "elegant", name: { ar: "أنيق", en: "Elegant" }, desc: { ar: "خط مزخرف ومسافات مريحة", en: "Refined serif typography" } },
];

export const PAPER_DIMS: Record<PaperSize, { w: string; h: string; mm: { w: number; h: number } }> = {
  a4: { w: "210mm", h: "297mm", mm: { w: 210, h: 297 } },
  letter: { w: "215.9mm", h: "279.4mm", mm: { w: 215.9, h: 279.4 } },
};

export const MARGIN_MM: Record<MarginPreset, number> = { narrow: 12, normal: 18, wide: 26 };

interface RenderProps {
  templateId: LetterTemplateId;
  body: string;
  cv: CVData | null;
  company: string;
  position: string;
  accentColor: string;
  lang: Lang;
  greeting?: string;
  closing?: string;
  paperSize?: PaperSize;
  marginPreset?: MarginPreset;
}

function todayStr(lang: Lang) {
  return new Date().toLocaleDateString(lang === "ar" ? "ar-EG" : "en-US", { year: "numeric", month: "long", day: "numeric" });
}

export function defaultGreeting(lang: Lang) {
  return lang === "ar" ? "إلى فريق التوظيف الموقّر،" : "Dear Hiring Team,";
}
export function defaultClosing(lang: Lang) {
  return lang === "ar" ? "مع أطيب التحيات،" : "Sincerely,";
}

export function LetterRenderer({ templateId, body, cv, company, position, accentColor, lang, greeting, closing, paperSize = "a4", marginPreset = "normal" }: RenderProps) {
  const c = cv?.contact;
  const fullName = c?.fullName || "";
  const jobTitle = c?.jobTitle || "";
  const email = c?.email || "";
  const phone = c?.phone || "";
  const location = c?.location || "";
  const date = todayStr(lang);
  const dir = lang === "ar" ? "rtl" : "ltr";
  const g = greeting || defaultGreeting(lang);
  const cl = closing || defaultClosing(lang);
  const subject = lang === "ar" ? `بخصوص وظيفة: ${position}${company ? ` — ${company}` : ""}` : `Re: ${position}${company ? ` at ${company}` : ""}`;

  const paragraphs = body.split(/\n\n+/).filter(Boolean);
  const dim = PAPER_DIMS[paperSize];
  const m = MARGIN_MM[marginPreset];

  const sheet: React.CSSProperties = {
    width: dim.w,
    minHeight: dim.h,
    background: "#ffffff",
    color: "#1f2937",
    direction: dir,
    fontFamily: lang === "ar" ? "'Tajawal', 'Cairo', system-ui, sans-serif" : "'Inter', system-ui, sans-serif",
    boxShadow: "0 4px 24px rgba(0,0,0,0.08)",
    margin: "0 auto",
  };

  if (templateId === "classic") {
    return (
      <div style={{ ...sheet, padding: `${m + 4}mm ${m}mm` }}>
        <div style={{ textAlign: lang === "ar" ? "right" : "left" }}>
          <div style={{ fontSize: 26, fontWeight: 800, letterSpacing: 0.3 }}>{fullName}</div>
          {jobTitle && <div style={{ fontSize: 13, color: "#6b7280", marginTop: 2 }}>{jobTitle}</div>}
          <div style={{ fontSize: 11, color: "#6b7280", marginTop: 6 }}>
            {[email, phone, location].filter(Boolean).join("  •  ")}
          </div>
        </div>
        <div style={{ height: 1, background: "#e5e7eb", margin: "18px 0" }} />
        <div style={{ fontSize: 11, color: "#6b7280" }}>{date}</div>
        {company && <div style={{ fontSize: 12, marginTop: 10, fontWeight: 600 }}>{company}</div>}
        <div style={{ fontSize: 13, marginTop: 14, fontWeight: 700, color: accentColor }}>{subject}</div>
        <div style={{ fontSize: 12.5, marginTop: 16, lineHeight: 1.8 }}>
          <div style={{ marginBottom: 10 }}>{g}</div>
          {paragraphs.map((p, i) => (
            <p key={i} style={{ margin: "0 0 10px 0", textAlign: "justify" }}>{p}</p>
          ))}
          <div style={{ marginTop: 18 }}>{cl}</div>
          <div style={{ marginTop: 6, fontWeight: 700 }}>{fullName}</div>
        </div>
      </div>
    );
  }

  if (templateId === "modern") {
    const sideW = `${Math.max(45, m * 3)}mm`;
    return (
      <div style={{ ...sheet, display: "flex", flexDirection: lang === "ar" ? "row-reverse" : "row" }}>
        <aside style={{ width: sideW, background: accentColor, color: "#ffffff", padding: `${m + 4}mm ${Math.max(8, m - 6)}mm` }}>
          <div style={{ fontSize: 22, fontWeight: 800, lineHeight: 1.15 }}>{fullName}</div>
          {jobTitle && <div style={{ fontSize: 12, opacity: 0.9, marginTop: 6 }}>{jobTitle}</div>}
          <div style={{ height: 1, background: "rgba(255,255,255,0.4)", margin: "16px 0" }} />
          <div style={{ fontSize: 11, lineHeight: 1.9, opacity: 0.95 }}>
            {email && <div>{email}</div>}
            {phone && <div>{phone}</div>}
            {location && <div>{location}</div>}
          </div>
          <div style={{ height: 1, background: "rgba(255,255,255,0.4)", margin: "16px 0" }} />
          <div style={{ fontSize: 10.5, opacity: 0.9 }}>{date}</div>
        </aside>
        <main style={{ flex: 1, padding: `${m + 4}mm ${m}mm` }}>
          {company && <div style={{ fontSize: 12, color: "#6b7280" }}>{company}</div>}
          <div style={{ fontSize: 18, fontWeight: 800, color: accentColor, marginTop: 4 }}>{subject}</div>
          <div style={{ fontSize: 12.5, marginTop: 18, lineHeight: 1.8 }}>
            <div style={{ marginBottom: 10 }}>{g}</div>
            {paragraphs.map((p, i) => (
              <p key={i} style={{ margin: "0 0 10px 0", textAlign: "justify" }}>{p}</p>
            ))}
            <div style={{ marginTop: 18 }}>{cl}</div>
            <div style={{ marginTop: 6, fontWeight: 700, color: accentColor }}>{fullName}</div>
          </div>
        </main>
      </div>
    );
  }

  // elegant
  return (
    <div style={{ ...sheet, padding: `${m + 8}mm ${m + 6}mm`, fontFamily: lang === "ar" ? "'Amiri', 'Tajawal', serif" : "'Cormorant Garamond', 'Georgia', serif" }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 32, fontWeight: 600, letterSpacing: 1.2, color: accentColor }}>{fullName}</div>
        <div style={{ fontSize: 11, letterSpacing: 2, textTransform: "uppercase", color: "#6b7280", marginTop: 4 }}>{jobTitle}</div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 12 }}>
          <span style={{ flex: 1, height: 1, background: accentColor, opacity: 0.4 }} />
          <span style={{ fontSize: 10, color: "#9ca3af", letterSpacing: 1 }}>{date}</span>
          <span style={{ flex: 1, height: 1, background: accentColor, opacity: 0.4 }} />
        </div>
        <div style={{ fontSize: 11, color: "#6b7280", marginTop: 10 }}>
          {[email, phone, location].filter(Boolean).join("  ·  ")}
        </div>
      </div>
      <div style={{ marginTop: 22, fontSize: 13.5, lineHeight: 1.95, fontFamily: lang === "ar" ? "'Tajawal', sans-serif" : "'Inter', sans-serif" }}>
        {company && <div style={{ fontWeight: 600 }}>{company}</div>}
        <div style={{ marginTop: 4, fontWeight: 700, color: accentColor }}>{subject}</div>
        <div style={{ marginTop: 14 }}>{g}</div>
        {paragraphs.map((p, i) => (
          <p key={i} style={{ margin: "10px 0 0 0", textAlign: "justify" }}>{p}</p>
        ))}
        <div style={{ marginTop: 22, fontStyle: "italic" }}>{cl}</div>
        <div style={{ marginTop: 4, fontWeight: 700 }}>{fullName}</div>
      </div>
    </div>
  );
}
