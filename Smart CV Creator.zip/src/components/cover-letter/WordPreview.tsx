import type { CSSProperties } from "react";
import type { CVData, Lang } from "@/lib/cv-types";
import { PAPER_DIMS, MARGIN_MM, type PaperSize, type MarginPreset } from "./templates";

export interface WordPreviewProps {
  body: string;
  cv: CVData | null;
  company: string;
  position: string;
  accent: string;
  lang: Lang;
  greeting: string;
  closing: string;
  paper: PaperSize;
  margin: MarginPreset;
}

/** Single source of truth for RTL/LTR alignment used by BOTH the on-screen
 *  Word preview and the docx export. Keeping this here guarantees the two
 *  outputs cannot drift apart. */
export function letterAlignment(lang: Lang) {
  const isRTL = lang === "ar";
  return {
    isRTL,
    dir: (isRTL ? "rtl" : "ltr") as "rtl" | "ltr",
    side: (isRTL ? "right" : "left") as "right" | "left",
    header: (isRTL ? "right" : "center") as "right" | "center",
  };
}

export function formatLetterDate(lang: Lang) {
  return new Date().toLocaleDateString(lang === "ar" ? "ar-EG" : "en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export function formatLetterSubject(lang: Lang, position: string, company: string) {
  return lang === "ar"
    ? `بخصوص وظيفة: ${position || "—"}${company ? ` — ${company}` : ""}`
    : `Re: ${position || "—"}${company ? ` at ${company}` : ""}`;
}

export function WordPreview(props: WordPreviewProps) {
  const { body, cv, company, position, accent, lang, greeting, closing, paper, margin } = props;
  const c = cv?.contact;
  const fullName = c?.fullName || (lang === "ar" ? "اسمك هنا" : "Your Name");
  const jobTitle = c?.jobTitle || "";
  const contactLine = [c?.email, c?.phone, c?.location].filter(Boolean).join(" • ");
  const date = formatLetterDate(lang);
  const subject = formatLetterSubject(lang, position, company);
  const a = letterAlignment(lang);
  const dim = PAPER_DIMS[paper];
  const m = MARGIN_MM[margin];
  const paragraphs = body.split(/\n\n+/).filter(Boolean);

  const sheet: CSSProperties = {
    width: dim.w,
    minHeight: dim.h,
    padding: `${m}mm`,
    background: "#ffffff",
    color: "#1f2937",
    direction: a.dir,
    fontFamily: a.isRTL ? "'Calibri', 'Tajawal', sans-serif" : "'Calibri', 'Times New Roman', serif",
    fontSize: 14,
    lineHeight: 1.5,
    boxShadow: "0 4px 24px rgba(0,0,0,0.08)",
    margin: "0 auto",
  };

  return (
    <div
      className="origin-top mx-auto"
      style={{
        transform: "scale(0.46)",
        width: `${100 / 0.46}%`,
        marginInline: `-${(100 / 0.46 - 100) / 2}%`,
        marginBottom: `-${(1 - 0.46) * 254}%`,
      }}
    >
      <div style={sheet} dir={a.dir} lang={a.isRTL ? "ar" : "en"}>
        <div style={{ textAlign: a.header }}>
          <div style={{ fontSize: 22, fontWeight: 700, color: accent }}>{fullName}</div>
          {jobTitle && <div style={{ fontSize: 13, color: "#6B7280" }}>{jobTitle}</div>}
          {contactLine && <div style={{ fontSize: 11, color: "#6B7280" }}>{contactLine}</div>}
        </div>
        <div style={{ height: 14 }} />
        <div style={{ textAlign: a.side, fontSize: 12, color: "#6B7280" }}>{date}</div>
        {company && <div style={{ textAlign: a.side, fontSize: 13, fontWeight: 700, marginTop: 4 }}>{company}</div>}
        <div style={{ textAlign: a.side, fontSize: 14, fontWeight: 700, color: accent, marginTop: 4 }}>{subject}</div>
        <div style={{ height: 12 }} />
        <div style={{ textAlign: a.side }}>{greeting}</div>
        {paragraphs.map((p, i) => (
          <p key={i} style={{ textAlign: a.side, margin: "10px 0 0 0" }}>{p}</p>
        ))}
        <div style={{ height: 14 }} />
        <div style={{ textAlign: a.side }}>{closing}</div>
        <div style={{ textAlign: a.side, fontWeight: 700 }}>{fullName}</div>
      </div>
    </div>
  );
}
