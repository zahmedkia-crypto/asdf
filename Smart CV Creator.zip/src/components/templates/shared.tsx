import type { CVData, SectionKey } from "@/lib/cv-types";
import { QRBlock } from "@/components/cv/QRBlock";

export interface TemplateProps {
  cv: CVData;
}

const labels = {
  ar: {
    summary: "نبذة شخصية",
    experience: "الخبرة العملية",
    education: "التعليم",
    skills: "المهارات",
    certificates: "الشهادات والاعتمادات",
    projects: "المشاريع",
    courses: "الدورات",
    awards: "الجوائز",
    languages: "اللغات",
    present: "حالياً",
    contact: "التواصل",
    profile: "الملف الشخصي",
  },
  en: {
    summary: "Profile",
    experience: "Experience",
    education: "Education",
    skills: "Skills",
    certificates: "Certificates",
    projects: "Projects",
    courses: "Courses",
    awards: "Awards",
    languages: "Languages",
    present: "Present",
    contact: "Contact",
    profile: "Profile",
  },
};

function formatDate(s?: string) {
  if (!s) return "";
  return s;
}

export function getLabels(cv: CVData) { return labels[cv.lang]; }

interface SectionRenderArgs {
  cv: CVData;
  L: typeof labels.ar;
}

export function renderSection(key: SectionKey, { cv, L }: SectionRenderArgs) {
  if (typeof key === "string" && key.startsWith("custom:")) {
    const id = key.slice(7);
    const sec = cv.custom.find((s) => s.id === id);
    if (!sec || sec.items.length === 0) return null;
    return (
      <section key={key} data-cv-section={String(key)} className="mb-5 transition-all">
        <h2 className="tpl-h2">{sec.title}</h2>
        <div className="space-y-2">
          {sec.items.map((it) => (
            <div key={it.id} className="cv-item">
              <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                <div className="font-semibold text-[13px]">{it.title}{it.subtitle ? ` — ${it.subtitle}` : ""}</div>
                {it.date && <div className="text-[11.5px] opacity-75">{it.date}</div>}
              </div>
              {it.description && <div className="text-[12px] mt-0.5 leading-relaxed whitespace-pre-line cv-summary">{it.description}</div>}
            </div>
          ))}
        </div>
      </section>
    );
  }
  switch (key) {
    case "summary":
      return cv.contact.summary ? (
        <section key={key} data-cv-section={String(key)} className="mb-5 transition-all">
          <h2 className="tpl-h2">{L.summary}</h2>
          <div className="flex items-start gap-3">
            <p className="text-[13px] leading-relaxed flex-1 cv-summary">{cv.contact.summary}</p>
            {cv.showQR && (cv.contact.linkedin || cv.contact.website) && (
              <QRBlock value={cv.contact.linkedin || cv.contact.website || ""} size={56} />
            )}
          </div>
        </section>
      ) : null;

    case "experience":
      return cv.experience.length > 0 ? (
        <section key={key} data-cv-section={String(key)} className="mb-5 transition-all cv-allow-break">
          <h2 className="tpl-h2">{L.experience}</h2>
          <div className="space-y-3">
            {cv.experience.map((e) => (
              <div key={e.id} className="cv-item">
                <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                  <div className="font-semibold text-[13.5px]">{e.position}</div>
                  <div className="text-[11.5px] opacity-75">
                    {formatDate(e.startDate)} — {e.current ? L.present : formatDate(e.endDate)}
                  </div>
                </div>
                <div className="text-[12.5px] opacity-90">
                  {e.company}{e.location ? ` · ${e.location}` : ""}
                </div>
                {e.description && (
                  <div className="text-[12px] mt-1 whitespace-pre-line leading-relaxed cv-summary">{e.description}</div>
                )}
              </div>
            ))}
          </div>
        </section>
      ) : null;

    case "education":
      return cv.education.length > 0 ? (
        <section key={key} data-cv-section={String(key)} className="mb-5 transition-all">
          <h2 className="tpl-h2">{L.education}</h2>
          <div className="space-y-3">
            {cv.education.map((e) => (
              <div key={e.id} className="cv-item">
                <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                  <div className="font-semibold text-[13.5px]">{e.degree}</div>
                  <div className="text-[11.5px] opacity-75">{formatDate(e.startDate)} — {formatDate(e.endDate)}</div>
                </div>
                <div className="text-[12.5px] opacity-90">{e.institution}{e.location ? ` · ${e.location}` : ""}{e.gpa ? ` · GPA: ${e.gpa}` : ""}</div>
                {e.description && <div className="text-[12px] mt-1 leading-relaxed cv-summary">{e.description}</div>}
              </div>
            ))}
          </div>
        </section>
      ) : null;

    case "skills":
      return cv.skills.length > 0 ? (
        <section key={key} data-cv-section={String(key)} className="mb-5 transition-all">
          <h2 className="tpl-h2">{L.skills}</h2>
          <div className="flex flex-wrap gap-1.5">
            {cv.skills.map((s) => (
              <span key={s.id} className="text-[11.5px] px-2.5 py-1 rounded bg-black/5">
                {s.name}{s.level ? ` · ${"★".repeat(s.level)}` : ""}
              </span>
            ))}
          </div>
        </section>
      ) : null;

    case "certificates":
      return cv.certificates.length > 0 ? (
        <section key={key} data-cv-section={String(key)} className="mb-5 transition-all">
          <h2 className="tpl-h2">{L.certificates}</h2>
          <div className="space-y-2">
            {cv.certificates.map((c) => (
              <div key={c.id} className="text-[12.5px] flex items-start gap-2 cv-item">
                {c.logo && <img src={c.logo} alt="" className="w-6 h-6 object-contain rounded shrink-0 mt-0.5" />}
                <div>
                  <span className="font-semibold">{c.name}</span> — {c.issuer}
                  {c.date ? <span className="opacity-70"> · {c.date}</span> : null}
                  {c.credentialId ? <span className="opacity-70"> · ID: {c.credentialId}</span> : null}
                </div>
              </div>
            ))}
          </div>
        </section>
      ) : null;

    case "projects":
      return cv.projects.length > 0 ? (
        <section key={key} data-cv-section={String(key)} className="mb-5 transition-all cv-allow-break">
          <h2 className="tpl-h2">{L.projects}</h2>
          <div className="space-y-3">
            {cv.projects.map((p) => (
              <div key={p.id} className="flex items-start gap-2 cv-item">
                {p.logo && <img src={p.logo} alt="" className="w-7 h-7 object-contain rounded shrink-0 mt-0.5" />}
                <div className="flex-1">
                  <div className="font-semibold text-[13px]">{p.name}{p.role ? ` — ${p.role}` : ""}</div>
                  {p.description && <div className="text-[12px] mt-0.5 leading-relaxed whitespace-pre-line cv-summary">{p.description}</div>}
                </div>
              </div>
            ))}
          </div>
        </section>
      ) : null;

    case "courses":
      return cv.courses.length > 0 ? (
        <section key={key} data-cv-section={String(key)} className="mb-5 transition-all">
          <h2 className="tpl-h2">{L.courses}</h2>
          <ul className="text-[12.5px] space-y-1 list-disc ps-5">
            {cv.courses.map((c) => (
              <li key={c.id} className="cv-item"><span className="font-semibold">{c.name}</span> — {c.provider}{c.date ? ` · ${c.date}` : ""}</li>
            ))}
          </ul>
        </section>
      ) : null;

    case "awards":
      return cv.awards.length > 0 ? (
        <section key={key} data-cv-section={String(key)} className="mb-5 transition-all">
          <h2 className="tpl-h2">{L.awards}</h2>
          <div className="space-y-2">
            {cv.awards.map((a) => (
              <div key={a.id} className="text-[12.5px] cv-item">
                <span className="font-semibold">{a.name}</span> — {a.issuer}{a.date ? ` · ${a.date}` : ""}
                {a.description && <div className="opacity-80 mt-0.5 cv-summary">{a.description}</div>}
              </div>
            ))}
          </div>
        </section>
      ) : null;

    case "languages":
      return cv.languages.length > 0 ? (
        <section key={key} data-cv-section={String(key)} className="mb-5 transition-all">
          <h2 className="tpl-h2">{L.languages}</h2>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-[12.5px]">
            {cv.languages.map((l) => {
              const profMap = cv.lang === "ar"
                ? { basic: "أساسي", conversational: "متوسط", fluent: "متقدم", native: "اللغة الأم" }
                : { basic: "Basic", conversational: "Conversational", fluent: "Fluent", native: "Native" };
              return <span key={l.id}><strong>{l.name}</strong> · {profMap[l.proficiency]}</span>;
            })}
          </div>
        </section>
      ) : null;
  }
}
