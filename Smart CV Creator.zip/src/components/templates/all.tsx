import type { CVData } from "@/lib/cv-types";
import { getLabels, renderSection } from "./shared";

interface Props { cv: CVData }

/* Classic — chronological, serif feel, centered header */
export function ClassicTemplate({ cv }: Props) {
  const L = getLabels(cv);
  return (
    <div dir={cv.lang === "ar" ? "rtl" : "ltr"} className="cv-page" style={{ fontFamily: cv.lang === "ar" ? "Tajawal, sans-serif" : "Georgia, serif" }}>
      <style>{`.tpl-h2{font-size:14px;font-weight:700;letter-spacing:.03em;text-transform:uppercase;border-bottom:2px solid #1a1a1a;padding-bottom:4px;margin-bottom:10px}`}</style>
      <header className="text-center mb-6 pb-4 border-b border-black/10">
        <h1 className="text-[28px] font-bold tracking-wide">{cv.contact.fullName || "—"}</h1>
        {cv.contact.jobTitle && <div className="text-[14px] opacity-75 mt-1">{cv.contact.jobTitle}</div>}
        <div className="text-[11.5px] opacity-70 mt-2 flex flex-wrap justify-center gap-x-3 gap-y-1">
          {cv.contact.email && <span>{cv.contact.email}</span>}
          {cv.contact.phone && <span>· {cv.contact.phone}</span>}
          {cv.contact.location && <span>· {cv.contact.location}</span>}
          {cv.contact.linkedin && <span>· {cv.contact.linkedin}</span>}
        </div>
      </header>
      {cv.sectionOrder.map((k) => renderSection(k, { cv, L }))}
    </div>
  );
}

/* Modern — left navy sidebar feel via colored header band */
export function ModernTemplate({ cv }: Props) {
  const L = getLabels(cv);
  return (
    <div dir={cv.lang === "ar" ? "rtl" : "ltr"} className="cv-page" style={{ padding: 0, fontFamily: "Tajawal, Inter, sans-serif" }}>
      <style>{`.tpl-h2{font-size:13px;font-weight:700;color:#1e3a5f;text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px;border-bottom:1.5px solid #d4af37;padding-bottom:3px;display:inline-block;padding-${cv.lang === "ar" ? "left" : "right"}:24px}`}</style>
      <header className="px-12 py-8 flex items-center gap-5" style={{ background: "linear-gradient(135deg,#1e3a5f,#2d4a7a)", color: "white" }}>
        {cv.contact.photo && (
          <img src={cv.contact.photo} alt="" className="w-20 h-20 rounded-full object-cover border-2 shrink-0" style={{ borderColor: "#e8c777" }} />
        )}
        <div className="flex-1 min-w-0">
          <h1 className="text-[30px] font-extrabold tracking-tight">{cv.contact.fullName || "—"}</h1>
          {cv.contact.jobTitle && <div className="text-[14px] opacity-90 mt-1" style={{ color: "#e8c777" }}>{cv.contact.jobTitle}</div>}
          <div className="text-[11.5px] opacity-90 mt-3 flex flex-wrap gap-x-3 gap-y-1">
            {cv.contact.email && <span>✉ {cv.contact.email}</span>}
            {cv.contact.phone && <span>☎ {cv.contact.phone}</span>}
            {cv.contact.location && <span>📍 {cv.contact.location}</span>}
            {cv.contact.linkedin && <span>in/ {cv.contact.linkedin}</span>}
          </div>
        </div>
      </header>
      <div className="px-12 py-8">
        {cv.sectionOrder.map((k) => renderSection(k, { cv, L }))}
      </div>
    </div>
  );
}

/* Elegant — gold accents, refined typography */
export function ElegantTemplate({ cv }: Props) {
  const L = getLabels(cv);
  return (
    <div dir={cv.lang === "ar" ? "rtl" : "ltr"} className="cv-page" style={{ fontFamily: "Tajawal, Inter, sans-serif" }}>
      <style>{`.tpl-h2{font-size:12px;font-weight:600;letter-spacing:.18em;text-transform:uppercase;color:#8a6d2f;margin-bottom:10px}.tpl-h2::after{content:"";display:block;width:32px;height:2px;background:#c9a14a;margin-top:4px}`}</style>
      <header className="mb-7">
        <h1 className="text-[34px] font-light tracking-wide" style={{ color: "#1a1a1a" }}>{cv.contact.fullName || "—"}</h1>
        {cv.contact.jobTitle && <div className="text-[13px] mt-1" style={{ color: "#8a6d2f", letterSpacing: ".15em", textTransform: "uppercase" }}>{cv.contact.jobTitle}</div>}
        <div className="h-px mt-4" style={{ background: "linear-gradient(to right, #c9a14a, transparent)" }} />
        <div className="text-[11.5px] opacity-80 mt-3 flex flex-wrap gap-x-4 gap-y-1">
          {cv.contact.email && <span>{cv.contact.email}</span>}
          {cv.contact.phone && <span>{cv.contact.phone}</span>}
          {cv.contact.location && <span>{cv.contact.location}</span>}
        </div>
      </header>
      {cv.sectionOrder.map((k) => renderSection(k, { cv, L }))}
    </div>
  );
}

/* Minimal — clean, single column */
export function MinimalTemplate({ cv }: Props) {
  const L = getLabels(cv);
  return (
    <div dir={cv.lang === "ar" ? "rtl" : "ltr"} className="cv-page" style={{ fontFamily: "Tajawal, Inter, sans-serif" }}>
      <style>{`.tpl-h2{font-size:11px;font-weight:700;letter-spacing:.15em;text-transform:uppercase;color:#666;margin-bottom:10px}`}</style>
      <header className="mb-7">
        <h1 className="text-[26px] font-bold">{cv.contact.fullName || "—"}</h1>
        {cv.contact.jobTitle && <div className="text-[13px] opacity-70 mt-0.5">{cv.contact.jobTitle}</div>}
        <div className="text-[11.5px] opacity-65 mt-2 flex flex-wrap gap-x-3 gap-y-0.5">
          {cv.contact.email && <span>{cv.contact.email}</span>}
          {cv.contact.phone && <span>· {cv.contact.phone}</span>}
          {cv.contact.location && <span>· {cv.contact.location}</span>}
        </div>
      </header>
      {cv.sectionOrder.map((k) => renderSection(k, { cv, L }))}
    </div>
  );
}

/* Creative — vibrant accent strip */
export function CreativeTemplate({ cv }: Props) {
  const L = getLabels(cv);
  return (
    <div dir={cv.lang === "ar" ? "rtl" : "ltr"} className="cv-page" style={{ fontFamily: "Tajawal, Inter, sans-serif", padding: 0 }}>
      <style>{`.tpl-h2{font-size:13px;font-weight:800;color:#7c2d92;text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px;display:flex;align-items:center;gap:8px}.tpl-h2::before{content:"";width:6px;height:6px;background:#d4af37;border-radius:50%}`}</style>
      <div className="flex" style={{ minHeight: "100%" }}>
        <aside className="w-[34%] p-8" style={{ background: "linear-gradient(160deg,#3a1c4a,#7c2d92)", color: "white" }}>
          {cv.contact.photo && (
            <img src={cv.contact.photo} alt="" className="w-24 h-24 rounded-full object-cover mb-4 border-2" style={{ borderColor: "#e8c777" }} />
          )}
          <h1 className="text-[22px] font-extrabold leading-tight">{cv.contact.fullName || "—"}</h1>
          {cv.contact.jobTitle && <div className="text-[12px] mt-1" style={{ color: "#e8c777" }}>{cv.contact.jobTitle}</div>}
          <div className="h-px my-5 bg-white/20" />
          <div className="text-[11px] space-y-1.5 opacity-95">
            {cv.contact.email && <div>✉ {cv.contact.email}</div>}
            {cv.contact.phone && <div>☎ {cv.contact.phone}</div>}
            {cv.contact.location && <div>📍 {cv.contact.location}</div>}
            {cv.contact.linkedin && <div>{cv.contact.linkedin}</div>}
          </div>
          {cv.skills.length > 0 && (
            <div className="mt-6">
              <div className="text-[11px] font-bold uppercase tracking-widest mb-2" style={{ color: "#e8c777" }}>{L.skills}</div>
              <div className="flex flex-wrap gap-1.5">
                {cv.skills.map((s) => <span key={s.id} className="text-[10.5px] px-2 py-0.5 bg-white/15 rounded">{s.name}</span>)}
              </div>
            </div>
          )}
          {cv.languages.length > 0 && (
            <div className="mt-6">
              <div className="text-[11px] font-bold uppercase tracking-widest mb-2" style={{ color: "#e8c777" }}>{L.languages}</div>
              <div className="text-[11px] space-y-1">
                {cv.languages.map((l) => <div key={l.id}>{l.name}</div>)}
              </div>
            </div>
          )}
        </aside>
        <main className="flex-1 p-8">
          {cv.sectionOrder.filter((k) => k !== "skills" && k !== "languages").map((k) => renderSection(k, { cv, L }))}
        </main>
      </div>
    </div>
  );
}

/* ATS — pure black on white, no decoration, single column, max parseability */
export function AtsTemplate({ cv }: Props) {
  const L = getLabels(cv);
  return (
    <div dir={cv.lang === "ar" ? "rtl" : "ltr"} className="cv-page" style={{ fontFamily: cv.lang === "ar" ? "Tajawal, Arial, sans-serif" : "Arial, sans-serif", color: "#000" }}>
      <style>{`.tpl-h2{font-size:13px;font-weight:700;text-transform:uppercase;color:#000;margin-bottom:6px;border-bottom:1px solid #000;padding-bottom:2px}`}</style>
      <header className="mb-5">
        <h1 className="text-[22px] font-bold uppercase">{cv.contact.fullName || "—"}</h1>
        {cv.contact.jobTitle && <div className="text-[13px] mt-0.5">{cv.contact.jobTitle}</div>}
        <div className="text-[12px] mt-1.5">
          {[cv.contact.email, cv.contact.phone, cv.contact.location, cv.contact.linkedin].filter(Boolean).join(" | ")}
        </div>
      </header>
      {cv.sectionOrder.map((k) => renderSection(k, { cv, L }))}
    </div>
  );
}

/* Executive — bold serif name, gold rule, refined senior look */
export function ExecutiveTemplate({ cv }: Props) {
  const L = getLabels(cv);
  const accent = cv.accentColor || "#1a1a1a";
  return (
    <div dir={cv.lang === "ar" ? "rtl" : "ltr"} className="cv-page" style={{ fontFamily: cv.lang === "ar" ? "Tajawal, serif" : "'Playfair Display', Georgia, serif" }}>
      <style>{`.tpl-h2{font-size:12px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:${accent};margin-bottom:10px;padding-bottom:4px;border-bottom:1px solid ${accent}}`}</style>
      <header className="mb-7 text-center pb-5" style={{ borderBottom: `3px double ${accent}` }}>
        <h1 className="text-[34px] font-bold tracking-wider" style={{ color: accent }}>{cv.contact.fullName || "—"}</h1>
        {cv.contact.jobTitle && <div className="text-[12px] mt-1 tracking-[.3em] uppercase opacity-70">{cv.contact.jobTitle}</div>}
        <div className="text-[11.5px] mt-3 opacity-75">
          {[cv.contact.email, cv.contact.phone, cv.contact.location].filter(Boolean).join("  •  ")}
        </div>
      </header>
      {cv.sectionOrder.map((k) => renderSection(k, { cv, L }))}
    </div>
  );
}

/* Tech — dev-style, monospace accents, dark accent badges */
export function TechTemplate({ cv }: Props) {
  const L = getLabels(cv);
  const accent = cv.accentColor || "#0d7a5f";
  return (
    <div dir={cv.lang === "ar" ? "rtl" : "ltr"} className="cv-page" style={{ fontFamily: "Tajawal, 'JetBrains Mono', ui-monospace, monospace" }}>
      <style>{`.tpl-h2{font-size:12px;font-weight:800;color:${accent};margin-bottom:8px;font-family:'JetBrains Mono',ui-monospace,monospace}.tpl-h2::before{content:"// ";opacity:.6}`}</style>
      <header className="mb-6 p-4 rounded-md" style={{ background: `${accent}10`, borderLeft: `4px solid ${accent}` }}>
        <div className="text-[10.5px] opacity-60" style={{ color: accent, fontFamily: "'JetBrains Mono',monospace" }}>~/cv $ whoami</div>
        <h1 className="text-[26px] font-extrabold mt-1">{cv.contact.fullName || "—"}</h1>
        {cv.contact.jobTitle && <div className="text-[13px] mt-0.5 opacity-80">{cv.contact.jobTitle}</div>}
        <div className="text-[11px] mt-2 opacity-80 flex flex-wrap gap-x-3 gap-y-0.5" style={{ fontFamily: "'JetBrains Mono',monospace" }}>
          {cv.contact.email && <span>email: {cv.contact.email}</span>}
          {cv.contact.phone && <span>tel: {cv.contact.phone}</span>}
          {cv.contact.location && <span>loc: {cv.contact.location}</span>}
          {cv.contact.linkedin && <span>in: {cv.contact.linkedin}</span>}
        </div>
      </header>
      {cv.sectionOrder.map((k) => renderSection(k, { cv, L }))}
    </div>
  );
}

/* Timeline — vertical timeline rail beside experience */
export function TimelineTemplate({ cv }: Props) {
  const L = getLabels(cv);
  const accent = cv.accentColor || "#3b82f6";
  return (
    <div dir={cv.lang === "ar" ? "rtl" : "ltr"} className="cv-page" style={{ fontFamily: "Tajawal, Inter, sans-serif" }}>
      <style>{`.tpl-h2{font-size:13px;font-weight:700;color:${accent};text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px}.tl-rail{position:relative;padding-${cv.lang === "ar" ? "right" : "left"}:18px;border-${cv.lang === "ar" ? "right" : "left"}:2px solid ${accent}30}.tl-rail > div{position:relative;margin-bottom:14px}.tl-rail > div::before{content:"";position:absolute;top:6px;${cv.lang === "ar" ? "right" : "left"}:-24px;width:10px;height:10px;border-radius:50%;background:${accent};box-shadow:0 0 0 3px ${accent}30}`}</style>
      <header className="mb-6 flex items-center gap-4">
        {cv.contact.photo && <img src={cv.contact.photo} alt="" className="w-16 h-16 rounded-full object-cover" style={{ border: `2px solid ${accent}` }} />}
        <div>
          <h1 className="text-[26px] font-extrabold" style={{ color: accent }}>{cv.contact.fullName || "—"}</h1>
          {cv.contact.jobTitle && <div className="text-[13px] opacity-80">{cv.contact.jobTitle}</div>}
          <div className="text-[11px] opacity-70 mt-1 flex flex-wrap gap-x-2">
            {[cv.contact.email, cv.contact.phone, cv.contact.location].filter(Boolean).map((v, i) => <span key={i}>{v}</span>)}
          </div>
        </div>
      </header>
      {cv.sectionOrder.map((k) => {
        if (k === "experience" && cv.experience.length) {
          return (
            <section key={k} data-cv-section={String(k)} className="mb-5 transition-all cv-allow-break">
              <h2 className="tpl-h2">{L.experience}</h2>
              <div className="tl-rail">
                {cv.experience.map((e) => (
                  <div key={e.id} className="cv-item">
                    <div className="font-semibold text-[13.5px]">{e.position}</div>
                    <div className="text-[12px] opacity-80">{e.company}{e.location ? ` · ${e.location}` : ""} · <span style={{ color: accent }}>{e.startDate} — {e.current ? L.present : e.endDate}</span></div>
                    {e.description && <div className="text-[12px] mt-1 whitespace-pre-line cv-summary">{e.description}</div>}
                  </div>
                ))}
              </div>
            </section>
          );
        }
        return renderSection(k, { cv, L });
      })}
    </div>
  );
}

/* Compact — tight spacing for one-pager */
export function CompactTemplate({ cv }: Props) {
  const L = getLabels(cv);
  const accent = cv.accentColor || "#111111";
  return (
    <div dir={cv.lang === "ar" ? "rtl" : "ltr"} className="cv-page" style={{ fontFamily: "Tajawal, Inter, sans-serif", padding: 32, fontSize: 11 }}>
      <style>{`.tpl-h2{font-size:11px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:${accent};margin-bottom:5px;border-bottom:1px solid ${accent}40;padding-bottom:2px} .cv-page section{margin-bottom:10px !important}`}</style>
      <header className="mb-4 flex items-end justify-between gap-3 pb-2" style={{ borderBottom: `2px solid ${accent}` }}>
        <div>
          <h1 className="text-[20px] font-extrabold leading-tight" style={{ color: accent }}>{cv.contact.fullName || "—"}</h1>
          {cv.contact.jobTitle && <div className="text-[12px] opacity-80">{cv.contact.jobTitle}</div>}
        </div>
        <div className="text-[10px] opacity-75 text-end leading-tight">
          {cv.contact.email && <div>{cv.contact.email}</div>}
          {cv.contact.phone && <div>{cv.contact.phone}</div>}
          {cv.contact.location && <div>{cv.contact.location}</div>}
        </div>
      </header>
      {cv.sectionOrder.map((k) => renderSection(k, { cv, L }))}
    </div>
  );
}

/* Two Column — sidebar with skills/contact, main with experience */
export function TwoColTemplate({ cv }: Props) {
  const L = getLabels(cv);
  const accent = cv.accentColor || "#7c3aed";
  return (
    <div dir={cv.lang === "ar" ? "rtl" : "ltr"} className="cv-page" style={{ fontFamily: "Tajawal, Inter, sans-serif", padding: 0 }}>
      <style>{`.tpl-h2{font-size:12px;font-weight:700;color:${accent};text-transform:uppercase;letter-spacing:.1em;margin-bottom:8px;border-bottom:1.5px solid ${accent}40;padding-bottom:3px}`}</style>
      <div className="flex" style={{ minHeight: "100%" }}>
        <aside className="w-[36%] p-7" style={{ background: `${accent}0d` }}>
          {cv.contact.photo && <img src={cv.contact.photo} alt="" className="w-24 h-24 rounded-full object-cover mb-4 mx-auto block" style={{ border: `3px solid ${accent}` }} />}
          <h1 className="text-[20px] font-extrabold text-center" style={{ color: accent }}>{cv.contact.fullName || "—"}</h1>
          {cv.contact.jobTitle && <div className="text-[12px] text-center opacity-80 mt-0.5 mb-4">{cv.contact.jobTitle}</div>}
          <div className="text-[11px] space-y-1 opacity-90 mb-4">
            {cv.contact.email && <div>✉ {cv.contact.email}</div>}
            {cv.contact.phone && <div>☎ {cv.contact.phone}</div>}
            {cv.contact.location && <div>📍 {cv.contact.location}</div>}
            {cv.contact.linkedin && <div>in/ {cv.contact.linkedin}</div>}
          </div>
          {cv.skills.length > 0 && (
            <div className="mb-4"><h2 className="tpl-h2">{L.skills}</h2>
              <div className="space-y-1.5">{cv.skills.map((s) => (
                <div key={s.id}>
                  <div className="text-[11px] flex justify-between"><span>{s.name}</span><span className="opacity-60">{"★".repeat(s.level || 3)}</span></div>
                  <div className="h-1 rounded" style={{ background: `${accent}20` }}>
                    <div className="h-full rounded" style={{ width: `${(s.level || 3) * 20}%`, background: accent }} />
                  </div>
                </div>
              ))}</div>
            </div>
          )}
          {cv.languages.length > 0 && (
            <div><h2 className="tpl-h2">{L.languages}</h2>
              <div className="text-[11px] space-y-0.5">{cv.languages.map((l) => <div key={l.id}>{l.name}</div>)}</div>
            </div>
          )}
        </aside>
        <main className="flex-1 p-7">
          {cv.sectionOrder.filter((k) => k !== "skills" && k !== "languages").map((k) => renderSection(k, { cv, L }))}
        </main>
      </div>
    </div>
  );
}

import type { TemplateId } from "@/lib/cv-types";
import type { ReactElement } from "react";

export const TEMPLATE_COMPONENTS: Record<TemplateId, (p: Props) => ReactElement> = {
  classic: ClassicTemplate,
  modern: ModernTemplate,
  elegant: ElegantTemplate,
  minimal: MinimalTemplate,
  creative: CreativeTemplate,
  ats: AtsTemplate,
  executive: ExecutiveTemplate,
  tech: TechTemplate,
  timeline: TimelineTemplate,
  compact: CompactTemplate,
  twocol: TwoColTemplate,
};

export function CVRenderer({ cv }: { cv: CVData }) {
  const Comp = TEMPLATE_COMPONENTS[cv.template] || ModernTemplate;
  return <Comp cv={cv} />;
}
